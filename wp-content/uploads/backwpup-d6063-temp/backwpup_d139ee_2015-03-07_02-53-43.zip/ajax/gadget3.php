<?
$HOST_NAME = "localhost";
$USER_NAME = "admin";
$USER_PASSWORD = "spike504";

mysql_connect($HOST_NAME, $USER_NAME, $USER_PASSWORD);

if(!isset($PHP_AUTH_USER))
{
	header('WWW-Authenticate: Basic realm="Events"');
	header('HTTP/1.0 401 Unauthorized');
	echo"You failed to provide the correct password...\n";
	exit;
}
else
{	
	$query = "SELECT * FROM mysql.user WHERE User='$PHP_AUTH_USER' AND Password=PASSWORD('$PHP_AUTH_PW')";
	$result = MYSQL_QUERY($query) or die(mysql_error());
	
	$numRows = MYSQL_NUMROWS($result);

		if($numRows == 0)
		{
			header('WWW-Authenticate: Basic realm="Events"');
			header('HTTP/1.0 401 Unauthorized');
			echo"You failed to provide the correct password...\n";
			exit;
		}
}
?>
<script language="JavaScript" src="ajax.js"></script>
<center>
<form>
Search:<input type="text" name="s" value="<?= $s ?>" onKeyup="ajax('gadget_search.php?s='+this.value,'table');" style="background:#deefff url('form_shadow.gif') fixed;">
</form>


<table border =1 bgcolor="#069E26" cellpadding="3" cellspacing="1">

<tr>
<td><center><b><font color="#88F779" filter>Website</td>
<td><center><b><font color="#88F779">Username</td>
<td><center><b><font color="#88F779">Password</td>
<td></td>
</td>
<tbody id="table">


</tbody>
</table>