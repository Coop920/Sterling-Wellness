<?
echo date("g:i:s" , mktime());
?>