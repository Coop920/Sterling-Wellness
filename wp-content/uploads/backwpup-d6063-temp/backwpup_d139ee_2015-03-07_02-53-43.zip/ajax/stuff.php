<table border="1">
<form name="a" onsubmit="return false;">

<select name='text' id='text' onChange="">
	<option value="value">text</option>
	<option value="value2">text2</option>
	<option value="value3">text3</option>
</select>
</form>


<input type="button" onClick="alert(document.a.text.text);">

<script>
function getSelectText(object)
{
	if(object[object.selectedIndex].textContent) return(object[object.selectedIndex].textContent);
	else if(object[object.selectedIndex].innerText) return(object[object.selectedIndex].innerText);
}

for(prop in document.a.text)
{
	document.write("<tr><td>" + prop + "</td><td>" + document.a.text[prop] + "</td></tr>");
}
</script>



<script>
//for(prop in document.a.text)
//{
//	document.write(prop + "| ");
//}
</script>

</table>