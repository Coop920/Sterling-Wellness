What is the smallest number that is divided by 3,4,and 5 with a remainder of 1,2,and 3 respectively?
<pre>
<?
$three = 7;
$four = 10;
$five = 8;


for($x=0;$x<500;$x++)
{
	$three_array[] = ($three + ($x*3));
}

for($x=0;$x<500;$x++)
{
	if(in_array($four + ($x*4),$three_array)) $four_array[] = ($four + ($x*4));
}

for($x=0;$x<500;$x++)
{
	if(in_array($five + ($x*5),$four_array)) $five_array[] = ($five + ($x*5));
}

print_r($five_array);

?>	