	var object;

	function callInProgress()
	{
		switch ( http.readyState )
		{
			case 1, 2, 3:
				return true;
			break;
			
			// Case 4 and 0
			default:
				return false;
			break;
		}
	}

	function handleHttpResponse_value()
	{
		if(http.readyState == 4)
		{
			results = http.responseText;
			object.value = results;
		}
		alert(http.readyState);
	}
	
	function handleHttpResponse()
	{
		if(http.readyState == 4)
		{
			results = http.responseText;
			document.getElementById(object).innerHTML = results;
		}
		
	}

	function handleHttpResponse_select()
	{
		if(http.readyState == 4)
		{
			results = http.responseText;
			object.options.length = 0;
			each_info=results.split("|");
			for(i=1;i<each_info.length;i++)
			{
				this_info=each_info[i].split("^^");
				insertNewOption (object,new Option(this_info[1], this_info[0]));
			}

		}
		
	}
	
	function ajax(page,element)
	{
		var ut=new Date();
		
		if(page.indexOf("?")==-1)
		{
			page += "?uniqueTime=" + ut;
		}
		else
		{
			page += "&uniqueTime=" + ut;
		}
		
		object=element;
		http.open("GET", page, true);
		if(object.type=='select-one' || object.type=='select-multiple') http.onreadystatechange = handleHttpResponse_select;
		if(object.type=='text' || object.type=='textarea' || object.type=='hidden') http.onreadystatechange = handleHttpResponse_value;
		else http.onreadystatechange = handleHttpResponse;
		http.send(null);
	}
	
	function ajax2(page,element)
	{
		object=element;
		http.open("GET", page, true);
		http.onreadystatechange = handleHttpResponse_select2;
		http.send(null);
	}
	
	
	
	function insertNewOption (select, option) 
	{
		var i = select.options.length;
		select.options[i] = option;
	}
	
	

	function getHTTPObject()
	{
		var xmlhttp;
		
		/*@cc_on
		@if (@_jscript_version >= 5)
		try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
		try {
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) {
		xmlhttp = false;
		}
		}
		@else
		xmlhttp = false;
		@end @*/
		
		if(!xmlhttp && typeof XMLHttpRequest != 'undefined')
		{
			try
			{
				xmlhttp = new XMLHttpRequest();
			}
			catch(e)
			{
				xmlhttp = false;
			}
		}
		return xmlhttp;
	}
	
	var http = getHTTPObject(); // We create the HTTP Object
