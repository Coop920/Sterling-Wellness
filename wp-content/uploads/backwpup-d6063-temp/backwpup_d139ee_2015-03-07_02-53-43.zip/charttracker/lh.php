<?
include("global.php");


/*$query = "SELECT * FROM ct_users WHERE usertype=5 ORDER BY lastname, firstname";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
while($user = mysql_fetch_array($result, MYSQL_ASSOC))
{
	echo "<p><b>{$user['firstname']} {$user['lastname']}</b><br>";


	$query2 = "SELECT * FROM ct_labcorp_pid WHERE firstname LIKE ('{$user['firstname']}') AND lastname LIKE ('{$user['lastname']}') LIMIT 1";
	$result2 = mysql_query($query2) or mysql_error_handler($query2, $PHP_SELF);
	if(mysql_num_rows($result2)>0) extract(mysql_fetch_array($result2));


	$queryi = "UPDATE ct_hra SET `labcorp_id` = '$id', user_id='{$user['id']}' WHERE firstname LIKE ('{$user['firstname']}') AND lastname LIKE ('{$user['lastname']}')";
	mysql_query($queryi) or mysql_error_handler($queryi, $PHP_SELF);

	/*$query3 = "SELECT * FROM ct_hra WHERE firstname LIKE ('{$user['firstname']}') AND lastname LIKE ('{$user['lastname']}')";
	$result3 = mysql_query($query3) or mysql_error_handler($query3, $PHP_SELF);
	while($hra = mysql_fetch_array($result3, MYSQL_ASSOC))
	{
	/*	$queryi = "UPDATE ct_users SET `company` = '{$hra['CompanyName']}' WHERE id='{$user['id']}'";
		mysql_query($queryi) or mysql_error_handler($queryi, $PHP_SELF);



	}
flush();
}*/

/*
$query = "SELECT * FROM ct_users WHERE usertype=4";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
while($company = mysql_fetch_array($result, MYSQL_ASSOC))
{
	echo $company['company'] . " - " . $company['id'] . "<br>";
}

$query = "SELECT * FROM ct_users WHERE usertype=5 GROUP BY company";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
while($company = mysql_fetch_array($result, MYSQL_ASSOC))
{
	echo $company['company'] . "<br>";
}

*/



/*

$query = "UPDATE ct_users SET company='596' WHERE company='Barriere Construction' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='597' WHERE company='Boh Company' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='598' WHERE company='Bollinger Shipyards' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='600' WHERE company='City of Thibodauux' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='600' WHERE company='City of Thibodaux' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='599' WHERE company='CPPJ' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='601' WHERE company='Donahue Favret' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='602' WHERE company='Haldor Topsoe' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='608' WHERE company='Orion South' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='607' WHERE company='The Blain Companies' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='607' WHERE company='The Blain Company' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


$query = "UPDATE ct_users SET company='2593' WHERE company='TRMC' AND usertype = 5";
mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
*/
?>