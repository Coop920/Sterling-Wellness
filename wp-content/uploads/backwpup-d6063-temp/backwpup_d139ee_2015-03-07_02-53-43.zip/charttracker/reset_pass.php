<table><?
include "../global.php";

$types = array('','Admin','Health Consultant','Field Consultant','Client','Patient');

$query = "SELECT * FROM `ct_users` WHERE `usertype` !=5 AND `email` != ''";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
	extract($row);
	$new_password = strtolower($firstname{0} . $lastname{0}) . rand(100,999);


	$query = "UPDATE ct_users SET password = MD5('$new_password') WHERE id='$id' LIMIT 1";
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	echo "<tr><td>$firstname</td><td>$lastname</td><td>$email</td><td>$new_password</td><td>{$types[$usertype]}</td></tr>";

}
?></table>