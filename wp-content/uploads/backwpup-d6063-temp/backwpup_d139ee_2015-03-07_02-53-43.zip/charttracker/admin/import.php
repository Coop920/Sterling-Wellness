<?

if(count($_FILES)>0)
{
	set_time_limit(900);
	if($_FILES['contact']['tmp_name']!=""
		&& $_FILES['computed']['tmp_name']!=""
		&& $_FILES['pwp']['tmp_name']!=""
		&& $_FILES['shared']['tmp_name']!=""
		&& $_FILES['supplemental']['tmp_name']!=""
		)
		{
			$id=0;
			import_hra($_FILES['contact']['tmp_name'],$id);
			import_hra($_FILES['computed']['tmp_name'],$id);
			import_hra($_FILES['pwp']['tmp_name'],$id);
			import_hra($_FILES['shared']['tmp_name'],$id);
			import_hra($_FILES['supplemental']['tmp_name'],$id);

			if( !isset( $GLOBALS['fulldata'] ) ) $GLOBALS['fulldata'] = array();

			#Get the DB fields to check to make sure we only try to insert fields that actually exist
			$valid_fields = array();
			$query = "SHOW COLUMNS FROM `ct_hra`";
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			while( $row = mysql_fetch_array($result, MYSQL_ASSOC) )
			{
//				extract( $row );
				$valid_fields[] = $row['Field'];
			}

			$records2import = count( $GLOBALS['fulldata'] );

			/*echo "total: " . $total_fields;
			mail("brett@fireflydigital.com","total: " . $total_fields,"test");
			flush();*/

			#Loop through to make sure only existing fields are there, then build the query
			$total=0;
			$query_stuff = array();
			foreach( $GLOBALS['fulldata'] as $key => $val )
			{
				$insert_query = array();

				if( (isset( $val['ClientID'])) && ($val['ClientID']) && ($val['ClientID'] != 'ClientID') )
				{
					$fields = array();
					$vals = array();
					$val['ClientID'] = trim( str_replace( "-", "", $val['ClientID'] ) );
					$val['import_date'] = date("Y-m-d");

					foreach($val as $key2 => $val2)
					{
						//if(in_array($key2,$valid_fields)) $insert_query[] = "`$key2`='".addslashes($val2)."'";
// TODO remove starting and trailing spaces ( may need to remove it in db also )

						if( in_array( $key2, $valid_fields ) )
						{
							$fields[] = $key2;
							$vals[] = addslashes( $val2 );
						}
					}

					$query_stuff[] = "('" . implode( "','", $vals ) . "')";

					$total += 1;

					if( count( $query_stuff ) > 29 )
					{
						$query  = "INSERT INTO `ct_hra` (`";
						$query .= implode("`,`",$fields);
						$query .= "`) VALUES ";
						$query .= implode("
						,",$query_stuff);

						mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

						$updated = mysql_affected_rows();

						//mail("brett@fireflydigital.com","STERLING TEST: $total / $total_fields Updated: $updated",$query . "\n" . $total . " / " . $total_fields . "\n\n");

						$query_stuff = array();
					}
					set_time_limit(600);

				}
			}

			if( is_array($query_stuff) && count( $query_stuff ) )
			{
				$query  = "INSERT INTO `ct_hra` (`";
				$query .= implode("`,`",$fields);
				$query .= "`) VALUES ";
				$query .= implode("
				,",$query_stuff);

				mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

				$updated = mysql_affected_rows();

			}






			$message = "Imported $total HREs.<br>";

			$start = mktime();
			//mail("brett@fireflydigital.com","STERLING TEST: Starting matching",$start);

			set_time_limit(6000);

			//set user_id in ct_hra. Linking with ct_labcorp_pid will be done in match.php manualy
			//linking with ct_labcorp_pid can not be done automaticaly TODO describe why
			//user_id is set with assumption that field ClientId holds id value from table ct_users ( PID )

			//first unset nonexisting user_id
			$query=
				'UPDATE ct_hra
					SET ct_hra.user_id=\'\'
					WHERE ct_hra.user_id <> \'\'
					AND (ct_hra.user_id NOT IN (
						SELECT id
						FROM ct_users
					)
				)';
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			$message .= 'Found '.(mysql_affected_rows()+0) . 'nonexisting users.<br>';

			$query=
				'UPDATE ct_hra, ct_users
				SET ct_hra.user_id=ct_hra.ClientID
				WHERE ct_hra.user_id = \'\'
				AND ct_hra.ClientID=ct_users.id
				AND ct_hra.FirstName <> \'\'
				AND ct_hra.FirstName = ct_users.FirstName
				AND ct_hra.LastName <> \'\'
				AND ct_hra.LastName = ct_users.LastName';
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			$message .= (mysql_affected_rows()+0) . " HRA users were set by ClientID.<br>";

			// set user info from hra
			$query = '
				UPDATE ct_hra h, ct_users u
				SET
				  u.email = IFNULL( IF( u.email <> \'\', u.email, h.EMail ), \'\' ),
				  u.address=IFNULL( IF( u.address <> \'\', u.address, h.Address ), \'\'),
				  u.city=IFNULL( IF( u.city <> \'\', u.city, h.City ), \'\'),
				  u.state=IFNULL( IF( u.state <> \'\', u.state, h.State ), \'\'),
				  u.zip=IFNULL( IF( u.zip <> \'\', u.zip, h.ZipCode ), \'\'),
				  u.phone1=IFNULL( IF( u.phone1 <> \'\', u.phone1, h.Phone ), \'\'),
				  u.phone2=IFNULL( IF( u.phone2 <> \'\', u.phone2, h.Phone2 ), \'\'),
				  u.dob=IFNULL( IF( u.dob <> \'\', u.dob, h.BirthDate ), \'\'),
				  u.zip=IFNULL( IF( u.zip <> \'\', u.zip, h.ZipCode ), \'\')
				WHERE h.user_id = u.id
				  AND u.usertype = \'5\'
				  AND(
				  	IFNULL( u.email = \'\', 1 )
				  	OR IFNULL( u.address = \'\', 1 )
				  	OR IFNULL( u.city = \'\', 1 )
				  	OR IFNULL( u.state = \'\', 1 )
				  	OR IFNULL( u.zip = \'\', 1 )
				  	OR IFNULL( u.phone1 = \'\', 1 )
				  	OR IFNULL( u.phone2 = \'\', 1 )
				  	OR IFNULL( u.dob = \'\', 1 )
				  	OR IFNULL( u.zip = \'\', 1 )
				  )
			';
			/*
			#Connect them by SSN
		  	$query = "UPDATE ct_hra,ct_labcorp_pid SET ct_hra.labcorp_id=ct_labcorp_pid.id WHERE ct_labcorp_pid.ssn=ct_hra.ClientId AND ct_hra.labcorp_id IS NULL";
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			$message .= (mysql_affected_rows()+0) . " HRAs were matched to existing Labcorps by PID.<br>";

			$query = "UPDATE ct_hra,ct_labcorp_pid SET ct_labcorp_pid.hra_id=ct_hra.id WHERE ct_hra.labcorp_id=ct_labcorp_pid.id";
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			$message .= (mysql_affected_rows()+0) . " Labcorps were updated.<br>";

			*/

			$end = mktime();
			//mail("brett@fireflydigital.com","STERLING TEST: Finished matching",($end-$start) . " Seconds");
			//mail("gmehal@sterling-wellness.com","STERLING TEST: Finished matching HRAs",($end-$start) . " Seconds");


		}
		else
		{
			$message = "IMPORT FAILED: Please upload all 5 files at the same time.";
		}
}

$query='
SELECT COUNT(*) labcorps
FROM ct_labcorp_pid
WHERE ( hra_id IS NULL
OR hra_id = 0)
AND ( nohra IS NULL
OR nohra = 0 )
';
$result=mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
$labcorps_count=mysql_fetch_array( $result, MYSQL_ASSOC );
if( $labcorps_count ) $labcorps_count=$labcorps_count['labcorps'];

$query='
SELECT COUNT(*) hras
FROM ct_hra
WHERE ( labcorp_id IS NULL
OR labcorp_id = 0)
AND ( nolab IS NULL
OR nolab = 0 )
';
$result=mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
$hras_count=mysql_fetch_array( $result, MYSQL_ASSOC );
if( $hras_count ) $hras_count=$hras_count['hras'];
?>
<?php if( $labcorps_count || $hras_count ) { ?>
<center>
There are HRAs(<?php echo( $hras_count ); ?>) and LabCorps(<?php echo( $labcorps_count ); ?>) not linked together. Please, press "Match Imports" to link they together.
</center>
<?php } ?>
<center>
<form action="index.php?page=import" enctype="multipart/form-data" method="POST">
<table cellspacing="0" cellpadding="4" style="border: 1px #D2D3CD solid;">
	<tr style="background:#E3E4DE;">
		<td width="20"><img src='util/images/import.png' border="0"></td>
		<td><span id="page_head">HRA Import</span></td>
	</tr>
		<tr><Td class="system_message" colspan="2"><?= $message ?></Td></tr>
		<tr><td align="right">Contact:</td><td><input type="file" name="contact"></td></tr>
		<tr><td align="right">Computed:</td><td><input type="file" name="computed"></td></tr>
		<tr><td align="right">PWP:</td><td><input type="file" name="pwp"></td></tr>
		<tr><td align="right">Shared:</td><td><input type="file" name="shared"></td></tr>
		<tr><td align="right">Supplemental:</td><td><input type="file" name="supplemental"></td></tr>
		<tr><td colspan="2" align="center"><input type="submit" class="button" value="Import Files">&nbsp;<input type="button" class="button" value="Match Imports" onClick="document.location='index.php?page=match'"></tr>
</table>
</form></center>