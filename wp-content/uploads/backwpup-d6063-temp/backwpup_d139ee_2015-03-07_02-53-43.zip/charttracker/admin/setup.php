<?php
	if($_GET['message'])
	{
?>
<center class="system_message"><?= $_GET['message'] ?></center>
<?php
	}
?>
<table cellpadding="0" cellspacing="0" width="100%">
	<tr>
		<td><img src="/images/spacer.gif" width="15" height="1"></td>
		<td valign="top" width="50%" style="border: 1px #D2D3CD solid;">
			<table cellspacing="0" cellpadding="5" width="100%">
				<tr style="background:#E3E4DE;">
					<td width="20"><a href="index.php?page=options"><img src='util/images/menuitem.png' border="0"></a></td>
					<td><span id="page_head">Dropdown Options</span></td>
				</tr>
				<tr>
					<td colspan="2" class="row-1 pushleft"><a href="index.php?page=options&opt=rsp">Physician/Nurse Responses</a></td>
				</tr>
				<tr>
					<td colspan="2" class="row1 pushleft"><a href="index.php?page=options&opt=prs">Prescriptions</a></td>
				</tr>
				<tr>
					<td colspan="2" class="row-1 pushleft"><a href="index.php?page=options&opt=rfr">Reasons for Referral</a></td>
				</tr>
				<tr>
					<td colspan="2" class="row1 pushleft"><a href="index.php?page=options&opt=rec">Recommendations</a></td>
				</tr>
			</table>
		</td>
		<td><img src="/images/spacer.gif" width="15" height="1"></td>
		<td valign="top" width="50%" style="border: 1px #D2D3CD solid;">
			<table cellspacing="0" cellpadding="5" width="100%">
				<tr style="background:#E3E4DE;">
					<td width="20"><a href="index.php?page=content"><img src='util/images/editcontent.png' border="0"></a></td>
					<td><span id="page_head">Entry Page Content</span></td>
				</tr>
				<tr>
					<td colspan="2" class="row-1 pushleft"><a href="index.php?page=content&opt=admn">Admin</a></td>
				</tr>
				<tr>
					<td colspan="2" class="row1 pushleft"><a href="index.php?page=content&opt=phys">Physician</a></td>
				</tr>
				<tr>
					<td colspan="2" class="row-1 pushleft"><a href="index.php?page=content&opt=cons">Consultant</a></td>
				</tr>
				<tr>
					<td colspan="2" class="row1 pushleft"><a href="index.php?page=content&opt=clnt">Client</a></td>
				</tr>
				<tr>
					<td colspan="2" class="row-1 pushleft"><a href="index.php?page=content&opt=ptnt">Participant</a></td>
				</tr>
			</table>
		</td>
		<td><img src="/images/spacer.gif" width="15" height="1"></td>
	</tr>
</table>