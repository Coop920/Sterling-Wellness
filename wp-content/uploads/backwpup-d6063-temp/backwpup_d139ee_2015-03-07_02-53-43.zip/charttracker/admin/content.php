<?
$pages = array(
	"admn"=>"Admin",
	"phys"=>"Physician",
	"cons"=>"Consultant",
	"clnt"=>"Client",
	"ptnt"=>"Participant",
	);

if(count($_POST)>1)
{
	$query = "UPDATE ct_content SET content='{$_POST['content']}' WHERE page='{$_POST['the_page']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	header("Location: index.php?page=setup&message={$pages[$_POST['the_page']]} welcome screen has been updated.");
}

$query = "SELECT * FROM ct_content WHERE page='{$_GET['opt']}'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

?>
<form action="index.php?page=content" method="POST">
<input type="hidden" name="the_page" value="<?= $_GET['opt'] ?>">
<span id="page_head"><?= $pages[$_GET['opt']] ?> Welcome Screen</span>

<script language="javascript" type="text/javascript" src="../control/tinymce/jscripts/tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
	tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		plugins : "table,save,advhr,advimage,advlink,iespell,insertdatetime,preview,zoom,searchreplace,print,contextmenu,paste",
		theme_advanced_buttons1_add_before : "save,separator",
		theme_advanced_buttons1_add : "spacer,fontselect,spacer,fontsizeselect",
		theme_advanced_buttons2_add : "print",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,iespell,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "insertdate,inserttime,advhr,separator,spacer,zoom,spacer,preview",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_path_location : "bottom",
		content_css : "../../styles.css",
	    plugin_insertdate_dateFormat : "%Y-%m-%d",
	    plugin_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		external_link_list_url : "example_data/example_link_list.js",
		external_image_list_url : "example_data/example_image_list.js",
		flash_external_list_url : "example_data/example_flash_list.js",
		file_browser_callback : "mcFileManager.filebrowserCallBack",
		theme_advanced_resize_horizontal : false,
		theme_advanced_resizing : true
	});
</script>

<textarea id="contentid" name="content" rows="25" style="width:93%;color:#FFFFFF;"><?= $content ?></textarea>
<br><input type="submit" value="Save Content" class="button">
</form>