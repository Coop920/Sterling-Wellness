<?php
require_once("global.php");

#make sure they're logged in
check_auth();
#extra check... no one, under any circumstance can see this unless they're an admin
if($GLOBALS['user_data']['usertype']!=1)
die("You do not have permission to view this page. Please log in.");


$test_name = $history_types[ $test_type ];
if( $test_type == 'upload' ) {
	$query = '
		SELECT *
		FROM ct_uploads
		WHERE id = "'.$test_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$row=mysql_fetch_array( $result, MYSQL_ASSOC );
	if( $row )
	{
		$test_name = (string) $row['file_desc'];
	}
}

?>
You select linking <b><?php echo( $test_name ); ?></b> from <b><?php echo( $user_name );?>&nbsp;(&nbsp;PID:&nbsp;<?php echo( $user_PID );?>&nbsp;)</b> to another user.<br>
Please click on user to which you want to link this <b><?php echo( $test_name );?></b>. You can select only <b>Active Participants</b>.
<br><br>
<?php
$s=''; // search string
if( isset( $_REQUEST['s'] ) && $_REQUEST['s'] ) {
	$s = (string) $_REQUEST['s'];
}

$query_count = '
	SELECT count(*) i
	FROM ct_users user
	LEFT JOIN ct_users company 
		ON user.company = company.id
		AND company.usertype = "4"
	WHERE user.usertype = "5"
	AND user.id <> '.$user_id.'
	AND user.active=1
';

$query = '
	SELECT user.id id, user.firstname firstname, user.lastname lastname, user.email email, company.company company
	FROM ct_users user
	LEFT JOIN ct_users company 
		ON user.company = company.id
		AND company.usertype = "4"
	WHERE user.usertype = "5"
	AND user.id <> '.$user_id.'
	AND user.active=1
';
if( $s ) {
	$query_count .= '
		AND CONCAT_WS( " ", CAST( user.id AS CHAR ), user.firstname, user.lastname, user.email, company.company ) LIKE "%'.$s.'%" 
	';
	$query .= '
		AND CONCAT_WS( " ", CAST( user.id AS CHAR ), user.firstname, user.lastname, user.email, company.company ) LIKE "%'.$s.'%" 
	';
}
$query .= '
	ORDER BY user.lastname, user.firstname, user.id
';


$result = mysql_query($query_count) or mysql_error_handler($query_count, $PHP_SELF);
$row = mysql_fetch_array( $result, MYSQL_ASSOC );
$total = $row['i'];  

if( isset($_REQUEST['start']) && $_REQUEST['start'] ) $start = (int) $_REQUEST['start'];
else $start = 0;
$users_per_page = 20;

if( $total > ($start + $users_per_page) ) {
	$next = '<a href="#" onClick="JavaScript: list_users_from( ' . ($start+$users_per_page) . ' );" >next&nbsp;&gt;&gt;</a>';
} else {
	$next = '';
}

if( $start > 0 ) {
	$prev = '<a href="#" onClick="JavaScript: list_users_from( '.($start-$users_per_page).')">&lt;&lt;prev</a>';
} else {
	$prev = '';
}

$showing = 'Showing '. ($start+1) .' to '. min($total,$start+$users_per_page) . ' of '. $total;

?>
<script type='text/JavaScript'>
function link_to_user( new_user_id ) {
	var form = document.getElementById( 'form_link_user' );
	var i_new_user = document.getElementById( 'test_new_user_id' );
	if( !confirm('Are you sure to link to this user?') ) {
		return false;
	}
	if( form && i_new_user ) {
		i_new_user.value = new_user_id;
		form.submit();
	}
}

function list_users_from( start ) {
	var form = document.getElementById( 'form_link_user' );
	var i_start = document.getElementById( 'list_users_from' );
	if( form && i_start ) {
		i_start.value = start;
		form.submit();
	}
}

function cancel_linking() {
	var form = document.getElementById( 'form_link_user' );
	var i_action = document.getElementById( 'form_test_action' );
	if( form && i_action ) {
		i_action.value = '';
		form.submit();
	}
}
</script>
<form method='POST' action='' id='form_link_user'>
<input type='hidden' name='page' value='history_edit' >
<input type='hidden' name='user_id' value='<?php echo( $user_id ); ?>'>
<input type='hidden' name='test_new_user_id' value='' id='test_new_user_id'>
<input type='hidden' name='test_type' value='<?php echo( $test_type ); ?>'>
<input type='hidden' name='test_id' value='<?php echo( $test_id ); ?>' >
<input type='hidden' name='action' value='link' id='form_test_action'>
<input type='hidden' name='start' value='0' id='list_users_from' >
<table id="search_table" class="disp_table">
	<tr>
		<td valign="middle" width="20%" nowrap><b>Search</b> <input type="text" name="s" value="<?php echo( $s ); ?>" class="textbox search"></td>
		<td valign="middle"><input type="image" name="submit" src="util/images/magnify2.png"></td>
	</tr>
</table>
<br>
<table id="list_table" class="disp_table" width="100%" cellspacing="1" cellpadding="0" border="0">
<tr>
<th>PID</th>
<th>Name</th>
<th>e-mail</th>
<th>Company</th>
</tr>
<?php
$query .= '
	LIMIT '.$start.', '.$users_per_page.'
';

// echo $query;

$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

$row_styles = array(
	0 => 'row-1',
	1 => 'row1'
);

$row_par = 0;
while( $row = mysql_fetch_array( $result, MYSQL_ASSOC ) ) {
	$id = (int) $row['id'];
	$PID = (string) $row['id'];
	$name = (string) $row['lastname'].' '.(string) $row['firstname'];
	$email = (string) $row['email'];
	$company = (string) $row['company'];
	
?>
	<tr class='<?php echo( $row_styles[$row_par] ); ?>' style='cursor:pointer;cursor:hand' onmouseover="this.className='rowover'" onmouseout="this.className='<?php echo( $row_styles[$row_par] ); ?>'" onClick="JavaScript: link_to_user('<?php echo( $id ); ?>')" >
		<td><?php echo( $PID ); ?></td>
		<td><?php echo( $name ); ?></td>
		<td><?php echo( $email ); ?></td>
		<td><?php echo( $company ); ?></td>
	</tr>
<?php 
	if( $row_par ) $row_par = 0;
	else $row_par = 1; 
} 
?>
</table>
<table width='100%'>
<tr>
<td align='left' width='30%' ><?php echo( $prev ); ?></td>
<td align='center' width='40%'><?php echo( $showing ); ?></td>
<td align='right' width='30%'><?php echo( $next ); ?></td>
</tr>
<tr>
<td colspan='3' align='center'>
<input align='middle' type="submit" class="button" style="width:75px" value="Cancel" onClick="JavaScript: cancel_linking();">
</td>
</tr>
</table>
</form>
