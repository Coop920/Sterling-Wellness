<?
/*User Reports
The site administrator will also have the ability to receive reports regarding each user on
the site.  In the User Management panel a list of Site Users will be provided to the
Administrator by Group: Health Consultant, Field Consultant, etc.  The Administrator will be able to
click on a User Name and receive the following data:

� Last Log In
� Assigned Clients
� Items Due (if Any)
� Reports Completed (Health Consultant Specifically)
*/

			ob_start();
			?>
				<div><a href="index.php?page=<?= $_GET['page'] ?>">Show All</a></div>
				<div><a href="index.php?page=<?= $_GET['page'] ?>&type=2">Health Consultant</a></div>
				<div><a href="index.php?page=<?= $_GET['page'] ?>&type=3">Field Consultants</a></div>
				<div><a href="index.php?page=creports">Clients</a></div>
			<?php
				$subnav = ob_get_contents();
			ob_end_clean();



if($_GET['id']>0)
{
		$usertypes = array(2=>"Health Consultant",3=>"Field Consultant");

		$query = "SELECT *,IF(`lastlogin`='0000-00-00 00:00:00','never',DATE_FORMAT(`lastlogin`,'%m-%d-%Y')) date_fmt FROM ct_users WHERE id='{$_GET['id']}'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

		?>

		<table align="center" id='list_table' class='disp_table' cellpadding="4" width="100%">
			<tr>
				<th colspan="4"><h3><?= $usertypes[$usertype] ?> Information</h3></th>
			</tr>

			<tr class="row-1">
				<td align="right"><b>Name</b></td>
				<td><?= $firstname ?> <?= $lastname ?></td>
				<td align="right"><b>Practice</b></td>
				<td><?= $company ?></td>
				</tr>
			<tr class="row-1"><td align="right"><b>Email</b></td>
				<td><?= $email ?></td>

				<td align="right"><b>Last Login</b></td>
				<td><?= $date_fmt ?></i></td>
				<!--<td align="right"><b>Status</b></td>
				<td><?= $active?"Active":"" ?></td>-->

			</tr>

			<tr class="row-1">
				<th colspan="4"><h3>Assigned Clients</h3></th>
			</tr>
			<tr class="row-1">
				<td colspan="4">

					<?
					if($usertype==2)
					{
						$assigned = array();
						$query = "SELECT company FROM ct_assigned_users,ct_users WHERE ct_users.id=ct_assigned_users.client AND ct_assigned_users.user = '{$_GET['id']}'";
						$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
						while($row = mysql_fetch_array($result, MYSQL_ASSOC))
						{
							extract($row);
							echo "$company<br>";
						}
					}
					else
					{
						$query = "SELECT company FROM ct_assigned_consultants,ct_users WHERE ct_users.id=ct_assigned_consultants.client AND ct_assigned_consultants.user = '{$_GET['id']}'";
						$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
						while($row = mysql_fetch_array($result, MYSQL_ASSOC))
						{
							extract($row);
							echo "$company<br>";
						}
					}
					?>



				</td>
			</tr>

			<tr>
				<th colspan="4"><h3>Items Due</h3></th>
			</tr>
			<tr class="row-1">
				<td colspan="4">
				<?
				if($usertype==2)
					{
						?>
						<p>&nbsp;&nbsp;&nbsp;<b>Notifications Needed: </b>
						<?
						$query = "SELECT patient.firstname,patient.lastname,ct_labcorp_pid.import_date,ct_labcorp_pid.id
									FROM ct_labcorp_pid,ct_users company, ct_users patient,ct_assigned_users
						 	 		WHERE ct_labcorp_pid.ct_sws_id=patient.id
						 	 			AND patient.company=company.id
						 	 			AND company.id=ct_assigned_users.client
						 	 			AND ct_labcorp_pid.hra_id IS NOT NULL
						 	 			AND ct_labcorp_pid.notification_id IS NULL
						 	 			AND ct_assigned_users.user = '{$_GET['id']}'
									";
						$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
						echo (mysql_num_rows($result)+0);
						?>
						</p><p>&nbsp;&nbsp;&nbsp;<b>Followups Needed: </b>
						<?

						$query = "SELECT * FROM ct_lab_results, ct_labcorp_pid WHERE ct_lab_results.labcorp_id = ct_labcorp_pid.id AND physician='{$_GET['id']}'";
						$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
						echo (mysql_num_rows($result)+0);

						?>
						</p><p>&nbsp;&nbsp;&nbsp;<b>Additional Followups: </b>
						<?
						$query = "SELECT * FROM ct_labcorp_pid, ct_followups
							  WHERE ct_labcorp_pid.id = ct_followups.pid_id AND ct_followups.physician='{$_GET['id']}'";
						$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
						echo (mysql_num_rows($result)+0) . "</p>";

					}
					else
					{

					}
				?>
				</td>
			</tr>

			<tr>
				<th colspan="4"><h3>Reports Completed</h3></th>
			</tr>
			<tr colspan="4" class="row-1">
				<td colspan="4">
					<?
						if($usertype==2)
						{
							$query = "SELECT * FROM ct_lab_results WHERE physician='{$_GET['id']}'";
								$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
								echo "<p>&nbsp;&nbsp;&nbsp;<b>Lab Result Notifications: </b>" . (mysql_num_rows($result)+0) . "</p>";

							$query = "SELECT * FROM ct_followups WHERE physician='{$_GET['id']}'";
								$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
								echo "<p>&nbsp;&nbsp;&nbsp;<b>Followups: </b>" . (mysql_num_rows($result)+0) . "</p>";

						}
						else
						{
							$query = "SELECT * FROM ct_assessments WHERE physician='{$_GET['id']}'";
								$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
								echo "<p>&nbsp;&nbsp;&nbsp;<b>Health Assesments: </b>" . (mysql_num_rows($result)+0) . "</p>";
						}

					?>
				</td>
			</tr>
		</table>


		<?


}
else
{
	?>
	<table align="center" width="100%">
		<?php
			if($_GET['message'])
			{
		?>
		<tr>
			<Td class="system_message" colspan="2"><?= $_GET['message'] ?></Td>
		</tr>
		<?php
			}
		?>
		<tr>
			<td>



			</td>
		</tr>
		<tr>
			<td><form action="index.php?page=users" method="GET">
			<input type='hidden' name='page' value='<?= $_GET['page'] ?>'>
			<input type='hidden' name='type' value='<?= $_GET['type'] ?>'>
				<table id="search_table" class="disp_table">
					<tr>
						<td nowrap><b>Search</b> <input type="text" name="s" value="<?= $_GET['s'] ?>" class="textbox search"></td>
						<td><input type="image" name="submit" src="util/images/magnify2.png"></td>
						<td width="100%"></td>
					</tr>
				</table>
			</td></form>
		</tr>
		<tr>
			<td>
				<table id="list_table" class="disp_table" width="100%" cellspacing="1" cellpadding="3" border="0">
				<tr>
					<th>User Name</th>
					<th>Company</th>
				</tr>
				<?
				$i=1;
				$query = "SELECT *,concat(`lastname`,', ',`firstname`) name_fmt FROM ct_users WHERE active=1 AND ";
				if($_GET['type']!="") $query .= " usertype = '{$_GET['type']}'";
				else  $query .= " usertype IN ('2','3')";
				if($_GET['s']!="") $query .= " AND (
													firstname LIKE('%{$_GET['s']}%')
												OR
													lastname LIKE('%{$_GET['s']}%')
												OR
													CONCAT(`firstname`,' ',`lastname`) LIKE('%{$_GET['s']}%')
												OR
													CONCAT(`lastname`,', ',`firstname`) LIKE('%{$_GET['s']}%')
												OR
													email LIKE('%{$_GET['s']}%')
												OR
													company LIKE('%{$_GET['s']}%')
												)";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					extract($row);
					?>
					<tr class="row<?= $i*=-1 ?>">
						<td><a href="index.php?page=<?= $page ?>&id=<?= $id ?>&returntype=<?= $_GET['type'] ?>"><?= $name_fmt ?></a></td>
						<td><?= $company ?></td>
					</tr>
					<?
				}
				?>
				</table>
			</td>
		</tr>

	</table>
	<?
}


?>