<?
/*
The administrator will have the ability to manage certain drop down options throughout the
database.   The area for managing options will be an add/edit/deactivate interface for the
following items:

� Physician/Nurse Responses � Notification of Medical Results Report
� Prescription Options � Areas TBD by SWS
� Recommendations � Health Assessment Form
*/

#Extra steps for security reasons.  Doesn't let user manipulate which table is chosen
switch($_GET['opt'].$_POST['opt'])
{
case "prs": $table="ct_option_prs";$title="Prescriptions";break;
case "rec": $table="ct_option_rec";$title="Reccomendations";break;
case "rfr": $table="ct_option_rfr";$title="Reasons for Referral";break;
default: $table="ct_option_rsp";$title="Physician/Nurse Responses";break;
}


if($_POST['n']!="")
{
	$query = "INSERT INTO $table VALUES ('','{$_POST['n']}','1')";
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$message = "<b>{$_POST['n']}</b> has been added.";
	header("Location: index.php?page=options&opt={$_POST['opt']}&message=$message");
}
elseif ($_POST['delete']=="Delete")
{
	$query = "UPDATE $table SET active=0 WHERE id = '{$_POST['id']}' LIMIT 1";
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$message = "Option has been deleted.";
	header("Location: index.php?page=options&opt={$_POST['opt']}&message=$message");
}
elseif ($_POST['id']>0)
{
	$query = "UPDATE $table SET `text`='{$_POST['text']}' WHERE id = '{$_POST['id']}' LIMIT 1";
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$message = "Option has been edited.";
	header("Location: index.php?page=options&opt={$_POST['opt']}&message=$message");
}


?>
<body onload="document.getElementById('n').focus()">
<table align="center">
	<tr>
		<Td class="system_message" colspan="2"><?= $_GET['message'] ?></Td>
	</tr>
	<tr>
		<td>

		<?
		ob_start();
		?>
			<div><a href="index.php?page=<?= $_GET['page'] ?>&opt=rsp">Physician/Nurse Responses</a></div>
			<div><a href="index.php?page=<?= $_GET['page'] ?>&opt=prs">Prescriptions</a></div>
			<div><a href="index.php?page=<?= $_GET['page'] ?>&opt=rec">Reccomendations</a></div>

		<?php
		$subnav = ob_get_contents();
		ob_end_clean();
		?>

		</td>
	</tr>
	<tr>
	<td>
	<form action="index.php?page=options" method="POST">
			<input type='hidden' name='page' value='<?= $_GET['page'] ?>'>
			<input type='hidden' name='opt' value='<?= $_GET['opt'] ?>'>
				<table id="search_table" class="disp_table">
					<tr>
						<td>New Option <input type="text" name="n" value="<?= $_GET['s'] ?>" id="n" class="textbox new">&nbsp;<input type="image" src="util/images/comment_new.gif"></td>
						<td align="right"><?= $_GET['type']>0?"<a href='index.php?page=options&new=1&returntype={$_GET['type']}'>+add new ".strtolower($GLOBALS['user_types'][$_GET['type']])."</a>":"" ?></td>
					</tr>
				</table>
			</td></form>
	</tr>
		<tr>
			<td>
			<table id="list_table" class="disp_table">
					<tr>
						<th><?= $title ?></th>
					</tr>
					<?
					$i=1;
					$query = "SELECT * FROM $table WHERE active =1 ORDER BY text";
					$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
					while($row = mysql_fetch_array($result, MYSQL_ASSOC))
					{
						extract($row);
						?>
						<tr class="row<?= $i*=-1 ?>">
							<td><?= display_hidden_form($id,$text); ?></td></form>
						</tr>
						<?
					}
					?>
				</table>
			</td>
		</tr>
</table>
<script>
function visi(nr)
{
	if (document.layers)
	{
		current = (document.layers[nr].display == 'none') ? 'block' : 'none';
		document.layers[nr].display = current;
	}
	else if (document.all)
	{
		current = (document.all[nr].style.display == 'none') ? 'block' : 'none';
		document.all[nr].style.display = current;
	}
	else if (document.getElementById)
	{
		vista = (document.getElementById(nr).style.display == 'none') ? 'block' : 'none';
		document.getElementById(nr).style.display = vista;
	}

}
</script>
<?
function display_hidden_form($id,$text)
{
	?>
	<a href="#" onClick="this.innerHTML='';visi('form<?= $id ?>'); return false"><?= $text ?>&nbsp;</a>
	<form style="display:none;" id="form<?= $id ?>" action="index.php?page=options" method="POST">
	<input type="hidden" name="id" value="<?= $id ?>">
	<input type="hidden" name="opt" value="<?= $_GET['opt'] ?>">
	<input type="text" name="text" value="<?= $text ?>" class="edit">
	&nbsp;<input type="submit" value="Save" class="button">
	&nbsp;<input type="submit" value="Delete" class="button" name="delete">
	<?
}

?></body>