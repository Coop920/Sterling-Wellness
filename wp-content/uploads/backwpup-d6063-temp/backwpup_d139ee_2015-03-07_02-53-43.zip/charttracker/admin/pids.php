<center><form action="util/pdf/pids.php" method="POST">
<table>
	<tr>
		<td colspan="3">Number of PIDs to create:<br>
		<input type="text" value="<?= $_POST['number'] ?>" name="number" onKeyUp="this.value=this.value.replace(/\D/g,'');" class="textbox"><br>
		Company:<br>
		<select name="company" style="width:100%"><option></option>
			<?

				$query = "SELECT id,company FROM ct_users WHERE usertype = 4";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					extract($row);
					?><option value="<?= $id ?>" <?= $company==$id?"SELECTED":"" ?>><?= $company ?></option><?

				}
			?></select>
		</td></tr>
		<tr>
			<td>
			Labels per participant
			</td>
			<td align="right">
			<label><input type="radio" name="template" value="2">Two</label>&nbsp;
			<label><input type="radio" name="template" value="4" checked>Four</label>
			</td>
			<td>
			<input type="submit" value="Create">
			</td>
		</tr>
		</table>
</form></center>

