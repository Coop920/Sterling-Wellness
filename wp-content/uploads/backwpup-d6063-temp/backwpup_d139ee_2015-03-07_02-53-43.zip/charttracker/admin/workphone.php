<?
include ("../global.php");


$query = "SELECT phone1 FROM ct_users WHERE id = '{$_GET['company']}'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

echo $phone1;
?>