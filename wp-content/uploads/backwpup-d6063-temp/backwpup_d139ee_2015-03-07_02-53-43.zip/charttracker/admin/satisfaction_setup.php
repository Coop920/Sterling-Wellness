<?
if($_POST['post'])
{
	$query = "UPDATE ct_users SET `satis_survey` = 0 WHERE usertype = '4'";
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	if(is_array($_POST['companies']))
	{
		$query = "UPDATE ct_users SET `satis_survey` = 1 WHERE id IN(".implode(",",$_POST['companies']).") AND usertype = '4'";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	}
}
?>

<form action="index.php?page=satisfaction_setup" method="POST">
<input type="hidden" name="post" value="1">
<center>
<table cellspacing="0" cellpadding="5" width="300" align="center">
	<tr style="background:#E3E4DE;">
		<td width="20"><a href="index.php?page=options"><img src='util/images/menuitem.png' border="0"></a></td>
		<td><span id="page_head">Satisfaction Clients</span></td>
	</tr>
	<?
	$i=-1;
	$query = "SELECT * FROM ct_users WHERE usertype = '4'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		extract($row);
		?>
			<tr>
				<td colspan="2" class="row<?= ($i*=-1) ?> pushleft"><label><input type="checkbox" name="companies[]" value="<?= $id ?>" <?= $satis_survey?"CHECKED":"" ?>"><?= $company ?></label></td>
			</tr>
		<?
	}
?>
	<tr>
		<td align="center"><input type="submit" value="Save"></form></td>
	</tr>
</table>
</center>
