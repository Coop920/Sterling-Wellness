<?
/*

Notification of Medical Results Report
Once clicked, this area will show a list of participants flagged for review if they have a
LabCorp associated with an HRA but no existing Notification of Medical Results Report
for the LabCorp Date.

By clicking on a Participant Name the Physician will be able to view the Lab Corp Results and
HRA. They will then be able to generate a Notification of Medical Results Report.  This
report will be pre-populated with indicators from the Lab Corp Results.  The Notification
of Medical Results Report will include the following fields which will not be editable:

� Participant Name
� Date of Exam

The Notification of Medical Results Report will also have editable fields, which are
denoted in Appendix A.

*/
if($_POST['results_id'])
{

	$query = "UPDATE ct_lab_results SET
		`labcorp_id` = '{$_POST['labcorp_id']}',
		`physician` = '{$GLOBALS['user_data']['id']}',
	    `initial` = '{$_POST['initial']}',
	    `doc` = '{$_POST['doc_y']}-{$_POST['doc_m']}-{$_POST['doc_d']}',
	    `labs_sent` = '{$_POST['labs_sent']}',
	    `wait` = '{$_POST['wait']}',
	    `comments` = '{$_POST['comments']}',
	    `patient`='{$_POST['patient']}',
	    `checkboxes` = '".serialize($_POST['labs'])."'
	    WHERE id = '{$_POST['results_id']}' LIMIT 1
	    ";
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	header("Location: index.php?page=history&patient={$_POST['patient']}&test=Notification of Lab Results&id={$_POST['results_id']}");
}
else if($_GET['results_id']!="")
{
	$query = "SELECT *,date_format(`date`,'%m-%d-%Y') date, DATE_FORMAT(`doc`,'%m') doc_m, DATE_FORMAT(`doc`,'%d') doc_d, DATE_FORMAT(`doc`,'%Y') doc_y FROM `ct_lab_results` WHERE `id` = '{$_GET['results_id']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));


	$query = "SELECT *,DATE_FORMAT(`EntryDate`,'%m-%d-%Y') date_fmt, concat(`ct_users`.`lastname`,', ',`ct_users`.`firstname`) name_fmt, companies.company company_name , ct_labcorp_pid.id id

							FROM ct_hra,ct_labcorp_pid, ct_users
							LEFT JOIN `ct_users` companies ON (companies.id = ct_users.company)
							WHERE  ct_hra.labcorp_id = ct_labcorp_pid.id
								AND ct_labcorp_pid.ct_sws_id = ct_users.id
								AND ct_labcorp_pid.id = '$labcorp_id'
							ORDER BY EntryDate";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));






	?>
	<form action="index.php?page=results" method="POST">
	<input type="hidden" name="patient" value="<?= $ct_sws_id ?>">
	<input type="hidden" name="results_id" value="<?= $_GET['results_id'] ?>">
	<table align="center" width="100%">
		<tr>
			<td>
				<table id="form_table" width="100%">
					<tr>
						<th colspan="4">Participant Information</th>
					</tr>
					<tr>
						<tr>
						<td><b>Date:</b></td>
						<td><?= date("m-d-Y") ?></td>
					</tr>
					<tr>
						<td><b>Name:</b></td>
						<td><?= $name_fmt ?></td>
						<td><b>Phone:</b></td>
						<td><?= $phone1 ?></td>
					</tr>
					<tr>
						<td><b>Company:</b></td>
						<td><?= $company ?></td>
						<td><b>Sign:</b></td>
						<td><input type="checkbox" name="initial" value="1"></td>
					</tr>
				</table>
				<br>
				<table id="form_table" width="100%">
					<tr>
						<th colspan="4">Call-Back Information</th>
					</tr>
					<tr>
						<td><b>Date of Call:</b></td>
						<td>
							<input type="text" class="textbox_s" name="doc_m" value="<?= $doc_m ?>" size="2" maxlength="2" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==2) doc_d.focus()">/
							<input type="text" class="textbox_s" name="doc_d" value="<?= $doc_d ?>" size="2" maxlength="2" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==2) doc_y.focus()">/
							<input type="text" class="textbox_s" name="doc_y" value="<?= $doc_y ?>" size="4" maxlength="4" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==4) ssn_1.focus()">
						</td>
					</tr>
					<tr>
						<td><b>Labs sent via:</b></td>
						<td><select name="labs_sent">
								<option></option>
								<option value="m" <?= $labs_sent=="m"?"SELECTED":"" ?>>Mail</option>
								<option value="f" <?= $labs_sent=="f"?"SELECTED":"" ?>>Fax</option>
							</select>
							</td>
						<td colspan="2"><label><input type="checkbox" name="wait" value="1" <?= $wait?"CHECKED":"" ?>>Participant requested to wait for results.</label></td>
					</tr>
					<tr>
						<td><b>Comments/History:</b></td>
					</tr>
					<tr>
						<td colspan="4"><textarea name="comments" style="width:100%" rows="3"></textarea></td>
					</tr>
				</table>
				<br>
				<table id="form_table" width="100%">
					<tr>
						<th colspan="4">Wellness Panel</th>
					</tr>
				</table>
				<table width="100%">

					<?
					$checkboxes = unserialize($checkboxes);

					if(!is_array($checkboxes))

					$query = "SELECT *,id obr_id FROM ct_labcorp_obr WHERE pid='$id'";
					$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
					while($row = mysql_fetch_array($result, MYSQL_ASSOC))
					{
						extract($row);
						$i=1;
						$query2 = "SELECT *,id obx_id FROM ct_labcorp_obx WHERE obr='$obr_id'";
						$result2 = mysql_query($query2) or mysql_error_handler($query2, $PHP_SELF);
						while($row2 = mysql_fetch_array($result2, MYSQL_ASSOC))
						{
							extract($row2);
							?>
							<tr class="row<?= $i*=-1 ?>">

								<td><input type="checkbox" name="labs[<?= $id ?>]" value="1" <?= $checkboxes[$id]?"CHECKED":"" ?>><?= $observation_text ?></td>
								<td align="center"><?= $observation_results ?></td>
								<td align="center"><?= $abnormal_flags ?></td>
								<td align="center"><?= $units ?></td>
								<td align="center"><?= $reference ?></td>
								<td align="center"><?= $lab ?></td>
							</tr>

							<?

						}
					}
					?>

				</table>
			</td>
		</tr>
		<tr>
			<td align="center"><input type="submit" class="button" value="Save Notification"></td>
		</tr>
	</table></td></tr>
	</table>
	</form>

	<?
}
/*else if($_GET['id']!="")
{

	$query .= "SELECT *,DATE_FORMAT(`EntryDate`,'%m-%d-%Y') date_fmt, concat(`ct_users`.`lastname`,', ',`ct_users`.`firstname`) name_fmt, companies.company company_name , ct_labcorp_pid.id id
							FROM ct_hra,ct_labcorp_pid, ct_users
							LEFT JOIN `ct_users` companies ON (companies.id = ct_users.company)
							WHERE  ct_hra.labcorp_id = ct_labcorp_pid.id
								AND ct_labcorp_pid.ct_sws_id = ct_users.id
								AND ct_labcorp_pid.id = '{$_GET['id']}'
							ORDER BY EntryDate";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

		$doc_m = date("m");
		$doc_d = date("d");
		$doc_y = date("Y");

	?>
	<!-- Participant Information -->
	<form action="index.php?page=results" method="POST">
	<input type="hidden" name="labcorp_id" value="<?= $id ?>">
	<table align="center"><tr><td>
	<table align="center" width="100%">
		<tr>
			<td>
				<table id="form_table" width="100%">
					<tr>
						<th colspan="4">Participant Information</th>
					</tr>
					<tr>
						<td><b>Date:</b></td>
						<td><?= date("m-d-Y") ?></td>
					</tr>
					<tr>
						<td><b>Name:</b></td>
						<td><?= $name_fmt ?></td>
						<td><b>Phone:</b></td>
						<td><?= $phone1 ?></td>
					</tr>
					<tr>
						<td><b>Company:</b></td>
						<td><?= $company ?></td>
						<td><b>Sign:</b></td>
						<td><input type="checkbox" name="initial" value="1"></td>
					</tr>
				</table>
				<br>
				<table id="form_table" width="100%">
					<tr>
						<th colspan="4">Call-Back Information</th>
					</tr>
					<tr>
						<td><b>Date of Call:</b></td>
						<td>
							<input type="text" class="textbox_s" name="doc_m" value="<?= $doc_m ?>" size="2" maxlength="2" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==2) doc_d.focus()">/
							<input type="text" class="textbox_s" name="doc_d" value="<?= $doc_d ?>" size="2" maxlength="2" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==2) doc_y.focus()">/
							<input type="text" class="textbox_s" name="doc_y" value="<?= $doc_y ?>" size="4" maxlength="4" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==4) ssn_1.focus()">
						</td>
					</tr>
					<tr>
						<td><b>Labs sent via:</b></td>
						<td><select name="labs_sent">
								<option></option>
								<option value="m" <?= $labs_sent=="m"?"SELECTED":"" ?>>Mail</option>
								<option value="f" <?= $labs_sent=="f"?"SELECTED":"" ?>>Fax</option>
							</select>
							</td>
						<td colspan="2"><label><input type="checkbox" name="wait" value="1" <?= $wait?"CHECKED":"" ?>>Participant requested to wait for results.</label></td>
					</tr>
					<tr>
						<td><b>Comments/History:</b></td>
					</tr>
					<tr>
						<td colspan="4"><textarea name="comments" style="width:100%" rows="3"></textarea></td>
					</tr>
				</table>
				<br>
				<table id="form_table" width="100%">
					<tr>
						<th colspan="4">Wellness Panel</th>
					</tr>
				</table>
				<table width="100%">
					<? show_labcorp_form($id,false) ?>
				</table>
			</td>
		</tr>
		<tr>
			<td align="center"><input type="submit" class="button" value="Save Notification"></td>
		</tr>
	</table></td></tr>
	</table>
	</form>
	<?
}
else
{
	?>
	<table align="center" width="100%">
		<tr>
			<Td class="system_message" colspan="2"><?= $_GET['message'] ?></Td>
		</tr>
		<tr>
			<td><form action="index.php?page=users" method="GET">
			<input type='hidden' name='page' value='<?= $_GET['page'] ?>'>
			<input type='hidden' name='type' value='<?= $_GET['type'] ?>'>
				<table id="search_table" class="disp_table">
					<tr>
						<td nowrap><b>Search</b> <input type="text" name="s" value="<?= $_GET['s'] ?>" class="textbox search"></td>
						<td><input type="image" name="submit" src="util/images/magnify2.png"></td>
						<td width="100%">&nbsp;</td>
						<input type="hidden" name="stat" value="<?= $_GET['stat'] ?>">
					</tr>
				</table>
			</td></form>
		</tr>
		<tr>
			<td align="right"><a href="index.php?page=results&s=<?= $_GET['s'] ?>&stat=<?= $_GET['stat']?0:1 ?>">show <?= $_GET['stat']?"new only":"all" ?></a></td>
		</tr>
		<tr>
			<td>
				<table id="list_table" class="disp_table" width="100%" cellspacing="1" cellpadding="0" border="0">
				<tr>
					<th>First Name</th>
					<th>Last Name</th>
					<th colspan="2">Date</th>
				</tr>
				<?
				if(!$_GET['stat']) $new_only = "AND ct_lab_results.labcorp_id IS NULL";

				$i = -1;
				$query .= "SELECT *, ct_lab_results.id results_id, DATE_FORMAT(doc,'%m/%d/%Y') doc_f
							FROM ct_lab_results, ct_labcorp_pid
							WHERE ct_lab_results.labcorp_id = ct_labcorp_pid.id
							AND physician='{$GLOBALS['user_data']['id']}'
							ORDER BY doc";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					extract($row);
					?>
					<tr class="row<?= $i*=-1 ?>">
						<td><?= $firstname ?></td>
						<td><?= $lastname ?></td>
						<td align="center"><?= $doc_f ?></td>
						<td><a href='index.php?page=results&results_id=<?= $results_id ?>'>edit</a></td>
					</tr>
					<?
				}
				?>


				</table>
			</td>
		</tr>

	</table>
	</table>
	<?
}*/
?>