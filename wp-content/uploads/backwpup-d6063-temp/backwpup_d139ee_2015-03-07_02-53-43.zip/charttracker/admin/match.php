<?
if( !isset( $DEBUG ) ) {
	$DEBUG=false;
}

// returns error description on error
function link_hra2labcorp( $hra_id, $labcorp_id ) {
	if( (!$hra_id) && $labcorp_id ) { // make labcorp with nohra
		$query='
		UPDATE ct_labcorp_pid
		SET hra_id = NULL,
			nohra = 1
		WHERE id = \''.(int)$labcorp_id.'\'
		';
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		return '';
	}
	if( $hra_id && (!$labcorp_id) ) { // make hra with nolab
		$query='
		UPDATE ct_hra
		SET labcorp_id = NULL,
			nolab = 1
		WHERE id = \''.(int)$hra_id.'\'
		';
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		return '';
	}
	if( $hra_id && $labcorp_id ) {
		// make sure that labcorp exists
		$query='
		SELECT *
		FROM ct_labcorp_pid
		WHERE id=\''.(int)$labcorp_id.'\'
		';
		$result=mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		$labcorp=mysql_fetch_array( $result, MYSQL_ASSOC );
		if( !$labcorp ) return 'no LabCorp with id '.$labcorp_id;

		// make sure that hra exists
		$query='
		SELECT *
		FROM ct_hra
		WHERE id=\''.(int)$hra_id.'\'
		';
		$result=mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		$hra=mysql_fetch_array( $result, MYSQL_ASSOC );
		if( !$hra ) return 'no HRA with id '.$hra_id;

		$user_id=false;
		if( $labcorp['ct_sws_id'] || $hra['user_id'] ) { // either in one user is set
			if( $labcorp['ct_sws_id'] == $hra['user_id'] ) $user_id=$hra['user_id'];
			elseif( !$labcorp['ct_sws_id'] ) $user_id=$hra['user_id'];
			elseif( !$hra['user_id'] ) $user_id=$labcorp['ct_sws_id'];
			else return 'Users differ for LabCorp '.$labcorp_id.' and HRA '.$hra_id;
//			else $user_id=$labcorp['ct_sws_id']; // users are set but they differ. We trust LabCorp
		} else {
			return 'no user set neither for labcorp '.$labcorp_id.' nor for hra '.$hra_id;
		}
		$query='
		UPDATE ct_labcorp_pid
		SET hra_id = \''.(int)$hra_id.'\',
			nohra = NULL,
			ct_sws_id=\''.(int)$user_id.'\'
		WHERE id=\''.(int)$labcorp_id.'\'
		';
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		$query='
		UPDATE ct_hra
		SET labcorp_id = \''.(int)$labcorp_id.'\',
			nolab = NULL,
			user_id = \''.(int)$user_id.'\'
		WHERE id=\''.(int)$hra_id.'\'
		';
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		// set labcorp info from hra
		$query = '
			UPDATE ct_hra h, ct_labcorp_pid l
			SET
			  l.address=IFNULL( IF( l.address <> \'\', l.address, h.Address ), \'\'),
			  l.address2=IFNULL( IF( l.address2 <> \'\', l.address2, h.Address2 ), \'\'),
			  l.city=IFNULL( IF( l.city <> \'\', l.city, h.City ), \'\'),
			  l.state=IFNULL( IF( l.state <> \'\', l.state, h.State ), \'\'),
			  l.zip=IFNULL( IF( l.zip <> \'\', l.zip, h.ZipCode ), \'\'),
			  l.dob=IFNULL( IF( l.dob <> \'\', l.dob, h.BirthDate ), \'\')
			WHERE l.hra_id = h.id
				AND l.id = '.(int)$labcorp_id.'
			  AND(
			  	IFNULL( l.address = \'\', 1 )
			  	OR IFNULL( l.address2 = \'\', 1 )
			  	OR IFNULL( l.city = \'\', 1 )
			  	OR IFNULL( l.state = \'\', 1 )
			  	OR IFNULL( l.zip = \'\', 1 )
			  	OR IFNULL( l.dob = \'\', 1 )
			  )
		';
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		return '';
	}
	return 'called with no LabCorp and HRA ids';
}

$error_msg='';
if( isset($_REQUEST['suggests']) && $_REQUEST['suggests'] ) {
	foreach( $_REQUEST['suggests'] as $pair ) { // each pair has form Labcorp_id|Hra_id
		$arr=explode( '|', $pair );
		if( count( $arr ) != 2 ) {
			$error_msg.='suggested pair '.pair.' has wrong format<br>';
			continue;
		}
		$labcorp_id=trim( $arr[0] );
		$hra_id=trim( $arr[1] );
		if( $DEBUG ) echo( 'linking labcorp '.$labcorp_id.' with hra '.$hra_id.'<br>' );
		$ret=link_hra2labcorp( $hra_id, $labcorp_id );
		if( $ret ) $error_msg.=$ret.'<BR>';
	}
}

// lookup for user made suggestions.
if( isset( $_REQUEST['PIDS'] ) && $_REQUEST['PIDS'] ) {
	foreach( $_REQUEST['PIDS'] as $pid ){
		$sel='PID_'.$pid;
		if( isset( $_REQUEST[ $sel.'_LABCORP' ] ) && $_REQUEST[$sel.'_LABCORP'] ) {
			$labcorp_id=$_REQUEST[ $sel.'_LABCORP' ];
		} else {
			$error_msg.='Not found labcorp id for PID '.$pid.' <br>';
			continue;
		}
		if( isset( $_REQUEST[ $sel.'_HRA' ] ) && $_REQUEST[$sel.'_HRA'] ) {
			$hra_id=$_REQUEST[ $sel.'_HRA' ];
		} else {
			$error_msg.='Not found hra id for PID '.$pid.' <br>';
			continue;
		}
		if( $DEBUG ) echo( 'linking labcorp '.$labcorp_id.' with hra '.$hra_id.' for user '.$pid.'<br>' );
		$ret=link_hra2labcorp( $hra_id, $labcorp_id );
		if( $ret ) $error_msg.=$ret.'<BR>';
	}
}

if( isset( $_REQUEST['hra_id']) && $_REQUEST['hra_id'] && isset( $_REQUEST['labcorp_id'] ) && $_REQUEST['labcorp_id'] ) {
	$hra_id=trim( $_REQUEST['hra_id'] );
	$labcorp_id=trim( $_REQUEST['labcorp_id'] );
	if( $DEBUG ) echo( 'manually linking labcorp '.$labcorp_id.' with hra '.$hra_id.'<br>' );
	$ret=link_hra2labcorp( $hra_id, $labcorp_id );
	if( $ret ) $error_msg.=$ret.'<BR>';
}

if( isset( $_REQUEST['nolab'] ) && $_REQUEST['nolab'] ) {
	if( $DEBUG ) echo( 'making HRA '.trim($_REQUEST['nolab']).' as with nolab');
	$ret=link_hra2labcorp( trim($_REQUEST['nolab']), 0 );
	if( $ret ) $error_msg.=$ret.'<BR>';
}

if( isset( $_REQUEST['nohra'] ) && $_REQUEST['nohra'] ) {
	if( $DEBUG ) echo( 'making LabCorp '.trim($_REQUEST['nohra']).' as with nohra');
	$ret=link_hra2labcorp( 0, trim($_REQUEST['nohra']) );
	if( $ret ) $error_msg.=$ret.'<BR>';
}


?>
<?php
//get labcorps
$labcorps=array();
$labcorps_by_PID=array();
$query='
SELECT *, DATE_FORMAT(`import_date`,\'%m-%d-%Y\') import_date_f
FROM ct_labcorp_pid
WHERE ( hra_id IS NULL OR hra_id = 0 )
AND ( nohra IS NULL OR nohra = 0 )
ORDER BY lastname
';
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$labcorps[$row['id']]=$row;
	if( $row['ct_sws_id'] ) {
		$PID=trim( $row['ct_sws_id'] );
		if( !isset( $labcorps_by_PID[$PID] )) $labcorps_by_PID[$PID]=array(); // may have multiple records with the same PID
		$labcorps_by_PID[$PID][]=$row['id'];
	}
}

//get HRAs
$hras=array();
$hras_by_PID=array();
$query='
SELECT *, DATE_FORMAT(`import_date`,\'%m-%d-%Y\') import_date_f
FROM ct_hra
WHERE ( labcorp_id IS NULL OR labcorp_id = 0 )
AND ( nolab IS NULL OR nolab = 0 )
ORDER BY lastname
';
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
$no_suggestions=true;
while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$hras[$row['id']]=$row;
	if( $row['user_id'] ) {
		$PID=trim( $row['user_id'] );
		if( !isset( $hras_by_PID[$PID] )) $hras_by_PID[$PID] = array();
		$hras_by_PID[$PID][] = $row['id'];
		if( $no_suggestions && isset( $labcorps_by_PID[$PID] ) ) $no_suggestions = false;
	}
}
?>
<?php if( $error_msg ) { ?>
<div class='error_msg'>
<p>There are some errors while processing data</p>
<?php echo( $error_msg )?>
</div>
<?php } ?>
<?php if( $no_suggestions ) { //found no suggestion ?>
<p>Sorry, found no suggestions</p>
<?php } else { ?>
<form action="index.php?page=match" method="POST">
<table class="suggestions" >
<caption>Suggestions</caption>
<tr>
<th>O'k</th>
<th>Labcorp</th>
<th>HRA</th>
</tr>
<?php
foreach( $labcorps_by_PID as $PID => $labcorp_ids) {
	if( !isset( $hras_by_PID[$PID] ) ) continue; //no matching hra
	$hra_ids=$hras_by_PID[$PID];
	$labcorps_count=count( $labcorp_ids );
	$hras_count=count( $hra_ids );
	$rows = $labcorps_count > $hras_count ? $labcorps_count : $hras_count;
	if( ($labcorps_count == 1) && ($hras_count == 1) ) { // only one suggestion
		$labcorp=$labcorps[$labcorp_ids[0]];
		$hra=$hras[$hra_ids[0]];
?>
<tr>
<td>
<input type="checkbox" name='suggests[]' value='<?php echo($labcorp['id'].'|'.$hra['id']);?>' checked />
</td>
<td>
<span class='user'><?php echo( $labcorp['firstname'].'&nbsp;'.$labcorp['lastname'] ); ?></span>&nbsp;at&nbsp;<?php echo( $labcorp['import_date_f'] ); ?>
</td>
<td>
<span class='user'><?php echo( $hra['FirstName'].'&nbsp;'.$hra['LastName'] ); ?></span>&nbsp;at&nbsp;<?php echo( $hra['import_date_f'] ); ?>
</td>
</tr>
<?php
	} else { // one or both sides has multiple entries
		$control_name='PID_'.$PID;
?>
<tr>
<td>
<input type='checkbox' name='PIDS[]' value='<?php echo( $PID ); ?>' />
</td>
<td>
<ul>
<?php
foreach( $labcorp_ids as $labcorp_id ){
	$labcorp=$labcorps[$labcorp_id];
?>
<li><label><input type='radio' name='<?php echo( $control_name.'_LABCORP' );?>' value='<?php echo( $labcorp['id'] );?>' <?php echo( $labcorps_count == 1 ? 'checked' : '' ); ?> />
<span class='user'><?php echo( $labcorp['firstname'].'&nbsp;'.$labcorp['lastname'] ); ?></span>&nbsp;at&nbsp;<?php echo( $labcorp['import_date_f'] ); ?></label></li>
<?php
}
?>
</ul>
</td>
<td>
<ul>
<?php
foreach( $hra_ids as $hra_id ) {
	$hra=$hras[$hra_id];
?>
<li><label><input type='radio' name='<?php echo( $control_name.'_HRA' );?>' value='<?php echo( $hra['id'] );?>' <?php echo( $hras_count == 1 ? 'checked' : '' ); ?> />
<span class='user'><?php echo( $hra['FirstName'].'&nbsp;'.$hra['LastName'] ); ?></span>&nbsp;at&nbsp;<?php echo( $hra['import_date_f'] ); ?></label></li>
<?php
}
?>
</ul>
</td>
</tr>
<?php
}
?>
<?php
}
?>
</table>
<center>
<input type='hidden' name='suggest' value='1' />
<input type='submit' value='Commit suggestion' class="button" />
<input type='reset' value='Restore' class="button" />
</center>
</form>
<?php } // end of suggestions ?>
<?php // next to manualy match hra and labcorps ( no user check )
?>
<form action="index.php?page=match" method="POST">
<table class="labcorp2hra">
	<caption>Bind manually</caption>
	<tr>
		<th width='50%' ><b>LabCorps with no HRA</b></th>
		<th width='50%' ><b>HRAs with no LabCorp</b></th>
	</tr>
	<tr>
		<td valign="top" >
		<table>
		<?php	foreach( $labcorps as $labcorp ) { ?>
			<tr>
				<td><label><input type='radio' name='labcorp_id' value='<?php echo( $labcorp['id'] ); ?>' />
				<span class='user'><?php echo( $labcorp['firstname'].'&nbsp;'.$labcorp['lastname'] ); ?></span>&nbsp;at&nbsp;<?php echo( $labcorp['import_date_f'] ); ?></label></td>
				<td><a href="index.php?page=match&nohra=<?php echo( $labcorp['id'] ); ?>" title='set as has no HRA' onClick='JavaScript: return confirm("Are you sure to mark this LabCorp as it has no HRA?");'><img src="util/images/broom_arrow.png" border="0"></a></td>
			</tr>
		<?php } ?>
		</table>
		</td>
		<td valign="top" >
		<table>
		<?php	foreach( $hras as $hra ) { ?>
			<tr>
				<td><label><input type='radio' name='hra_id' value='<?php echo( $hra['id'] ); ?>' />
				<span class='user'><?php echo( $hra['FirstName'].'&nbsp;'.$hra['LastName'] ); ?></span>&nbsp;at&nbsp;<?php echo( $labcorp['import_date_f'] ); ?></label></td>
				<td><a href="index.php?page=match&nolab=<?php echo( $hra['id'] ); ?>" title='set as has no LabCorp' onClick='JavaScript: return confirm("Are you sure to mark this HRA as it has no LabCorp?");'><img src="util/images/broom_arrow.png" border="0"></a></td>
			</tr>
		<?php } ?>
		</table>
		</td>
	</tr>
</table>
<center><input type="submit" value="Match These Results" class="button"></center>
</form>