<?
$x=1;
$query = "SELECT u.*,l.import_date,c.company company_name,l.id lid
		  FROM ct_labcorp_pid l,ct_users u
		  	LEFT JOIN ct_users c ON(u.company=c.id)
		  WHERE l.ct_sws_id=u.id
		  	AND DATE_ADD(`import_date`, INTERVAL 8 DAY) > NOW()
		  ORDER BY import_date DESC, company_name, c.lastname, c.firstname ASC";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0)
{
	?>
	<table id="list_table" cellspacing="1" cellpadding="0" border="0" align="center">
		<tr>
			<td height="32"><span id="page_head">&nbsp;&nbsp;Labcorps Imported This Week&nbsp;&nbsp;</span></td>
		</tr>
	<?
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		extract($row);
		if($company_name=="") $company_name="<i>unknown client</i>";

		if($company_name!=$last_company_name)
			echo "<tr><th colspan=3><b>$import_date - $company_name</b></th></tr>";

		?>
		<tr class='row-<?= $x*=-1 ?>1' style='cursor:pointer;cursor:hand' onmouseover="this.className='rowover'" onmouseout="this.className='row-<?= $x ?>'" onclick="document.location='index.php?page=users&id=<?= $id ?>&returntype='">
			<td>&nbsp; <?= $lastname ?>, <?= $firstname ?></td>
		</tr>

		<?

		$last_company_name = $company_name;
	}

	echo "</table>";
}

$query = "SELECT * FROM ct_content WHERE page='admn'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
echo $content;
?>