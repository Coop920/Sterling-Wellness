<?
ob_start();
?>
	<div><a href="index.php?page=<?= $_GET['page'] ?>">All</a></div>
	<?
	foreach ($GLOBALS['user_types_names'] as $usertypeid => $usertypename)
	{
		?>
		<div><a href="index.php?page=<?= $_GET['page'] ?>&type=<?= $usertypeid ?>"><?=  $usertypename ?>s</a></div>
		<?
	}
	?>
	<div><a href="index.php?page=pids">Generate PIDs</a></div>
<?php
	$subnav = ob_get_contents();
	ob_end_clean();

if(count($_POST)>1)
{
	#These are all of the fields in the DB that will be updated.  I put them in an array because
	#this was easier than having to update all of the queries everytime a new field is added
	$fields_to_edit = array('firstname','lastname','usertype','email','active','company','address','city','state','zip','phone1','phone2');


	#Some forms have extra fields
	//Client
	if($_POST['usertype']==4) $fields_to_edit = array_merge($fields_to_edit,array('clientID','groupnumber','custom','locations'));
	//Participant
	if($_POST['usertype']==5)
	{
		$fields_to_edit = array_merge($fields_to_edit,array('dob','phys','ins','ssn'));
		$_POST['dob'] = $_POST['dob_y'] . "-" . $_POST['dob_m'] . "-" . $_POST['dob_d'];

	}
	//Consultant
	if($_POST['usertype']==3) $fields_to_edit = array_merge($fields_to_edit,array('title'));

	#Make sure we don't edit a password field they don't want to edit. Also encrypt it in the DB
	if($_POST['password']!="")
	{
		$fields_to_edit[]="password";
		$_POST['password'] = md5($_POST['password']);
	}

	#build out the query
	for($x=0;$x<count($fields_to_edit);$x++)
	{
		$insert_array[] = "`{$fields_to_edit[$x]}`='{$_POST[$fields_to_edit[$x]]}'";
	}

	if(is_array($insert_array))
	{
		if($_POST['id'])
		{
			$may_update = true;
			if( isset( $_POST['new_PID']) && ($_POST['new_PID'] != $_POST['id']) ) {
				$message = change_user_id( (int)$_POST['id'], (int)$_POST['new_PID'] );
				if( $message ) { // change id failed
					$may_update = false;
				} else { // change id is Ok
					$_POST['id'] = (int)$_POST['new_PID'];
				}
			}
			if( $may_update ) { // change id is OK
				if( isset( $insert_array['id'] ) ) $insert_array['id'] = (int)$_POST['new_PID'];
				$query = "UPDATE `ct_users` SET " . implode(", ",$insert_array) . " WHERE id = '{$_POST['id']}'";
				$message = "{$_POST['firstname']} {$_POST['lastname']} has been saved.";
			} else {
				$query = '';
			}
		}
		else
		{
			$PID = get_next_PID();
			$insert_array[] = 'id = "'.$PID.'"';
			$query = "INSERT INTO `ct_users` SET " . implode(", ",$insert_array) . "";
			$message = "{$_POST['firstname']} {$_POST['lastname']} has been added.";
			$_POST['id']=$PID;
		}
		if( $query ) mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	}

	#if this is a physician, we need to add the clients they have access to
	if($_POST['usertype']==2)
	{
		#Delete the ones already there
		$query = "DELETE FROM ct_assigned_users WHERE user = '{$_POST['id']}'";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

		if(is_array($_POST['assigned']))
		{
			$query = "INSERT INTO ct_assigned_users VALUES ({$_POST['id']}," . implode("),({$_POST['id']},",$_POST['assigned']) .")" ;
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		}

	}

	#if this is a consultant, we need to add the clients they have access to
	if($_POST['usertype']==3)
	{
		#Delete the ones already there
		$query = "DELETE FROM ct_assigned_consultants WHERE user = '{$_POST['id']}'";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

		if(is_array($_POST['assigned']))
		{
			$query = "INSERT INTO ct_assigned_consultants VALUES ({$_POST['id']}," . implode("),({$_POST['id']},",$_POST['assigned']) .")" ;
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		}

	}

	#if this is a client, we need to add the physicians, then consultants who have access to them
	if($_POST['usertype']==4)
	{
		#Physicians
		$query = "DELETE FROM ct_assigned_users WHERE client = '{$_POST['id']}'";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

		if(is_array($_POST['assigned']))
		{
			$query = "INSERT INTO ct_assigned_users (`client`,`user`) VALUES ({$_POST['id']}," . implode("),({$_POST['id']},",$_POST['assigned']) .")" ;
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		}

		#Field Consultants
		$query = "DELETE FROM ct_assigned_consultants WHERE client = '{$_POST['id']}'";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

		if(is_array($_POST['cons']))
		{
			$query = "INSERT INTO ct_assigned_consultants (`client`,`user`) VALUES ({$_POST['id']}," . implode("),({$_POST['id']},",$_POST['cons']) .")" ;
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		}

	}

	if($_FILES['signature']['tmp_name']!="")
	{
		if(!move_uploaded_file($_FILES['signature']['tmp_name'],"signatures/{$_POST['id']}.jpg"))
			die("error moving file");
	}

	header("Location: index.php?page=users&type=".$_POST['returntype']."&message=".$message);
}
else if($_GET['status']>0)
{
	if($_GET['val']) $new_status = 0;
	else $new_status=1;

	$query = "UPDATE ct_users SET active = '$new_status' WHERE id='{$_GET['status']}' AND `id`!=1";
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	$message = "Status updated";

	header("Location: index.php?message=Updated Status&page=users&type=".$_GET['returntype']);
}
else if($_GET['id']>0 || $_GET['new'])
{
	if($_GET['id']>0)
	{
		$query = "SELECT *,IF(`lastlogin`='0000-00-00 00:00:00','never',DATE_FORMAT(`lastlogin`,'%m-%d-%Y')) date_fmt FROM ct_users WHERE id='{$_GET['id']}'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	}
	else
	{
		$usertype = $_GET['returntype'];
	}
	?>


	<script src="util/js/jqvalidate.js"></script>

	<script>
	$().ready(function() {
		// validate signup form on keyup and submit
		$("#user_form").validate({
			rules: {
				firstname: "required",
				lastname: "required",
				password2: {
					equalTo: "#password"
				},
				zip: {
					required: true
				},
				address: {
					required: true
				},
				phone1: {
					required: true
				},
				city: {
					required: true
				}

			},
			messages: {
				firstname: "Please enter your first name.",
				lastname: "Please enter your last name.",
				password2: "Passwords do not match",
				city: "Please enter your city",
				zip: "Please enter your zip code",
				phone1: "Please enter your phone number"

			}
		});
	});

	</script>




	<table align="center" width="100%">
<tr>
	<td>
	<fieldset>
	<legend><b><?= $_GET['new']?"New ".$GLOBALS['user_types_names'][$_GET['returntype']]:"$firstname $lastname" ?></b></legend>

	<form action="index.php?page=users" method="POST" id="user_form" enctype="multipart/form-data">
	<input type='hidden' name='page' value='<?= $_GET['page'] ?>'>
	<input type='hidden' name='returntype' value='<?= $_GET['returntype'] ?>'>
	<input type='hidden' name='id' value='<?= $_GET['id'] ?>'>
	<input type='hidden' name='usertype' value='<?= $usertype==""?$_GET['usertype']:$usertype ?>'>
	<?
	//echo strtolower("admin/userforms/".$GLOBALS['user_types'][$usertype].".php");
	include(strtolower("admin/userforms/".$GLOBALS['user_types'][$usertype].".php"));
	?>
	<tr>
			 <td colspan="4" align="center"><br><input type="submit" class="button" style="width:75px" value="Save">
			 &nbsp;&nbsp;&nbsp;<input type="button" class="button" style="width:75px" value="Cancel" onClick="history.go(-1)"></td>
		</tr>
	</table>
	</form>

		</fieldset>
	</tr>
	</table>

	<?
}
else
{
	$per_page = 50;
	if(!is_numeric($_GET['start'])) $_GET['start']=0;

	?>
	<table align="center">
		<?php
			if($_GET['message'])
			{
		?>
		<tr>
			<Td class="system_message" colspan="2"><?= $_GET['message'] ?></Td>
		</tr>
		<?php
			}
		?>
		<tr>
			<td colspan="3"><form action="index.php?page=users" method="GET">
			<input type='hidden' name='page' value='<?= $_GET['page'] ?>'>
			<input type='hidden' name='type' value='<?= $_GET['type'] ?>'>
				<table id="search_table" class="disp_table">
					<tr>
						<td valign="middle" width="20%" nowrap><b>Search</b> <input type="text" name="s" value="<?= $_GET['s'] ?>" class="textbox search"></td>
						<? if($_GET['type']==5) { ?>
						<td>
						<select name="company" onchange="this.form.submit()"><option value="">All Clients</option>
						<?

							$query = "SELECT id,company FROM ct_users WHERE usertype = 4 order by company";
							$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
							while($row = mysql_fetch_array($result, MYSQL_ASSOC))
							{
								?><option value="<?= $row['id'] ?>" <?= $_GET['company']==$row['id']?"SELECTED":"" ?>><?= $row['company'] ?></option><?

							}
						?></select>
						</td>
						<? } ?>
						<td valign="middle"><input type="image" name="submit" src="util/images/magnify2.png"></td>
						<td align="center"><label><input type="checkbox" name="inactive" value="1" <?= $_GET['inactive']?"CHECKED":"" ?> onchange="this.form.submit()">show inactives</label></td>
						<td align="right"><?= $_GET['type']>0?"<a href='index.php?page=users&new=1&returntype={$_GET['type']}'>add new ".strtolower($GLOBALS['user_types_names'][$_GET['type']])."</a>":"" ?></td>
						<td width="10"><?= $_GET['type']>0?"<a href='index.php?page=users&new=1&returntype={$_GET['type']}'><img src='util/images/greenplus.png' border=0></a>":"" ?></td>
					</tr>
				</table>
			</td></form>
		</tr>
		<tr>
			<td colspan="3">
				<table id="list_table" class="disp_table" width="100%" cellspacing="1" cellpadding="0" border="0">
				<tr>
				<?

				switch($_GET['type'])
				{
						case 1:
							?>
							<th nowrap>Last Name</th>
							<th nowrap>First Name</th>
							<th nowrap>Email</th>
							<th nowrap>Phone</th>
							<th nowrap>Last Login</th>
							<th nowrap>Type</th>
							<th colspan="2">&nbsp;</th>
							<?
						break;

						case 2:
							?>
							<th nowrap>Last Name</th>
							<th nowrap>First Name</th>
							<th nowrap>Practice</th>
							<th nowrap>Email</th>
							<th nowrap>Primary Phone</th>
							<th nowrap>Secondary Phone</th>
							<th nowrap>Last Login</th>
							<th nowrap>Type</th>
							<th colspan="2">&nbsp;</th>
							<?
						break;

						case 3:
							?>
							<th nowrap>Last Name</th>
							<th nowrap>First Name</th>
							<th nowrap>Email</th>
							<th nowrap>Primary Phone</th>
							<th nowrap>Secondary Phone</th>
							<th nowrap>Last Login</th>
							<th nowrap>Type</th>
							<th colspan="2">&nbsp;</th>
							<?
						break;

						case 4:
							?>
							<th nowrap>Company</th>
							<th nowrap>Contact</th>
							<th nowrap>Email</th>
							<th nowrap>Phone</th>
							<th nowrap>Client ID</th>
							<th nowrap>Last Login</th>
							<th nowrap>Type</th>
							<th colspan="2">&nbsp;</th>
							<?
						break;

						case 5:
							?>
							<th nowrap>Last Name</th>
							<th nowrap>First Name</th>
							<th nowrap>Company</th>
							<th nowrap>Email</th>
							<th nowrap>Home Phone</th>
							<th nowrap>Last Login</th>
							<th nowrap>Type</th>
							<th colspan="2">&nbsp;</th>
							<?
						break;

						default:
							?>
							<th nowrap>Last Name</th>
							<th nowrap>First Name</th>
							<th nowrap>Company</th>
							<th nowrap>Email</th>
							<th nowrap>Primary Phone</th>
							<th nowrap>Last Login</th>
							<th nowrap>Type</th>
							<th colspan="2">&nbsp;</th>
							<?
						break;


				}
				?></tr>
				<?
				if($_GET['type']==5 || $_GET['type']=="")
				{
					$query = "SELECT id,company FROM ct_users WHERE usertype = 4";
					$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
					while($row = mysql_fetch_array($result, MYSQL_ASSOC))
					{
						extract($row);
						$company_name[$id]=$company;

					}
				}

				$i=1;
				$query = "SELECT *,concat(`lastname`,', ',`firstname`) name_fmt, CASE `usertype`";
					foreach ($GLOBALS['user_types_names'] as $when => $then)
					{
						$query .= "WHEN '$when' THEN '$then' ";
					}
				$query .= "ELSE NULL END usertype_fmt,
							IF(`lastlogin`='0000-00-00 00:00:00','never',DATE_FORMAT(`lastlogin`,'%m-%d-%Y')) date_fmt,email

							FROM ct_users
							WHERE `lastname` IS NOT NULL";
				if($_GET['type']!="") $query .= " AND usertype = '{$_GET['type']}'";
				if(!$_GET['inactive']) $query .= " AND active = '1'";
				if($_GET['s']!="") $query .= " AND (
													firstname LIKE('%{$_GET['s']}%')
												OR
													lastname LIKE('%{$_GET['s']}%')
												OR
													CONCAT(`firstname`,' ',`lastname`) LIKE('%{$_GET['s']}%')
												OR
													CONCAT(`lastname`,', ',`firstname`) LIKE('%{$_GET['s']}%')
												OR
													email LIKE('%{$_GET['s']}%')
												OR
													company LIKE('%{$_GET['s']}%')
												)
												";
				if($_GET['company']!="") $query .= " AND company = '{$_GET['company']}'";
				$query .= " ORDER BY usertype,name_fmt";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				$total_rows = mysql_num_rows($result);

				$query .= " LIMIT {$_GET['start']},$per_page";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);


				if($total_rows>($_GET['start']+$per_page))
				{
					$next = "<a href='index.php?page=users&type={$_GET['type']}&s={$_GET['s']}&start=".($_GET['start']+$per_page)."&inactive=".$_GET['inactive'].'&company='.$_GET['company']."'>next &gt;&gt;</a>";
				}

				if($_GET['start']>0)
				{
					$prev = "<a href='index.php?page=users&type={$_GET['type']}&s={$_GET['s']}&start=".($_GET['start']-$per_page)."&inactive=".$_GET['inactive'].'&company='.$_GET['company']."'>&lt;&lt; prev</a>";
				}

				$numbers = "Showing ".($_GET['start']+1)." to ".min($total_rows,$_GET['start']+$per_page)." of $total_rows";


				$pagination = "<tr><td align='left' width='30%'>$prev</td><td align='center' width='30%'>$numbers</td><td align='right' width='30%'>$next</td>";


				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					extract($row);

					$i *= -1;
					$thisalt = $i;

					echo "<tr class='row" , $thisalt , "$active' style='cursor:pointer;cursor:hand' onmouseover=\"this.className='rowover'\" onmouseout=\"this.className='row" , $thisalt , "'\" onclick=\"document.location='index.php?page=users&id={$id}&returntype={$_GET['type']}'\">";


					switch($_GET['type'])
					{
						case 1:
							?>
							<td><?= $lastname ?></a></td>
							<td><?= $firstname ?></a></td>
							<td><?= $email ?></td>
							<td><?= $phone1 ?></td>
							<td><?= $date_fmt ?></td>
							<td><?= $usertype_fmt ?></td>
							<td align="center">
								<a href="index.php?page=users&status=<?= $id ?>&val=<?= $active ?>&returntype=<?= $_GET['type'] ?>"><?= $active?"<img src='util/images/greencircle.png' alt='This user is active, click to deactivate' title='This user is active, click to deactivate' border='0'>":"<img src='util/images/greycircle.png' alt='This user is inactive, click to activate' title='This user is inactive, click to activate' border='0'>" ?></a>


							</td>
							<?
						break;

						case 2:
							?>
							<td><?= $lastname ?></a></td>
							<td><?= $firstname ?></a></td>
							<td><?= is_numeric($company)?$company_name[$company]:$company ?></td>
							<td><?= $email ?></td>
							<td><?= $phone1 ?></td>
							<td><?= $phone2 ?></td>
							<td><?= $date_fmt ?></td>
							<td><?= $usertype_fmt ?></td>
							<td align="center">
								<a href="index.php?page=users&status=<?= $id ?>&val=<?= $active ?>&returntype=<?= $_GET['type'] ?>"><?= $active?"<img src='util/images/greencircle.png' alt='This user is active, click to deactivate' title='This user is active, click to deactivate' border='0'>":"<img src='util/images/greycircle.png' alt='This user is inactive, click to activate' title='This user is inactive, click to activate' border='0'>" ?></a>


							</td>
							<?
						break;

						case 3:
							?>
							<td><?= $lastname ?></a></td>
							<td><?= $firstname ?></a></td>
							<td><?= $email ?></td>
							<td><?= $phone1 ?></td>
							<td><?= $phone2 ?></td>
							<td><?= $date_fmt ?></td>
							<td><?= $usertype_fmt ?></td>
							<td align="center">
								<a href="index.php?page=users&status=<?= $id ?>&val=<?= $active ?>&returntype=<?= $_GET['type'] ?>"><?= $active?"<img src='util/images/greencircle.png' alt='This user is active, click to deactivate' title='This user is active, click to deactivate' border='0'>":"<img src='util/images/greycircle.png' alt='This user is inactive, click to activate' title='This user is inactive, click to activate' border='0'>" ?></a>


							</td>
							<?
						break;

						case 4:
							?>
							<td><?= is_numeric($company)?$company_name[$company]:$company ?></td>
							<td><?= $name_fmt ?></td>
							<td><?= $email ?></td>
							<td><?= $phone1 ?></td>
							<td><?= $clientID ?></td>
							<td><?= $date_fmt ?></td>
							<td><?= $usertype_fmt ?></td>
							<td align="center">
								<a href="index.php?page=users&status=<?= $id ?>&val=<?= $active ?>&returntype=<?= $_GET['type'] ?>"><?= $active?"<img src='util/images/greencircle.png' alt='This user is active, click to deactivate' title='This user is active, click to deactivate' border='0'>":"<img src='util/images/greycircle.png' alt='This user is inactive, click to activate' title='This user is inactive, click to activate' border='0'>" ?></a>


							</td>
							<?
						break;

						default:
							?>
							<td valign="top"><?= $lastname ?></a></td>
							<td valign="top"><?= $firstname ?></a></td>
							<td valign="top"><?= is_numeric($company)?$company_name[$company]:$company ?></td>
							<td valign="top"><?= $email ?></td>
							<td valign="top"><?= $phone1 ?></td>
							<td valign="top"><?= $date_fmt ?></td>
							<td valign="top"><?= $usertype_fmt ?></td>
							<td valign="top" align="center">
								<a href="index.php?page=users&status=<?= $id ?>&val=<?= $active ?>&returntype=<?= $_GET['type'] ?>"><?= $active?"<img src='util/images/greencircle.png' alt='This user is active, click to deactivate' title='This user is active, click to deactivate' border='0'>":"<img src='util/images/greycircle.png' alt='This user is inactive, click to activate' title='This user is inactive, click to activate' border='0'>" ?></a>

							</td>
							<?
						break;



					}
					echo "</tr>";
				}

				?>
				</table>
			</td>
		</tr>
		<?= $pagination; ?>
	</table>
	<?
}


?>