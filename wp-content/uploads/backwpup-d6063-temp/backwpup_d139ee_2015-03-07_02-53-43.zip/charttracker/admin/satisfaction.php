<?
if($_GET['start_date']!="")
{
	$daterange = " AND `completed` >= STR_TO_DATE('{$_GET['start_date']}', '%m/%d/%Y')";
}

if($_GET['end_date']!="")
{
	$daterange .= " AND `completed` <= STR_TO_DATE('{$_GET['end_date']}', '%m/%d/%Y')";
}

if($_GET['customer']>0)
{
	$daterange .= " AND `company` = '{$_GET['customer']}'";
}

$i=1;
$query = "SELECT count(`id`) total_submissions FROM ct_surveys WHERE 1 $daterange";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

?>
<span style="float:right"><a href="index.php?page=satisfaction_setup">[setup]</a></span>
<table width="100%">
	<tr>
		<td valign="top" align="left">
		<?
			if($total_submissions>0)
			{
			?>

			<table align="center" cellpadding="3" cellspacing="1" width="100%">

			<tr>
				<th colspan="4"><b>How did rate the onsite wellness screenings?</b></th>
			</tr>
			<?
			$ratings = array("1"=>"Excellent","2"=>"Good","3"=>"Average","4"=>"Fair","5"=>"Poor");
			$query = "SELECT count(`rating`) results,rating FROM ct_surveys WHERE 1 $daterange GROUP BY rating ORDER BY rating";
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			while($row = mysql_fetch_array($result, MYSQL_ASSOC))
			{
				extract($row);
				?>
				<tr class="row<?= $i*=-1 ?>">
					<td><?= $ratings[$rating] ?></td>
					<td width="10%" align="right"><?= $results ?></td>
					<td width="10%" align="right"><?= intval(($results/$total_submissions)*100) ?>%</td>
					<td width="50">
						<table cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="border:1px solid #6990b3;background-color:#FFFFFF"><img src="util/images/bar.gif" style="border-right:1px solid #6990b3;height:16px;width:<?= intval(($results/$total_submissions)*100) ?>%"></td>
							</tr>
						</table>
					</td>
				</tr>
				<?
			}
			?>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<th colspan="4"><b>What did you <i>most</i> like about the wellness screenings and consultations?</b></th>
			</tr>
			<?

			$mostlikesearch = array(
				'mostlike1'=>"Conveniece of Onsite Lab Testing",
				'mostlike2'=>"Health Risk Appraisal Questionnaire",
				'mostlike3'=>"Nutrition Consultation",
				'mostlike4'=>"Blood Pressure Screening",
				'mostlike5'=>"Weight & Body Composition Analysis",
				'mostlike6'=>"Fitness Consultation",
				'mostlike7'=>"3-Minute Step Test",
				'mostlike8'=>"Sit & Reach Test",
				'mostlike9'=>"Educational Material",
				'mostlike9'=>"Other",
				);

			foreach ($mostlikesearch as $field=>$question)
			{
				$query = "SELECT count(`$field`) results FROM ct_surveys WHERE `$field` = 1 $daterange";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

				?>
				<tr class="row<?= $i*=-1 ?>">
					<td><?= $question ?></td>
					<td width="10%" align="right"><?= $results ?></td>
					<td width="10%" align="right"><?= intval(($results/$total_submissions)*100) ?>%</td>
					<td width="50">
						<table cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="border:1px solid #6990b3;background-color:#FFFFFF"><img src="util/images/bar.gif" style="border-right:1px solid #6990b3;height:16px;width:<?= intval(($results/$total_submissions)*100) ?>%"></td>
							</tr>
						</table>
					</td>
				</tr>
				<?

			}

			?>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<th colspan="4"><b>What did you <i>least</i> like about the wellness screenings and consultations?</b></th>
			</tr>
			<?

			$mostlikesearch = array(
				'leastlike1'=>"Conveniece of Onsite Lab Testing",
				'leastlike2'=>"Health Risk Appraisal Questionnaire",
				'leastlike3'=>"Nutrition Consultation",
				'leastlike4'=>"Blood Pressure Screening",
				'leastlike5'=>"Weight & Body Composition Analysis",
				'leastlike6'=>"Fitness Consultation",
				'leastlike7'=>"3-Minute Step Test",
				'leastlike8'=>"Sit & Reach Test",
				'leastlike9'=>"Educational Material",
				'leastlike10'=>"Other",
				);

			foreach ($mostlikesearch as $field=>$question)
			{
				$query = "SELECT count(`$field`) results FROM ct_surveys WHERE `$field` = 1 $daterange";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

				?>
				<tr class="row<?= $i*=-1 ?>">
					<td><?= $question ?></td>
					<td width="10%" align="right"><?= $results ?></td>
					<td width="10%" align="right"><?= intval(($results/$total_submissions)*100) ?>%</td>
					<td width="50">
						<table cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="border:1px solid #6990b3;background-color:#FFFFFF"><img src="util/images/bar.gif" style="border-right:1px solid #6990b3;height:16px;width:<?= intval(($results/$total_submissions)*100) ?>%"></td>
							</tr>
						</table>
					</td>
				</tr>
				<?

			}

			?>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<th colspan="4"><b>Are you likely to participate in future onsite wellness screenings?</b></th>
			</tr>
			<?
			$responses = array("1"=>"Yes","0"=>"No");
			$query = "SELECT count(`part_again`) results,part_again FROM ct_surveys WHERE 1 $daterange GROUP BY part_again ORDER BY part_again DESC";
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			while($row = mysql_fetch_array($result, MYSQL_ASSOC))
			{
				extract($row);
				?>
				<tr class="row<?= $i*=-1 ?>">
					<td><?= $responses[$part_again] ?></td>
					<td width="10%" align="right"><?= $results ?></td>
					<td width="10%" align="right"><?= intval(($results/$total_submissions)*100) ?>%</td>
					<td width="50">
						<table cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="border:1px solid #6990b3;background-color:#FFFFFF"><img src="util/images/bar.gif" style="border-right:1px solid #6990b3;height:16px;width:<?= intval(($results/$total_submissions)*100) ?>%"></td>
							</tr>
						</table>
					</td>
				</tr>
				<?
			}
			?>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<th colspan="4"><b>How would you rate the importance an value of your Lab Results and<br>Personal Wellness Profile in making future life-style changes?</b></th>
			</tr>
			<?

			$ratings = array("1"=>"Highly Important and Valuable","2"=>"Somewhat Important and Valuable","3"=>"No Importance or Value");
			$query = "SELECT count(`importance`) results,importance FROM ct_surveys WHERE 1 $daterange GROUP BY importance ORDER BY importance";
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			while($row = mysql_fetch_array($result, MYSQL_ASSOC))
			{
				extract($row);
				?>
				<tr class="row<?= $i*=-1 ?>">
					<td><?= $ratings[$importance] ?></td>
					<td width="10%" align="right"><?= $results ?></td>
					<td width="10%" align="right"><?= intval(($results/$total_submissions)*100) ?>%</td>
					<td width="50">
						<table cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="border:1px solid #6990b3;background-color:#FFFFFF"><img src="util/images/bar.gif" style="border-right:1px solid #6990b3;height:16px;width:<?= intval(($results/$total_submissions)*100) ?>%"></td>
							</tr>
						</table>
					</td>
				</tr>
				<?
			}

			?>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<th colspan="4"><b>What other onsite programs related to Health and Wellness would you like?</b></th>
			</tr>
			<?

			$mostlikesearch = array(
				'wouldlike1'=>"Weight Watchers Program at Work",
				'wouldlike2'=>"Stress Management",
				'wouldlike3'=>"Smoking Cessation Program",
				'wouldlike4'=>"Exercise Fitness Program",
				'wouldlike5'=>"Nutritional Series",
				'wouldlike6'=>"Diabetes Awareness",
				'wouldlike7'=>"Other"
				);

			foreach ($mostlikesearch as $field=>$question)
			{
				$query = "SELECT count(`$field`) results FROM ct_surveys WHERE `$field` = 1 $daterange";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

				?>
				<tr class="row<?= $i*=-1 ?>">
					<td ><?= $question ?></td>
					<td width="10%" align="right"><?= $results ?></td>
					<td width="10%" align="right"><?= intval(($results/$total_submissions)*100) ?>%</td>
					<td width="50">
						<table cellpadding="0" cellspacing="0" width="100%">
							<tr>
								<td style="border:1px solid #6990b3;background-color:#FFFFFF"><img src="util/images/bar.gif" style="border-right:1px solid #6990b3;height:16px;width:<?= intval(($results/$total_submissions)*100) ?>%"></td>
							</tr>
						</table>
					</td>
				</tr>
				<?

			}

			?>
			<tr>
				<td>&nbsp;</td>
			</tr>



			</table><?
				}
				else
				{
					//echo "There were no surveys that match this criteria.";
				}
				?>
		</td>
		<td width="8"></td>
		<td valign="top">

		<script>
	  $(document).ready(function(){
	    $('.date').datepicker();
	  });
	  </script>
		<table align="center" id="form_table" cellpadding="3" width="100%">
			<form action="index.php">
			<input type="hidden" name="page" value="<?= $_GET['page'] ?>">
				<tr>
					<th colspan="2">
						Company Name
					</th>
				</tr>
				<tr>
					<td colspan="2">
						<select name="customer">
						<option value="">All</option>
						<?
						$query = "SELECT * FROM ct_users WHERE usertype = '4'";
						$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
						while($row = mysql_fetch_array($result, MYSQL_ASSOC))
						{
							extract($row);
							?>
							<option value="<?= $id ?>"><?= $company ?></option>
							<?
						}
						?>
						</select>
					</td>
				</tr>
				<tr>
					<th colspan="2">
						Search by Date Range
					</th>
					<tr>
						<td>From:</td><td>
							<input type="text" class="textbox date" name="start_date" size="10" value="<?= $_GET['start_date'] ?>">
							</td>
						</tr>
						<tr>
							<td>To:</td>
							<td>
							<input type="text" class="textbox date" name="end_date" size="10" value="<?= $_GET['end_date'] ?>">

						</td>
					</tr>
					<tr>
						<td colspan="2" align="right"><input type="submit" value="Run Report" class="button"></td>
					</tr>
				</tr>
			</form>

			</table>
			<table>
				<tr>
					<td>Total Surveys: </td>
					<td><?= $total_submissions ?></td>
				</tr>
			</table>


		</td>
	</table>
