<link href="styles.css" rel="stylesheet" type="text/css">
<? // make subnav menu
ob_start();
?>
	<div><a href="index.php?page=users">All</a></div>
	<?
	foreach ($GLOBALS['user_types_names'] as $usertypeid => $usertypename)
	{
		?>
		<div><a href="index.php?page=users&type=<?= $usertypeid ?>"><?=  $usertypename ?>s</a></div>
		<?
	}
	?>
	<div><a href="index.php?page=pids">Generate PIDs</a></div>
<?php
	$subnav = ob_get_contents();
	ob_end_clean();
	// end of subnav menu
?>
<?php

require_once("global.php");

// Some helpful functions

function unlink_hra_from_labcorp( $hra_id, $user_id ) {
	$query='
		SELECT labcorp_id, nolab
		FROM ct_hra
		WHERE id="'.$hra_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$row = mysql_fetch_array( $result, MYSQL_ASSOC );
	if( !$row['nolab'] ) { // unlink from labcorp
		$labcorp_id = $row['labcorp_id'];
		$query = '
			UPDATE ct_labcorp_pid
			SET hra_id = NULL,
			nohra = NULL,
			ct_sws_id = '.$user_id.'
			WHERE id = "'.$labcorp_id.'"
		';
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	}
	$query = '
		UPDATE ct_hra
		SET labcorp_id=NULL,
		nolab=NULL,
		user_id='.$user_id.'
		WHERE id = "'.$hra_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function unlink_labcorp_from_hra( $labcorp_id, $user_id ) {
 $query='
		SELECT hra_id, nohra
		FROM ct_labcorp_pid
		WHERE id="'.$labcorp_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$row = mysql_fetch_array( $result, MYSQL_ASSOC );

	if( !$row['nohra'] ) { // unlink hra
		$hra_id = $row['hra_id'];
		$query = '
			UPDATE ct_hra
			SET labcorp_id = NULL,
			nolab = NULL,
			user_id = '.$user_id.'
			WHERE id="'.$hra_id.'"
		';
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	}
	$query = '
		UPDATE ct_labcorp_pid
		SET hra_id = NULL,
		nohra = NULL,
		ct_sws_id = '.$user_id.'
		WHERE id="'.$labcorp_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function delete_hra( $hra_id, $user_id ) {

	$query='
		SELECT labcorp_id, nolab, user_id
		FROM ct_hra
		WHERE id="'.$hra_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$hra = mysql_fetch_array( $result, MYSQL_ASSOC );

	// check for linked LabCorps
	$query = '
		SELECT *
		FROM ct_labcorp_pid
		WHERE hra_id = '.$hra_id.'
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while( $labcorp = mysql_fetch_array( $result, MYSQL_ASSOC ) ) {
		// check if properly linked
		if( $labcorp['ct_sws_id'] == $user_id ) {// they are properly linked, delete labcorp
			$query = '
				DELETE
				FROM ct_labcorp_pid
				WHERE id='.$labcorp['id'].'
			';
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		} else { // they are linked by mistake, unlink labcorp
			$query = '
				UPDATE ct_labcorp_pid
				SET hra_id = NULL
				WHERE id='.$labcorp['id'].'
			';
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		}
	}
		$query = '
		DELETE FROM ct_hra
		WHERE id="'.$hra_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function delete_labcorp( $labcorp_id ) {

	$query = '
		SELECT *
		FROM ct_labcorp_pid
		WHERE id='.$labcorp_id.'
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$labcorp = mysql_fetch_array( $result, MYSQL_ASSOC );
	if( $labcorp['hra_id'] ) {
		//check if linked properly
		$query = '
			SELECT *
			FROM ct_hra
			WHERE id='.$labcorp['hra_id'].'
		';
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

		if( $hra = mysql_fetch_array( $result, MYSQL_ASSOC ) ) {
			if( $hra['labcorp_id'] == $labcorp_id ) {//they are properly linked, delete HRA
				$query = '
					DELETE
					FROM ct_hra
					WHERE id='.$hra['id'].'
				';
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			} else { // they are linked by mistake, unlink HRA
				$query = '
					UPDATE ct_hra
					SET labcorp_id = NULL
					WHERE id='.$hra['id'].'
				';
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			}
		}
	}
	$query = '
		DELETE FROM ct_labcorp_pid
		WHERE id="'.$labcorp_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function delete_assessment( $assessment_id ) {
	$query='
		DELETE
		FROM ct_assessments
		WHERE id="'.(int) $assessment_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function delete_followup( $followup_id ) {
	$query='
		DELETE
		FROM ct_followups
		WHERE id="'.(int) $followup_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function delete_lab_result( $lab_result_id ) {
	$query='
		DELETE
		FROM ct_lab_results
		WHERE id="'.(int) $lab_result_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function delete_upload( $upload_id ) {

	//first get upload info to be able to delete uploaded file
	$query='
		SELECT *
		FROM ct_uploads
		WHERE id="'.(int) $upload_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$row = mysql_fetch_array( $result, MYSQL_ASSOC );
	if( $row && $row['filename'] ) {
		$filename = 'uploads/' . (int) $row['id']. '_' . (string) $row['filename'];
		if( is_file( $filename ) ) unlink( $filename );
	}
	$query='
		DELETE
		FROM ct_uploads
		WHERE id="'.(int) $upload_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function link_labcorp( $labcorp_id, $new_user_id = false ) {

	if( $new_user_id ) {
		$hra_user_id = '"'. (int) $new_user_id .'"';
		$labcorp_user_id = (int) $new_user_id;
	}	else {
		$hra_user_id = '""'; // TODO need change table column defination to INT with NULL. Now it is VARCHAR without NULL
		$labcorp_user_id = 'NULL';
	}
	$query = '
		SELECT *
		FROM ct_labcorp_pid
		WHERE id='.$labcorp_id.'
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$labcorp = mysql_fetch_array( $result, MYSQL_ASSOC );
	if( $labcorp['hra_id'] ) {
		//check if linked properly
		$query = '
			SELECT *
			FROM ct_hra
			WHERE id='.$labcorp['hra_id'].'
		';
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

		if( $hra = mysql_fetch_array( $result, MYSQL_ASSOC ) ) {
			if( $hra['labcorp_id'] == $labcorp_id ) {//they are properly linked, link HRA
				$query = '
					UPDATE ct_hra
					SET user_id = '.$hra_user_id.'
					WHERE id='.$hra['id'].'
				';
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			} else { // they are linked by mistake, unlink HRA
				$query = '
					UPDATE ct_hra
					SET labcorp_id = NULL
					WHERE id='.$hra['id'].'
				';
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			}
		}
	}
	// TODO may be shoud also set correct user name?
	$query='
		UPDATE ct_labcorp_pid
		SET ct_sws_id='.$labcorp_user_id.'
		WHERE id="'.(int) $labcorp_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function link_hra( $hra_id, $user_id, $new_user_id = false ) {

	if( $new_user_id ) {
		$hra_user_id = '"'. (int) $new_user_id .'"';
		$labcorp_user_id = (int) $new_user_id;
	}	else {
		$hra_user_id = '""'; // TODO need change table column defination to INT with NULL. Now it is VARCHAR without NULL
		$labcorp_user_id = 'NULL';
	}

	// check for linked LabCorps
	$query = '
		SELECT *
		FROM ct_labcorp_pid
		WHERE hra_id = '.$hra_id.'
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while( $labcorp = mysql_fetch_array( $result, MYSQL_ASSOC ) ) {
		// check if properly linked
		if( $labcorp['ct_sws_id'] == $user_id ) {// they are properly linked, link labcorp
			// TODO may be shoud also set correct user name?
			$query = '
				UPDATE ct_labcorp_pid
				SET ct_sws_id = '.$labcorp_user_id.'
				WHERE id='.$labcorp['id'].'
			';
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		} else { // they are linked by mistake, unlink labcorp
			$query = '
				UPDATE ct_labcorp_pid
				SET hra_id = NULL
				WHERE id='.$labcorp['id'].'
			';
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		}
	}
	$query = '
		UPDATE ct_hra
		SET user_id = '.$hra_user_id.'
		WHERE id="'.$hra_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

}

function link_assessment( $assessment_id, $new_user_id = false ) {

	if( $new_user_id ) $new_user_id = '"'. (int) $new_user_id .'"';
	else $new_user_id = '0'; // TODO need change table column defination to INT with NULL. Now it is INT without NULL

	$query = '
		UPDATE ct_assessments
		SET patient = '.$new_user_id.'
		WHERE id="'.(int) $assessment_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function link_followup( $followup_id, $new_user_id = false ) {

	if( $new_user_id ) $new_user_id = '"'. (int) $new_user_id .'"';
	else $new_user_id = '0'; // TODO need change table column defination to INT with NULL. Now it is INT without NULL

	$query = '
		UPDATE ct_followups
		SET patient = '.$new_user_id.'
		WHERE id="'.(int) $followup_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function link_lab_result( $lab_result_id, $new_user_id = false ) {

	if( $new_user_id ) $new_user_id = '"'. (int) $new_user_id .'"';
	else $new_user_id = '0'; // TODO need change table column defination to INT with NULL. Now it is INT without NULL

	$query = '
		UPDATE ct_lab_results
		SET patient = '.$new_user_id.'
		WHERE id="'.(int) $lab_result_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

function link_upload( $upload_id, $new_user_id = false ) {

	if( $new_user_id ) $new_user_id = '"'. (int) $new_user_id .'"';
	else $new_user_id = '0'; // TODO need change table column defination to INT with NULL. Now it is INT without NULL

	$query = '
		UPDATE ct_uploads
		SET user_id = '.$new_user_id.'
		WHERE id="'.(int) $upload_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
}

#make sure they're logged in
check_auth();
#extra check... no one, under any circumstance can see this unless they're an admin
if($GLOBALS['user_data']['usertype']!=1)
die("You do not have permission to view this page. Please log in.");

ob_start();



if( isset( $_REQUEST['user_id'] ) && $_REQUEST['user_id'] )
{
	$user_id=(int) $_REQUEST['user_id'];
	$query = '
		SELECT * FROM ct_users WHERE id='.$user_id.'
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$row=mysql_fetch_array( $result, MYSQL_ASSOC );
	if( $row )
	{
		$user_name = (string) $row['firstname'].' '.(string) $row['lastname'];
		$user_PID = $user_id;
	}
	else
	{
		$user_id = false;
		$user_name = false;
	}
}
else
{
	$user_id=false;
}

if( !$user_id ) // wrong or unexisting user
{
?>
	<div>User not found or not exists.<br>
	<a href='?page=users'>click here to view all users</a></div>
<?php
return;
}
?>
<?php

if( isset( $_REQUEST['action'] ) && $_REQUEST['action'] ) $action= (string) $_REQUEST['action'];

if( isset( $_REQUEST['test_type']) && $_REQUEST['test_type'] ) $test_type=(string) $_REQUEST['test_type'];
else $action = '';

if( isset( $_REQUEST['test_id']) && $_REQUEST['test_id'] ) $test_id=(int) $_REQUEST['test_id'];
else $action = '';

if( isset( $action ) && $action ) {
	switch( $action ) {
		case 'delete': // indeed we link it to nonexisting user ( NULL )
			switch( $test_type ) {
				case 'labcorp': delete_labcorp( $test_id ); break;
				case 'hra': delete_hra( $test_id, $user_id ); break;
				case 'assessment': delete_assessment( $test_id ); break;
				case 'followup': delete_followup( $test_id ); break;
				case 'lab_result': delete_lab_result( $test_id ); break;
				case 'upload': delete_upload( $test_id ); break;
			}
			break;
		case 'unlink': // indeed we link it to nonexisting user ( NULL )
			switch( $test_type ) {
				case 'labcorp': link_labcorp( $test_id ); break;
				case 'hra': link_hra( $test_id ); break;
				case 'assessment': link_assessment( $test_id ); break;
				case 'followup': link_followup( $test_id ); break;
				case 'lab_result': link_lab_result( $test_id ); break;
				case 'upload': link_upload( $test_id ); break;
			}
			break;
		case 'unlink_from_hra':
			switch( $test_type ) {
				case 'labcorp': unlink_labcorp_from_hra( $test_id, $user_id ); break;
			}
			break;
		case 'unlink_from_labcorp':
			switch( $test_type ) {
				case 'hra': unlink_hra_from_labcorp( $test_id, $user_id ); break;
			}
			break;
		case 'link':
			if( isset( $_REQUEST['test_new_user_id'] ) && $_REQUEST['test_new_user_id'] ) {
				$test_new_user_id = (int) $_REQUEST['test_new_user_id'];
				switch( $test_type ) {
					case 'labcorp': link_labcorp( $test_id, $test_new_user_id ); break;
					case 'hra': link_hra( $test_id, $user_id, $test_new_user_id ); break;
					case 'assessment': link_assessment( $test_id, $test_new_user_id ); break;
					case 'followup': link_followup( $test_id, $test_new_user_id ); break;
					case 'lab_result': link_lab_result( $test_id, $test_new_user_id ); break;
					case 'upload': link_upload( $test_id, $test_new_user_id ); break;
				}
			} else {
				$back_url = '';
				require( 'admin/history_link.php' );
				return;
			}
			break;
	}
}

?>
	<?php
	$query = '
	SELECT id, DATE_FORMAT(`import_date`,"%m-%d-%Y") date_f, "'.$history_types['labcorp'].'" test_name, "labcorp" test_type, hra_id linked_to FROM ct_labcorp_pid WHERE ct_sws_id="'.$user_id.'"
	UNION
	SELECT ct_hra.id, DATE_FORMAT(ct_hra.`import_date`,"%m-%d-%Y") date_f, "'.$history_types['hra'].'" test_name, "hra" test_type, ct_hra.labcorp_id linked_to FROM ct_hra,ct_labcorp_pid WHERE (ct_labcorp_pid.id=ct_hra.labcorp_id AND ct_sws_id="'.$user_id.'") OR ( ct_hra.user_id="'.$user_id.'" )
	UNION
	SELECT id , DATE_FORMAT(`add_date`,"%m-%d-%Y") date_f, "'.$history_types['assessment'].'(attached)" test_name, "assessment" test_type, "" linked_to FROM ct_assessments WHERE patient = "'.$user_id.'"
	UNION
	SELECT id,  DATE_FORMAT(GREATEST(q1date,q2date,q3date,q4date),"%m-%d-%Y") date_f , "'.$history_types['followup'].'" test_name, "followup" test_type, "" linked_to FROM ct_followups WHERE patient = "'.$user_id.'"
	UNION
	SELECT id, DATE_FORMAT(`date`,"%m-%d-%Y") date_f, "'.$history_types['lab_result'].'" test_name, "lab_result" test_type, "" linked_to FROM ct_lab_results WHERE patient = "'.$user_id.'"
	UNION
	SELECT id, DATE_FORMAT(`date`,"%m-%d-%Y") date_f, file_desc test_name, "upload" test_type, "" linked_to FROM ct_uploads WHERE user_id = "'.$user_id.'"
	ORDER BY date_f DESC';


?>
<script type='text/JavaScript' >

function edit_history_entry( action, test_id, test_type ) {
	switch( action ) {
		case 'unlink':
			switch( test_type ) {
				case 'labcorp':
					if( !confirm("Are you sure to hide this LabCorp?\nThis entry will be hided but still left in database.\nThis will also hide linked HRA if any.")) return false;
					break;
				case 'hra':
					if( !confirm("Are you sure to hide this HRA?\nThis entry will be hided but still left in database.\nThis will also hide linked LabCorp if any.")) return false;
					break;
				default:
					if( !confirm( 'Are you sure to hide this history entry?\nThis entry will be hided but still left in database.') ) return false;
					break;
			}
			break;
		case 'unlink_from_labcorp':
			if( !confirm( "Are you sure to unlink this HRA from LabCorp?\nUnlinked HRA and LabCorp will not be shown in History view.\nYou can link them together in \"Match Import\" page." ) ) return false;
			break;
		case 'unlink_from_hra':
			if( !confirm( "Are you sure to unlink this LabCorp from HRA?\nUnlinked HRA and LabCorp will not be shown in History view.\nYou can link them together in \"Match Import\" page." ) ) return false;
			break;
		case 'link':
			if( (test_type == 'labcorp') && (!confirm("Are you sure to link this LabCorp to another user?\nThis will also link linked HRA if any.")) ) return false;
			if( (test_type == 'hra') && (!confirm("Are you sure to link this HRA to another user?\nThis will also link linked LabCorp if any.")) ) return false;
			break;
		case 'delete' :
			switch( test_type ) {
				case 'labcorp':
					if( !confirm("Are you sure to delete this LabCorp?\nThis entry will be permanently erased from database.\nThis will also delete linked HRA if any.")) return false;
					break;
				case 'hra':
					if( !confirm("Are you sure to delete this HRA?\nThis entry will be permanently erased from database.\nThis will also delete linked LabCorp if any.")) return false;
					break;
				default:
					if( !confirm( 'Are you sure to delete this history entry?\nThis entry will be permanently erased from database.') ) return false;
					break;
			}
			break;
	}
	var form=document.getElementById( 'history_edit_form' );
	var i_test_type=document.getElementById( 'history_edit_test_type' );
	var i_test_name=document.getElementById( 'history_edit_test_name' );
	var i_action=document.getElementById( 'history_edit_test_action' );
	var i_test_id=document.getElementById( 'history_edit_test_id' );
	if( form && i_action && i_test_type && i_test_id )
	{
		i_test_type.value = test_type;
		i_test_id.value = test_id;
		i_action.value = action;
		form.submit();
	}
	else
	{
		alert( "Some error while trying to submit form" );
	}
}
</script>
<form method="POST" action="" id='history_edit_form' >
<input type='hidden' name='page' value='history_edit' >
<input type='hidden' name='action' value='' id='history_edit_test_action' >
<input type='hidden' name='user_id' value='<?php echo( $user_id ); ?>' >
<input type='hidden' name='test_type' value='' id='history_edit_test_type' >
<input type='hidden' name='test_name' value='' id='history_edit_test_name' >
<input type='hidden' name='test_id' value='' id='history_edit_test_id' >
<table width="100%">
<caption>Imported Data for user <?php echo( $user_name ); ?> ( PID: <?php echo( $user_PID );?> )</caption>
<tr>
<th>Entry type</th>
<th>Entry date</th>
<th>Actions</th>
</tr>
<?php
//	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$history = get_user_history( $user_id, true );
	error_log( print_r( $history, true ), 3, 'log.txt' );
	foreach( $history as $row )
//	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
//		extract($row);
		$test_id = (int) $row['id'];
		$test_name = (string) $row['test_name'];
		$test_type = (string) $row['test_type'];
		$import_date = (string) $row['date_f'];
		$linked_to = (int) $row['linked_to'];
		if( $test_type == 'hra' ) {
			if( $linked_to ) $test_name .= '('.$test_id.') => LabCorp('.$linked_to.')';
			else $test_name .= '(not linked)';
		}
		if( $test_type == 'labcorp' ) {
			if( $linked_to ) $test_name .= '('.$test_id.') => HRA('.$linked_to.')';
			else $test_name .= '(not linked)';
		}
?>
<tr>
<td><?php echo( $test_name );?></td>
<td><?php echo( $import_date );?></td>
<td>
<a href="#" onClick="JavaScript: edit_history_entry( 'unlink', '<?php echo( $test_id );?>', '<?php echo( $test_type );?>', '<?php echo( $test_name );?>' )">hide</a>
&nbsp;&nbsp;<a href="#" onClick="JavaScript: edit_history_entry( 'link', '<?php echo( $test_id );?>', '<?php echo( $test_type );?>', '<?php echo( $test_name );?>' )">link_to_another</a>
&nbsp;&nbsp;<a href="#" onClick="JavaScript: edit_history_entry( 'delete', '<?php echo( $test_id );?>', '<?php echo( $test_type );?>', '<?php echo( $test_name );?>' )">delete</a>
<?php if( ($test_type == 'labcorp') && $linked_to ) {?>
&nbsp;&nbsp;<a href="#" onClick="JavaScript: edit_history_entry( 'unlink_from_hra', '<?php echo( $test_id );?>', '<?php echo( $test_type );?>', '<?php echo( $test_name );?>' )">unlink_hra</a>
<?php } ?>
<?php if( ($test_type == 'hra') && $linked_to ) {?>
&nbsp;&nbsp;<a href="#" onClick="JavaScript: edit_history_entry( 'unlink_from_labcorp', '<?php echo( $test_id );?>', '<?php echo( $test_type );?>', '<?php echo( $test_name );?>' )">unlink_from_labcorp</a>
<?php } ?>
</tr>

<?php
	}
?>
<tr>
<td colspan='3' align='center'>
<?php
 // FIXME Cancel botton not work
  ?>
<input type="submit" class="button" style="width:75px" value="Cancel" onClick="JavaScript: cancel_linking();">
</td>
</tr>
</table>
</form>
