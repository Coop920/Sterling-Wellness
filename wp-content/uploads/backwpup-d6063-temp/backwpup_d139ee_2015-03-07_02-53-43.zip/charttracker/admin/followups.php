<?
/*
Accessing Follow Up Consultation Listing
After choosing to view the Follow Up Consultation Listing the Physician/Nurse will be
given a list of Participants they have access to that have met the requirements requiring follow
up: either an abnormal Lab Corp Result and/or an uncommon HRA Score.   The list will be
ordered by date due.  In addition to this listing the Physician/Nurse will be able to Filter
his/her views by:
Wellness Solutions � Chart Tracker
Website Development Proposal



� Client Name
� Participant Name
� Date
� Priority

The Physician/Nurse will be able to access the Follow Up Consultation Record Worksheet
per participant.  This worksheet will be pre-populated with the following information, which
will not be editable by the Physician/Nurse:

� Client Name
� Participant Name
� Age
� Gender
� Reason for Participation

The Physician/Nurse will be able to add/edit information on the Follow Up Consultation
Record Worksheet. The comment section will be specific to the quarter and it will also
calculate the time spent on the report based on input from the Physician/Nurse.  The
information they can Add/Edit is denoted in Appendix B.  In addition to the items they can
Add/Edit the Physician will be responsible for setting up the next date for Follow Up
Consultation.

*/

if(count($_POST)>1)
{

	$_POST['physician']=$GLOBALS['user_data']['id'];

	$excluded_fields = array('id');

	$date1 = explode("/",$_POST['q1date']);
	$date2 = explode("/",$_POST['q2date']);
	$date3 = explode("/",$_POST['q3date']);
	$date4 = explode("/",$_POST['q4date']);

	$_POST['q1date'] = $date1[2]."-".$date1[0]."-".$date1[1];
	$_POST['q2date'] = $date2[2]."-".$date2[0]."-".$date2[1];
	$_POST['q3date'] = $date3[2]."-".$date3[0]."-".$date3[1];
	$_POST['q4date'] = $date4[2]."-".$date4[0]."-".$date4[1];

	$query = "SHOW columns FROM `ct_followups`";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		if(!in_array($row['Field'],$excluded_fields))
			$query_set[] = " `{$row['Field']}`='{$_POST[$row['Field']]}'";
	}



	if($_POST['followup_id'])
	{
		$query = "UPDATE";
	}
	else
	{
		$query = "INSERT INTO";
	}

	$query .= " `ct_followups` SET " . implode(", ",$query_set);

	if($_POST['followup_id'])
		$query .= " WHERE id = '{$_POST['followup_id']}'";

	mysql_query($query) or die($query . "<br>" . mysql_error());

	header("Location: index.php?page=history&patient={$_POST['patient']}&test=Followup Consultation&id={$_POST['followup_id']}");
}
else if($_GET['id']!="" || $_GET['new_followup']!="")
{
	if($_GET['new_followup']!='')
	{
		$query = "SELECT *, DATE_FORMAT(FROM_DAYS(TO_DAYS(NOW())-TO_DAYS(dob)), '%Y')+0 age FROM ct_users WHERE id='{$_GET['new_followup']}'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	}
	else if($_GET['id']!="")
	{
		$query .= "SELECT *,DATE_FORMAT(FROM_DAYS(TO_DAYS(NOW())-TO_DAYS(dob)), '%Y')+0 age, DATE_FORMAT(q1date,'%m/%d/%Y') q1date,DATE_FORMAT(q2date,'%m/%d/%Y') q2date,DATE_FORMAT(q3date,'%m/%d/%Y') q3date,DATE_FORMAT(q4date,'%m/%d/%Y') q4date FROM ct_followups, ct_users WHERE ct_followups.patient = ct_users.id AND ct_followups.id = {$_GET['id']}";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	}

	?>
	<style>
		table { background-color:#bbbbbb; }
		td {background-color:white; }
	</style>

	<script>
	  $(document).ready(function(){
	    $('.date').datepicker();
	  });
	  </script>

	<form action="index.php?page=followups" method="POST">
	<input type="hidden" name="patient" value="<?= $patient==""?$_GET['new_followup']:$patient ?>">
	<input type="hidden" name="followup_id" value="<?= $_GET['id'] ?>">
	<input type="hidden" name="pid_id" value="<?= $_GET['pid_id']==""?$pid_id:$_GET['pid_id'] ?>">
	<table align="center" cellpadding="0" cellspacing="1" width="100%" border="0">

					<tr>
						<td><b>Name</b></td>
						<td colspan="2"><?= $firstname ?> <?= $lastname ?></td>
						<td><b>Age: </b><?= $age ?></td>
						<td colspan="2"><b>Gender: </b>&nbsp;<?= $sex ?></td>

		</tr>
		<tr>
			<td rowspan="10">
				<B>Reason for<br>Program<br>Participation</B>
			</td>
			<td colspan="2">
				<b>Abnormal Lab Results</b>
			</td>
			<td colspan="3">
				<b>Personal History</b>
			</td>
		</tr>
		<?

		$alr_ph_vals = array(
			"Glucose",
			"Diabetes Mellitus",
			"Hemoglobin A<sub>1</sub>C",
			"Cancer",
			"Kidney Function",
			"Cardiovascular",
			"Liver Function",
			"Stroke",
			"Electrolytes",
			"Hepatitis",
			"Cholesterol",
			"Obesity",
			"Thyroid",
			"Other:",
			"CBC",
			"&nbsp;",
			"Other",
			"HRA Score Under 25");

			for($x=0;$x<count($alr_ph_vals);$x+=2)
			{
				$var1 = "alr_ph_$x";
				$var2 = "alr_ph_".($x+1);

				?>
				<tr>
					<td colspan="2"><? if($alr_ph_vals[$x]!="&nbsp;") { ?><input type="checkbox" name="alr_ph_<?= $x ?>" value="1" <?= $$var1?"checked":"" ?>><? } ?><?= $alr_ph_vals[$x] ?></td>
					<td colspan="3"><? if($alr_ph_vals[$x+1]!="&nbsp;") { ?><input type="checkbox" name="alr_ph_<?= $x+1 ?>" value="1" <?= $$var2?"checked":"" ?>><? } ?><?= $alr_ph_vals[$x+1] ?></td>
				</tr>
				<?
			}

		?>


		<tr>
			<td rowspan="13"><b>Health<br>Practice<br>Review</b></td>

					<td>&nbsp;</td>
						<td align="center" width="65"><b>Qtr 1</b></td>
						<td align="center"><b>Qtr 2</b></td>
						<td align="center"><b>Qtr 3</b></td>
						<td align="center"><b>Qtr 4</b></td>
					</tr>
					<td><b>Date</b> (mm/dd/yyyy)</td>
						<td align="center" width="65"><input type="text" class="textbox date" name="q1date" value="<?= $q1date!="00/00/0000"?$q1date:"" ?>"></td>
						<td align="center" width="65"><input type="text" class="textbox date" name="q2date" value="<?= $q2date!="00/00/0000"?$q2date:"" ?>"></td>
						<td align="center" width="65"><input type="text" class="textbox date" name="q3date" value="<?= $q3date!="00/00/0000"?$q3date:"" ?>"></td>
						<td align="center" width="65"><input type="text" class="textbox date" name="q4date" value="<?= $q4date!="00/00/0000"?$q4date:"" ?>"></td>

					</tr>
					<?
					$hpr_vals = array(
								"Any changes to diet regimen",
								"Any changes to excercise regimen",
								"Smoking cessation",
								"Weight loss/gain",
								"Blood pressure control",
								"Medication regimen changes",
								"Diabetes Control",
								"Pneumonia vaccine",
								"Influenza vaccine",
								"PCP Follow-up",
								"Other:" );
					for($x=0;$x<count($hpr_vals);$x++)
					{
						$var1 = "hpr_$x"."_1";
						$var2 = "hpr_$x"."_2";
						$var3 = "hpr_$x"."_3";
						$var4 = "hpr_$x"."_4";
						?>
						<tr>
							<td><?= $hpr_vals[$x] ?></td>
							<td><input type="text" name="hpr_<?= $x ?>_1" value="<?= $$var1 ?>" style="width:65" maxlength="10"></td>
							<td><input type="text" name="hpr_<?= $x ?>_2" value="<?= $$var2 ?>" style="width:65" maxlength="10"></td>
							<td><input type="text" name="hpr_<?= $x ?>_3" value="<?= $$var3 ?>" style="width:65" maxlength="10"></td>
							<td><input type="text" name="hpr_<?= $x ?>_4" value="<?= $$var4 ?>" style="width:65" maxlength="10"></td>
						</tr>
						<?
					}

					?>


		<tr>
			<td rowspan="25"><b>Education/<br>Reinforcement<br>Provided</b></td>

					<?
					$erp_vals = array(
								"Limiting saturated fats",
								"Diabetes control",
								"High fiber diet",
								"Diet adequate in calcium",
								"Portion control",
								"Limiting sodium intake",
								"Other Diet",
								"Limit alcohol intake",
								"Colorectal cancer screening",
								"Mammogram",
								"Pap Smear",
								"Prostate health",
								"Bone density screening",
								"Eye exam",
								"Hearing screening",
								"Hearing protection",
								"Smoking cessation",
								"Seat belt use",
								"Limiting sun exposure",
								"Blood pressure control",
								"Medication compliance",
								"Pneumonia vaccine",
								"Influenza vaccine",
								"Other",
								);

					for($x=0;$x<count($erp_vals);$x++)
					{
						$var1 = "erp_$x"."_1";
						$var2 = "erp_$x"."_2";
						$var3 = "erp_$x"."_3";
						$var4 = "erp_$x"."_4";

						?>
						<tr>
							<td><?= $erp_vals[$x] ?></td>
							<td><input type="text" name="erp_<?= $x ?>_1" value="<?= $$var1 ?>" style="width:65" maxlength="10"></td>
							<td><input type="text" name="erp_<?= $x ?>_2" value="<?= $$var2 ?>" style="width:65" maxlength="10"></td>
							<td><input type="text" name="erp_<?= $x ?>_3" value="<?= $$var3 ?>" style="width:65" maxlength="10"></td>
							<td><input type="text" name="erp_<?= $x ?>_4" value="<?= $$var4 ?>" style="width:65" maxlength="10"></td>
						</tr>
						<?
					}

					?>


		</tr>

	</table>&nbsp;
	<center>
		<input type="submit" value="Save Followup" class="button">
	</center>
</form>

	<?
}
elseif($_GET['new'])
{

	?>
	<table align="center" width="100%">
		<tr>
			<Td class="system_message" colspan="2"><?= $_GET['message'] ?></Td>
		</tr>
		<tr>
			<td><form action="index.php?page=users" method="GET">
			<input type='hidden' name='page' value='<?= $_GET['page'] ?>'>
			<input type='hidden' name='type' value='<?= $_GET['type'] ?>'>
				<table id="search_table" class="disp_table">
					<tr>
						<td nowrap><b>Search</b> <input type="text" name="s" value="<?= $_GET['s'] ?>" class="textbox search"></td>
						<td><input type="image" name="submit" src="util/images/magnify2.png"></td>
						<td width="100%">&nbsp;</td>
						<input type="hidden" name="stat" value="<?= $_GET['stat'] ?>">
					</tr>
				</table>
			</td></form>
		</tr>
		<tr>
			<td align="right"><a href="index.php?page=followups&s=<?= $_GET['s'] ?>&stat=<?= $_GET['stat']?0:1 ?>">show <?= $_GET['stat']?"new only":"all" ?></a></td>
		</tr>
		<tr>
			<td>
				<table id="list_table" class="disp_table" width="100%" cellspacing="1" cellpadding="0" border="0">
				<tr>
					<th>Name</th>
					<th>Company</th>
					<th>Exam Date</th>
				</tr>
				<?
				if(!$_GET['stat']) $new_only = "AND ct_lab_results.labcorp_id IS NULL";

				$i = -1;
				$query .= "SELECT *,DATE_FORMAT(`EntryDate`,'%m-%d-%Y') date_fmt, concat(`ct_users`.`lastname`,', ',`ct_users`.`firstname`) name_fmt, companies.company company_name , ct_labcorp_pid.id pid_id, ct_lab_results.id results_id, ct_users.id patient_id
							FROM ct_hra,ct_labcorp_pid, ct_users
							LEFT JOIN `ct_users` companies ON (companies.id = ct_users.company)
							LEFT JOIN `ct_lab_results` ON (ct_lab_results.labcorp_id=ct_labcorp_pid.id)
							WHERE  ct_hra.labcorp_id = ct_labcorp_pid.id
								AND ct_labcorp_pid.ct_sws_id = ct_users.id $new_only
							ORDER BY EntryDate";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					extract($row);
					?>
					<tr class="row<?= $i*=-1 ?>">
						<td><a href="index.php?page=followups&new_followup=<?= $patient_id ?>&pid_id=<?= $pid_id ?>"><?= $name_fmt ?></a><?= $results_id?"":"&nbsp;<img src='util/images/new.png' border='0'>" ?></td>
						<td><?= $company_name ?></td>
						<td align="center"><?= $date_fmt ?></td>
					</tr>
					<?
				}
				?>


				</table>
			</td>
		</tr>

	</table>

	<?
}
else
{
	?>
	<table align="center" width="100%">
		<tr>
			<Td class="system_message" colspan="2"><?= $_GET['message'] ?></Td>
		</tr>
		<tr>
			<td><form action="index.php?page=users" method="GET">
			<input type='hidden' name='page' value='<?= $_GET['page'] ?>'>
			<input type='hidden' name='type' value='<?= $_GET['type'] ?>'>
				<table id="search_table" class="disp_table">
					<tr>
						<td nowrap>Search <input type="text" name="s" value="<?= $_GET['s'] ?>" class="textbox search"></td>
						<td><input type="image" name="submit" src="util/images/magnify2.png"></td>
						<td width="100%" align="right"><a href='index.php?page=followups&new=1'>+add new followup</td>
					</tr>
				</table>
			</td></form>
		</tr>
		<tr>
			<td>
				<table id="list_table" class="disp_table" width="100%" cellspacing="1" cellpadding="0" border="0">
				<tr>
					<th>Name</th>
					<th>Company</th>
					<th>Followup Date</th>
				</tr>
				<?
				$i = -1;
				$query .= "SELECT company,firstname,lastname,ct_followups.id as id, DATE_FORMAT(GREATEST(q1date,q2date,q3date,q4date),'%m-%d-%Y') date_fmt FROM ct_followups, ct_users WHERE ct_followups.patient = ct_users.id AND physician='{$GLOBALS['user_data']['id']}'";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					extract($row);
					?>
					<tr class="row<?= $i*=-1 ?>">
						<td><a href="index.php?page=followups&id=<?= $id ?>"><?= $firstname ?> <?= $lastname ?></a></td>
						<td><?= $company ?></td>
						<td align="center"><?= $date_fmt ?></td>
					</tr>
					<?
				}
				?>


				</table>
			</td>
		</tr>

	</table>
	</table>
	<?
}


?>