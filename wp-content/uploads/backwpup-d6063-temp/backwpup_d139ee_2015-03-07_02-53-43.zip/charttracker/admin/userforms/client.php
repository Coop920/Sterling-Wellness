<table align="center" id="form_table" width="100%">
		<tr valign='top'>
			<td>Last Login: <i><?= $date_fmt ?></i></td>
			<td align="right" colspan="4"><label><input type="checkbox" name="active" value="1" <?= $active?"CHECKED":"" ?>><b>Active</b></label></td>
		</tr>
		<tr valign='top'>
			<td>Company Name<br><input type="text" class="textbox" name="company" value="<?= $company ?>"></td>
			<td colspan="2" >Email<br><input type="text" class="textbox" name="email" value="<?= $email ?>"></td>

			<td valign="top" rowspan="9">
				Physicians
				<table>
				<?
				$assigned = array();
				$query = "SELECT user FROM ct_assigned_users WHERE client = '{$_GET['id']}'";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_assoc($result)) $assigned[]=$row['user'];

				$b = 0;
				$query = "SELECT id,firstname,lastname FROM ct_users WHERE usertype = 2";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					if($b==0) echo "<tr valign='top'>";

					?>
					<td><input type="checkbox" value="<?= $row['id'] ?>" name="assigned[]" <?= in_array($row['id'],$assigned)?"CHECKED":"" ?>><?= $row['firstname'] ?> <?= $row['lastname'] ?></td>
						<?
					if($b++==1)
					{
						echo "</tr>";
						$b=0;
					}
				}
				?>
				</table>
				Consultants
				<table>
				<?
				$assigned = array();
				$query = "SELECT user FROM ct_assigned_consultants WHERE client = '{$_GET['id']}'";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_assoc($result)) $assigned[]=$row['user'];

				$b = 0;
				$query = "SELECT id,firstname,lastname FROM ct_users WHERE usertype = 3";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					if($b==0) echo "<tr valign='top'>";

					?>
					<td><input type="checkbox" value="<?= $row['id'] ?>" name="cons[]" <?= in_array($row['id'],$assigned)?"CHECKED":"" ?>><?= $row['firstname'] ?> <?= $row['lastname'] ?></td>
						<?
					if($b++==1)
					{
						echo "</tr>";
						$b=0;
					}
				}

				?>
				</table>
			</td>


		</tr>
		<tr valign='top'>
			<td>Contact First Name<br><input type="text" class="textbox" name="firstname" value="<?= $firstname ?>"></td>
			<td colspan="2" >Contact Last Name<br><input type="text" class="textbox" name="lastname" value="<?= $lastname ?>"></td>
		</tr>
		<tr valign='top'>
			<td>Password<br><input type="password" class="textbox" name="password" id="password"></td>
			<td colspan="2">Retype Password<br><input type="password" class="textbox" name="password2" id="password2"></td>
		</tr>
		<tr valign='top'>
			<td class="helptext" colspan="3">only enter password to add or edit existing password</td>
		</tr>
		<tr valign='top'>
			<td colspan="3">Address<br><input type="text" class="textbox" name="address" value="<?= $address ?>"></td>
		</tr>
		<tr valign='top'>
			<td width="30%">City<br><input type="text" class="textbox" name="city" value="<?= $city ?>"></td>
			<td width="10%">State<br><select name="state"><?= show_states($state) ?></select></td>
			<td width="20%">Zip<br><input type="text" class="textbox" name="zip" value="<?= $zip ?>" size="5"></td>
		</tr>
		<tr valign='top'>
			<td>Primary Phone<br><input type="text" class="textbox" name="phone1" value="<?= $phone1 ?>"></td>
			<td colspan="2" >Secondary Phone<br><input type="text" class="textbox" name="phone2" value="<?= $phone2 ?>"></td>
		</tr>
		<tr valign='top'>
			<td>Client ID<br><input type="text" class="textbox" name="clientID" value="<?= $clientID ?>"></td>
			<td colspan="2" >Group Number<br><input type="text" class="textbox" name="groupnumber" value="<?= $groupnumber ?>"></td>
		</tr>
		<tr valign='top'>
			<td colspan="3">Custom Client Parameters</td>
		</tr>
		<tr valign='top'>
			<td colspan="3">
			<textarea name="custom" class="textbox" rows="4"><?= $custom ?></textarea>
			</td>
		</tr>


		<tr valign='top'>
			<td colspan="3">Locations</td>
		</tr>
		<tr valign='top'>
			<script>
			function add_to_locations()
			{
				//get current locations
				loc_array = new Array();
				loc_array = document.getElementById('locations').value.split("|");
				//add current locations
				loc_array.push(document.getElementById('loc').value);
				//sort the array
				loc_array.sort();
				//join and set the hidden field
				document.getElementById('locations').value = loc_array.join("|");
				//empty the multi select box so we can repopulate it.
				document.getElementById('location_list').options.length = 0;
				//loop through and add the new options
				for(x=1;x<loc_array.length;x++)
				{
					document.getElementById('location_list').options[x-1] = new Option(loc_array[x],loc_array[x]);
				}
				//empty the text box
				document.getElementById('loc').value='';
				//set focus to the locations box
				document.getElementById('loc').focus();
			}

			function remove_from_locations(index)
			{
				if(confirm('Remove "'+ document.getElementById('location_list').options[index].text +'" from locations?'))
				{
					//get current locations
					loc_array = new Array();
					loc_array = document.getElementById('locations').value.split("|");
					//remove the field no one loves
					loc_array.splice((index+1),1);
					//join and set the hidden field
					document.getElementById('locations').value = loc_array.join("|");
					//empty the multi select box so we can repopulate it.
					document.getElementById('location_list').options.length = 0;
					//loop through and add the new options
					var y=0;
					for(x=0;x<loc_array.length;x++)
					{
						if(loc_array[x].length>0) document.getElementById('location_list').options[y++] = new Option(loc_array[x],loc_array[x]);
					}

				}

			}
			</script>
			<td align="left" colspan="3"><input type="hidden" id="locations" name="locations" value="<?= $locations ?>">
				<input type="text" id="loc" class="textbox" style="width: 125px">&nbsp;<input type="button" class="button" value=">>" onclick="add_to_locations()"><br>
				<select id="location_list" multiple class="textbox" size="7" ondblclick="remove_from_locations(this.selectedIndex)">
					<?
					$locals = explode("|",$locations);
					for($x=1;$x<count($locals);$x++)
					{
						echo "<option>" , $locals[$x] , "</option>";
					}
					?>
				</select>
				<br><font class="helptext">double click to remove location</font>
			</td>
		</tr>