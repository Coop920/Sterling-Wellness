<?
list($dob_y,$dob_m,$dob_d) = explode("-",$dob);

function get_user_history_count( $user_id ) {
	// FIXME shows wrong count if has unlinked HRA
	$query='
		SELECT count(*) i, "labcorps" type FROM ct_labcorp_pid WHERE ct_sws_id="'.$user_id.'"
		UNION
		SELECT count(*) i, "hras" type FROM ct_hra,ct_labcorp_pid WHERE ct_labcorp_pid.id=ct_hra.labcorp_id AND ct_sws_id="'.$user_id.'"
		UNION
		SELECT count(*) i, "assessments" type FROM ct_assessments WHERE patient = "'.$user_id.'"
		UNION
		SELECT count(*) i, "followups" type FROM ct_followups WHERE patient = "'.$user_id.'"
		UNION
		SELECT count(*) i, "lab_results" type FROM ct_lab_results WHERE patient = "'.$user_id.'"
	';
	$count = 0;
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		$count += $row['i'];
	}
	return $count;
}

function get_user_uploades_count( $user_id ) {
	$query = '
		SELECT count(*) i
		FROM ct_uploads
		WHERE user_id = '.$user_id.'
	';
	$count = 0;
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
		$count += $row['i'];
	}
	return $count;
}

$user_history_count = get_user_history_count( (int) $id );
$user_uploades_count = get_user_uploades_count( (int) $id );
// TODO edit_history != $user_history_count + $user_uploades_count


?>
<script>
$(function() {
	$("#company").change( function() {
		 $.ajax({
			  url: "admin/workphone.php?company="+$("#company").val(),
			  cache: false,
			  success: function(html){

			  	$("#phone2").val(html)

			  }
			});


	});
});


</script>
<table align="center" id="form_table" width="100%">
		<tr valign='top'>
			<td><b>PID:&nbsp;<i><input type='text' name='new_PID' value='<?= $id ?>' /></i></b>&nbsp;&nbsp;&nbsp;<b>Last Login: <i><?= $date_fmt ?></i></b></td>
			<td colspan="2" align="right"><label><input type="checkbox" name="active" value="1" <?= $active?"CHECKED":"" ?>><b>Active</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
				<a href="#" onclick="window.open('history.php?id=<?= $id ?>',null,'height=400,width=300,status=no,toolbar=no,menubar=no,location=no,scrollbar=yes');" value="View History">View Patient History&nbsp;(<?php echo( $user_history_count ); ?>)</a>
				<br><a href="#" onclick="window.open('history_upload.php?id=<?= $id ?>',null,'height=400,width=300,status=no,toolbar=no,menubar=no,location=no,scrollbar=yes,resizable=yes');" value="Attached Forms">Attached Forms&nbsp;(<?php echo( $user_uploades_count ); ?>)</a>
				<br><a href="#" onClick="location='index.php?page=history_edit&user_id=<?php echo( (int)$id ); ?>'" >Edit history&nbsp;(<?php echo( $user_history_count + $user_uploades_count ); ?>)</a>
			</td>
		</tr>
		<tr valign='top'>
			<td>First Name<br><input type="text" class="textbox" name="firstname" value="<?= $firstname ?>"></td>
			<td colspan="2">Last Name<br><input type="text" class="textbox" name="lastname" value="<?= $lastname ?>"></td>
		</tr>
		<tr valign='top'>
			<td>Email<br><input type="text" class="textbox" name="email" value="<?= $email ?>"></td>
			<td colspan="2">Birthdate<br>
				<input type="text" class="textbox_s" name="dob_m" value="<?= $dob_m ?>" size="2" maxlength="2" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==2) dob_d.focus()">/
				<input type="text" class="textbox_s" name="dob_d" value="<?= $dob_d ?>" size="2" maxlength="2" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==2) dob_y.focus()">/
				<input type="text" class="textbox_s" name="dob_y" value="<?= $dob_y ?>" size="4" maxlength="4" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==4) ssn_1.focus()">
			</td>
		</tr>
		<tr valign='top'>
			<!--<td>PID</td>
			<td><input type="text" class="textbox" name="ssn" value="<?= $ssn ?>"></td>-->
			<td colspan="3">Company<br><select name="company" id="company"><option></option>
			<?

				$query = "SELECT id,company FROM ct_users WHERE usertype = 4";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					?><option value="<?= $row['id'] ?>" <?= $company==$row['id']?"SELECTED":"" ?>><?= $row['company'] ?></option><?

				}
			?></select>
			</td>
		</tr>
		<tr valign='top'>
			<td>Personal Physician<br><input type="text" class="textbox" name="phys" value="<?= $phys ?>"></td>
			<td colspan="2">Insurance Provider<br><input type="text" class="textbox" name="ins" value="<?= $ins ?>"></td>
		</tr>
		<tr valign='top'>
			<td>Password<br><input type="password" class="textbox" name="password" id="password"></td>
			<td colspan="2">Retype Password<br><input type="password" class="textbox" name="password2" id="password2"></td>
		</tr>

		<tr valign='top'>
			<td class="helptext" colspan="3">only enter password to add or edit existing password</td>
		</tr>
		<tr valign='top'>
			<td colspan="3">Address<input type="text" class="textbox" name="address" value="<?= $address ?>"></td>
		</tr>
		<tr valign='top'>
			<td width="50%">City<br><input type="text" class="textbox" name="city" value="<?= $city ?>"></td>
			<td width="20%">State<br><select name="state"><?= show_states($state) ?></select></td>
			<td width="30%">Zip<br><input type="text" class="textbox" name="zip" value="<?= $zip ?>" size="5"></td>
		</tr>
		<tr valign='top'>
			<td>Home Phone<br><input type="text" class="textbox" name="phone1" value="<?= $phone1 ?>"></td>
			<td colspan="2">Work Phone<br><input type="text" class="textbox" name="phone2" id="phone2" value="<?= $phone2 ?>"></td>
		</tr>