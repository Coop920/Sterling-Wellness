	<table align="center" id="form_table" width="100%" border="0">
			<tr valign='top'>
				<td colspan="2">Last Login: <i><?= $date_fmt ?></i></td>
				<td colspan="4" align="right"><label><input type="checkbox" name="active" value="1" <?= $active?"CHECKED":"" ?>><b>Active</b></label></td>
			</tr>
			<tr valign='top'>
				<td>First Name<br><input type="text" class="textbox" name="firstname" value="<?= $firstname ?>"></td>
				<td colspan="2">Last Name<br><input type="text" class="textbox" name="lastname" value="<?= $lastname ?>"></td>

				<td rowspan="11" valign="top">
					<b>Clients</b>
					<table>
					<?
					$assigned = array();
					$query = "SELECT client FROM ct_assigned_consultants WHERE user = '{$_GET['id']}'";
					$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
					while($row = mysql_fetch_assoc($result)) $assigned[]=$row['client'];


					$query = "SELECT id,company FROM ct_users WHERE usertype = 4";
					$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
					while($row = mysql_fetch_array($result, MYSQL_ASSOC))
					{
						if($b==0) echo "<tr valign='top'>";

						?>
							<td><input type="checkbox" value="<?= $row['id'] ?>" name="assigned[]" <?= in_array($row['id'],$assigned)?"CHECKED":"" ?>><?= $row['company'] ?></td>
						<?
						if($b++==1)
						{
							echo "</tr>";
							$b=0;
						}
					}
					?>
					</table>
				</td>

			</tr>
			<tr valign='top'>
				<td>Practice<br><input type="text" class="textbox" name="company" value="<?= $company ?>"></td>
				<td colspan="2">Title<br><input type="text" class="textbox" name="title" value="<?= $title ?>"></td>
			</tr>
			<tr valign='top'>
				<td>Email<br><input type="text" class="textbox" name="email" value="<?= $email ?>"></td>
			</tr>
			<tr valign='top'>
			<td>Password<br><input type="password" class="textbox" name="password" id="password"></td>
			<td colspan="2">Retype Password<br><input type="password" class="textbox" name="password2" id="password2"></td>
			</tr>
			<tr valign='top'>
				<td class="helptext" colspan="3">only enter password to add or edit existing password</td>
			</tr>
			<tr valign='top'>
				<td colspan="3">Address<br><input type="text" class="textbox" name="address" value="<?= $address ?>"></td>
			</tr>
			<tr valign='top'>
				<td width="30%">City<br><input type="text" class="textbox" name="city" value="<?= $city ?>"></td>
				<td width="10%">State<br><select name="state"><?= show_states($state) ?></select></td>
				<td width="20%">Zip<br><input type="text" class="textbox" name="zip" value="<?= $zip ?>" size="5"></td>
			</tr>
			<tr valign='top'>
				<td>Primary Phone<br><input type="text" class="textbox" name="phone1" value="<?= $phone1 ?>"></td>
				<td colspan="2">Secondary Phone<br><input type="text" class="textbox" name="phone2" value="<?= $phone2 ?>"></td>
			</tr>
			<tr valign='top'>
				<td>Signature<br><input type="file" name="signature"></td>
				<td><? if(file_exists("signatures/{$_GET['id']}.jpg")) { ?><img src="signatures/<?= $_GET['id'] ?>.jpg"><? } ?></td>
			</tr>