<table align="center" id="form_table" width="100%">

		<tr valign='top'>
			<td colspan="2">Last Login: <i><?= $date_fmt ?></i></td>
			<td colspan="2" align="right"><label><input type="checkbox" name="active" value="1" <?= $active?"CHECKED":"" ?>><b>Active</b></label></td>
		</tr>
		<tr valign='top'>
			<td>First Name<br><input type="text" class="textbox" name="firstname" value="<?= $firstname ?>"></td>
			<td colspan="2">Last Name<br><input type="text" class="textbox" name="lastname" value="<?= $lastname ?>"></td>
		</tr>
		<tr valign='top'>
			<td>Email<br><input type="text" class="textbox" name="email" value="<?= $email ?>"></td>
		</tr>
		<tr valign='top'>
			<td>Password<br><input type="password" class="textbox" name="password" id="password"></td>
			<td colspan="2">Retype Password<br><input type="password" class="textbox" name="password2" id="password2"></td>
		</tr>
		<tr valign='top'>
			<td class="helptext" colspan="2">only enter password to add or edit existing password</td>
		</tr>
		<tr valign='top'>
			<td colspan="3">Address<br><input type="text" class="textbox" name="address" value="<?= $address ?>"></td>
		</tr>
		<tr valign='top'>
			<td width="50%">City<br><input type="text" class="textbox" name="city" value="<?= $city ?>"></td>
			<td width="20%">State<br><select name="state"><?= show_states($state) ?></select></td>
			<td width="30%">Zip<br><input type="text" class="textbox" name="zip" value="<?= $zip ?>" size="5"></td>
		</tr>
		<tr valign='top'>
			<td>Primary Phone<br><input type="text" class="textbox" name="phone1" value="<?= $phone1 ?>"></td>
			<td colspan="2">Secondary Phone<br><input type="text" class="textbox" name="phone2" value="<?= $phone2 ?>"></td>
		</tr>
