<div align="right">
	<input type="button" value="Participant History" class="button" onclick="window.open('history.php?id=<?= $_GET['patient'] ?>',null,'height=400,width=300,status=no,toolbar=no,menubar=no,location=no,scrollbar=yes');">
	<input type="button" value="Participant Information" class="button" onclick="document.location='index.php?page=users&id=<?= $_GET['patient'] ?>&returntype=5'">
	<?
	switch($_GET['test'])
	{
		case "Labcorp Results":

		break;

		case "HRA Results":

		break;

		case "Health Assessment":
			?>
			<input type="button" value="Update Health Assessment" class="button" onclick="document.location='index.php?page=assessment&assess_id=<?= $_GET['id'] ?>&returntype=5'">
			<?
		break;

		case "Followup Consultation":
			?>
			<input type="button" value="Edit Follow Up" class="button" onclick="document.location='index.php?page=followups&id=<?= $_GET['id'] ?>'">
			<?
		break;

		case "Notification of Lab Results":
			?>
			<input type="button" value="Edit Notification" class="button" onclick="document.location='index.php?page=results&results_id=<?= $_GET['id'] ?>'">
			<?
		break;
		default:
			echo "unknown test";
		break;

	}
	?>


</div>
<?

#make sure they're logged in
check_auth();
#extra check... no one, under any circumstance can see this unless they're an admin
if($GLOBALS['user_data']['usertype']!=1)
die("You do not have permission to view this page. Please log in.");
if($_GET['test'])
{

	switch($_GET['test'])
	{
		case "Labcorp Results":
			show_labcorp_no_form($_GET['id'],true);
		break;

		case "HRA Results":
			show_hra_form($_GET['id']);
		break;

		case "Health Assessment":
			show_health_assessment($_GET['id']);
		break;

		case "Followup Consultation":
			show_followup($_GET['id']);
		break;

		case "Notification of Lab Results":
			show_notification($_GET['id']);
		break;
		default:
			echo "unknown test";
		break;

	}

}
?>