<?
/*
Consultants will have access to the system as configured by the site administrator.  The
first thing they will see when going to the CTA will be a login screen.  Upon a successful
login to the site, Consultants will see a landing page with options to view Health
Assessment Client Listing.


Accessing Health Assessment Listing
After choosing to view the Health Assessment Listing the consultant will be given a list of
Clients who they have access to.  Once the Client is chosen a list of all participants available
for Health Assessments will be provided.  The Consultant will be able to generate a Health
Assessment Worksheet.  This worksheet will be pre-populated with the following
information, which will not be editable by the Consultant:

� Participant Name
� Phone Number
� Date (automatically generated)
� Location (Drop-down list of Client Locations)
� Existing Physicians Referral
� Existing Reason for Referral

The Consultant will be able to add information to the Health Assessment Worksheet.  The
information they can Add/Edit is denoted in Appendix C.
*/

if($_POST['sub'])
{

	if(is_array($_POST['rx'])) $str_rx = implode(",",$_POST['rx']);


	if($_POST['a_id']!="")
	{
		$query = "UPDATE `ct_assessments` SET
			`patient` = '{$_POST['patient']}',
		    `rx` = '$str_rx',
		    `other_box` = '{$_POST['other_box']}',
	    	`other_text` = '{$_POST['other_text']}',
		    `r_systolic` = '{$_POST['r_systolic']}',
		    `r_diastolic` = '{$_POST['r_diastolic']}',
		    `r_pulse` = '{$_POST['r_pulse']}',
		    `r_weight` = '{$_POST['r_weight']}',
		    `r_height` = '{$_POST['r_height']}',
		    `r_waist` = '{$_POST['r_waist']}',
		    `r_bodyfat` = '{$_POST['r_bodyfat']}',
		    `r_bmi` = '{$_POST['r_bmi']}',
		    `phys_ref` = '{$_POST['phys_ref']}',
		    `rfr` = '{$_POST['rfr']}',
		    `goals` = '{$_POST['goals']}',
		    `ft_results` = '{$_POST['ft_results']}',
		    `ft_ref` = '{$_POST['ft_ref']}',
		    `ft_rfr` = '{$_POST['ft_rfr']}',
		    `fl_results` = '{$_POST['fl_results']}',
		    `fl_ref` = '{$_POST['fl_ref']}',
		    `fl_rfr` = '{$_POST['fl_rfr']}',
		    `bone_density` = '{$_POST['bone_density']}',
		    `bd_ref` = '{$_POST['bd_ref']}',
		    `bd_rfr` = '{$_POST['bd_rfr']}',
		    `sign_bd` = '{$_POST['sign_bd']}',
		    `sign_fl` = '{$_POST['sign_fl']}',
		    `sign_ft` = '{$_POST['sign_ft']}',
		    `location` = '{$_POST['location']}'
		    WHERE id = '{$_POST['a_id']}'
			";

			$message = "Updated";
	}

	mysql_query($query) or die($query . "<p>" . mysql_error());

	header("Location: index.php?page=history&patient={$_POST['patient']}&test=Health Assessment&id={$_POST['a_id']}");

}
else if(is_numeric($_GET['new_patient']) || is_numeric($_GET['assess_id']))
{

	if($_GET['assess_id'])
	{
		$query = "SELECT * FROM ct_assessments WHERE id='{$_GET['assess_id']}'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

		$_GET['new_patient']=$patient;
	}


	$query = "SELECT * FROM ct_users WHERE id='{$_GET['new_patient']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	?>
	  <script>
	  $(document).ready(function(){
	    $("input#other_box").change(function () {
	      $("input#other_text").slideToggle(40);
	     });
		 });
	  </script>
	<form method="POST" action="index.php?page=assessment">
	<input type="hidden" name="sub" value="1">
	<input type="hidden" name="patient" value="<?= $_GET['new_patient'] ?>">
	<input type="hidden" name="a_id" value="<?= $_GET['assess_id'] ?>">
	<? if($_GET['assess_id']!="") { ?>
		<SCRIPT LANGUAGE="JavaScript">
			function popUp(URL) {
			day = new Date();
			id = day.getTime();
			eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=600,height=800,left = 640,top = 225');");
			}
		</script>
		<div align="right"><a href="javascript:popUp('assessment_print.php?assess_id=<?= $_GET['assess_id'] ?>')" title='print this health assessment' alt='print this health assessment'><img src='util/images/action_print.gif' border=0 align="right">Print this Health Assessment</a></div><? } ?>
	<table cellpadding="3">
		<tr>
			<td><b>Name</b>:</td>
			<td><?= $firstname ?> <?= $lastname ?></td>
		</tr>
		<tr>
			<td><b>Phone Number:</b></td>
			<td><?= $phone ?></td>
		</tr>
		<tr>
			<td><b>Date:</b></td>
			<td><?= date("m-d-Y") ?></td>
		</tr>
		<tr>
			<td><b>Location:</b></td>
			<td>
			<?
			$query = "SELECT locations FROM ct_users WHERE id = '$company'";
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

			$local_array = explode("|",$locations)

			?>
			<select name="location">
			<?
			for($x=0;$x<count($local_array);$x++)
			{
				?><option <?= $location==$local_array[$x]?"SELECTED":"" ?>><?= $local_array[$x] ?></option><?
			}
			?>
			</select></td>
		</tr>
	</table>
	<br>
	<table id="list_table" class="disp_table" cellspacing="1" cellpadding="3" width="100%" border="0">
		<tr>
			<th>Health Assessment</th>
			<th>Results</th>
			<th>Physician Referral</th>
			<th>Reason for Referral</th>
			<th>Comments/Reccomendations/<br>Goals</th>
		</tr>
		<tr class="row-1">
			<td valign="top">
				<b>Health Screening Analysis</b>
				<p>
				<b>RX</b><br>
				<?
				$rs_select = explode(",",$rx);

				$query = "SELECT * FROM ct_option_prs WHERE `active` = '1' ORDER BY text";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($rxs = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					?>
					<input type="checkbox" name="rx[]" value="<?= $rxs['id'] ?>" <?= in_array($rxs['id'],$rs_select)?"CHECKED":"" ?>><?= $rxs['text'] ?><br>
					<?
				}
				?>
				<input type="checkbox" id="other_box" name="other_box" value="16" <?= $other_box?"CHECKED":"" ?>>Other <input type="text" id="other_text" name="other_text" value="<?=  $other_text ?>" class="textbox" <?= !$other_box?"style='display:none'":"" ?>>

				</p>

			</td>
			<td valign="top">
			<b>Blood Pressure</b>
				<table align="center">
				<tr>
					<td>Systolic</td>
					<td><input type="text" name="r_systolic" value="<?= $r_systolic ?>" class="textbox" style="width: 35px"></td>
				</tr>
				<tr>
					<td>Diastolic</td>
					<td><input type="text" name="r_diastolic" value="<?= $r_diastolic ?>" class="textbox" style="width: 35px"></td>
				</tr>
				<tr>
					<td>Pulse</td>
					<td><input type="text" name="r_pulse" value="<?= $r_pulse ?>" class="textbox" style="width: 35px"></td>
				</tr>
				<tr>
					<td>Weight</td>
					<td><input type="text" name="r_weight" value="<?= $r_weight ?>" class="textbox" style="width: 35px"></td>
				</tr>
				<tr>
					<td>Height</td>
					<td><input type="text" name="r_height" value="<?= $r_height ?>" class="textbox" style="width: 35px"></td>
				</tr>
				<tr>
					<td>Waist</td>
					<td><input type="text" name="r_waist" value="<?= $r_waist ?>" class="textbox" style="width: 35px"></td>
				</tr>
				<tr>
					<td>Body Fat</td>
					<td><input type="text" name="r_bodyfat" value="<?= $r_bodyfat ?>" class="textbox" style="width: 35px"></td>
				</tr>
				<tr>
					<td>BMI</td>
					<td><input type="text" name="r_bmi" value="<?= $r_bmi ?>" class="textbox" style="width: 35px"></td>
				</tr>
				</table>

			</td>
			<td valign="top">
				<input type="radio" name="phys_ref" value="Y" <?= $phys_ref=="Y"?"CHECKED":"" ?>>Yes<br>
				<input type="radio" name="phys_ref" value="N" <?= $phys_ref=="N"?"CHECKED":"" ?>>No
			</td>
			<td valign="top"><textarea name="rfr" style="height:320;"><?= $rfr ?></textarea></td>
			<td valign="top"><textarea name="goals" style="height:320;width:100%"><?= $goals ?></textarea></td>
		</tr>
		<tr class="row-1">
			<td>Fitness Test (3 minute step test)</td>
			<td><textarea name="ft_results" style="height:50;"><?= $rfr ?></textarea></td>
			<td><input type="radio" name="ft_ref" value="Y" <?= $ft_ref=="Y"?"CHECKED":"" ?>>Yes<br>
				<input type="radio" name="ft_ref" value="N" <?= $ft_ref=="N"?"CHECKED":"" ?>>No</td>
			<td><textarea name="ft_rfr" style="height:50;"><?= $ft_rfr ?></textarea></td>
			<td><input type="checkbox" name="sign_ft" value="1" <?= $sign_ft?"CHECKED":"" ?>>Sign</td>
		</tr>
		<tr class="row-1">
			<td>Flexibility (Sit and Reach)</td>
			<td><textarea name="fl_results" style="height:50;"><?= $rfr ?></textarea></td>
			<td><input type="radio" name="fl_ref" value="Y" <?= $fl_ref=="Y"?"CHECKED":"" ?>>Yes<br>
				<input type="radio" name="fl_ref" value="N" <?= $fl_ref=="N"?"CHECKED":"" ?>>No</td>
			<td><textarea name="fl_rfr" style="height:50;"><?= $fl_rfr ?></textarea></td>
			<td><input type="checkbox" name="sign_fl" value="1" <?= $sign_fl?"CHECKED":"" ?>>Sign</td>
		</tr>
		<tr class="row-1">
			<td>Bone Density</td>
			<td>
				<input type="radio" name='bone_density' value="1" <?= $bone_density=="1"?"CHECKED":"" ?>>Normal<br>
				<input type="radio" name='bone_density' value="2" <?= $bone_density=="2"?"CHECKED":"" ?>>Osteopenia<br>
				<input type="radio" name='bone_density' value="3" <?= $bone_density=="3"?"CHECKED":"" ?>>Osteoporosis
			</td>
			<td><input type="radio" name="bd_ref" value="Y" <?= $bd_ref=="Y"?"CHECKED":"" ?>>Yes<br>
				<input type="radio" name="bd_ref" value="N" <?= $bd_ref=="N"?"CHECKED":"" ?>>No</td>
			<td><textarea name="bd_rfr" style="height:50;"><?= $bd_rfr ?></textarea></td>
			<td><input type="checkbox" name="sign_bd" value="1" <?= $sign_bd?"CHECKED":"" ?>>Sign</td>
		</tr>
	</table>
	&nbsp;
	<center>
		<input type="submit" class="button" style="width:75px" value="Save">
	</center>
	</form>
	<?

}
else if(is_numeric($_GET['patient_list']))
{
	$query = "SELECT CONCAT(firstname,' ',lastname)  name FROM ct_users WHERE id='{$_GET['patient_list']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));


	$query = "SELECT DATE_FORMAT(`add_date`,'%M %d, %Y') add_date_f,id FROM ct_assessments WHERE `patient` = '{$_GET['patient_list']}' ORDER BY add_date DESC";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	?>
		<table id="list_table" cellpadding="5" cellspacing="0" width="100%">
		<tr>
			<th colspan='4'><a href="#" onclick="jqalert('These are all the health assessments for <?= $name ?>.', 'More Information', {icon: &quot;util/images/info.png&quot;})"><img src="util/images/important.png" align="right" border="0"></a><?= $name ?></th>
		</tr>
		<?
		$i=1;
		while($row = mysql_fetch_array($result, MYSQL_ASSOC))
		{
			$i*=-1;
			echo "<tr class='row". $i . "'>";
			echo "<td><a href='index.php?assess_id={$row['id']}'>{$row['add_date_f']}</a></td>";
			echo "</tr>";
		}
		?>
		</table>
	<?
}

?>