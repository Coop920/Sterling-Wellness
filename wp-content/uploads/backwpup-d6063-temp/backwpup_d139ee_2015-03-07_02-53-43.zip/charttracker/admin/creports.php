<?
/*Client Reports
Each year: Date of service, Participants name, first and last; list of
labs we did on them, client account number, - this is an internal report
*/

			ob_start();
			?>
				<div><a href="index.php?page=ureports">Show All</a></div>
				<div><a href="index.php?page=ureports&type=2">Physicians</a></div>
				<div><a href="index.php?page=ureports&type=3">Consultants</a></div>
				<div><a href="index.php?page=creports">Clients</a></div>
			<?php
				$subnav = ob_get_contents();
			ob_end_clean();


if($_GET['id']>0)
{

		if($_GET['start_date']=="") $_GET['start_date']=date("m/d/").(date("Y")-1);
		if($_GET['end_date']=="") $_GET['end_date']=date("m/d/Y");

		$query = "SELECT *,IF(`lastlogin`='0000-00-00 00:00:00','never',DATE_FORMAT(`lastlogin`,'%m-%d-%Y')) date_fmt FROM ct_users WHERE id='{$_GET['id']}'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

		?>

		<table align="center" id='list_table' class='disp_table' cellpadding="4" width="100%">
			<tr>
				<th colspan="4"><h3><?= $usertypes[$usertype] ?> Information</h3></th>
			</tr>

			<tr class="row-1">
				<td align="right"><b>Client</b></td>
				<td><?= $company ?></td>
				<td align="right"><b>Contact</b></td>
				<td><?= $firstname ?> <?= $lastname ?></td>
				</tr>
			<tr class="row-1"><td align="right"><b>Email</b></td>
				<td><?= $email ?></td>

				<td align="right"><b>Last Login</b></td>
				<td><?= $date_fmt ?></i></td>
				<!--<td align="right"><b>Status</b></td>
				<td><?= $active?"Active":"" ?></td>-->

			</tr>
			<tr class="row-1"><td align="right"><b>Company ID</b></td>
				<td><?= $clientID ?></td>

				<td align="right"><b>Status</b></td>
				<td><?= $active?"Active":"Inactive" ?></td>

			</tr>

			<tr class="row-1">
				<th colspan="4"><h3>Participant Data</h3></th>
			</tr>
			<tr class="row-1">
				<td colspan="4">

	<script>
	  $(document).ready(function(){
	    $('.date').datepicker();
	  });
	  </script>



	  <table style="float:right;border:2px solid #D2D3CD" cellpadding="6" cellspacing="0">
				<form action="index.php">
				<input type="hidden" name="page" value="creports">
				<input type="hidden" name="id" value="<?= $_GET['id'] ?>">
					<tr>
						<th colspan="3">Search by Date Range</th>
					</tr>
					<tr>
						<td>From:</td>
						<td><input type="text" class="textbox date" name="start_date" size="10" value="<?= $_GET['start_date'] ?>"></td>
					</tr>
					<Tr>
						<td>To:</td>
						<td><input type="text" class="textbox date" name="end_date" size="10" value="<?= $_GET['end_date'] ?>"></td>
						<td><input type="submit" value=">>" class="button"></td>
					</tr>
					</form>
				</table>


				<?

					$query = "SELECT *,id p_id FROM ct_users WHERE usertype='5' AND `company`='{$_GET['id']}' AND `lastname` IS NOT NULL";
					$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
					while($row = mysql_fetch_array($result, MYSQL_ASSOC))
					{
						extract($row);
						#get all the procedures for these participants, then

						$bt_part = "BETWEEN STR_TO_DATE('{$_GET['start_date']}', '%m/%d/%Y') AND STR_TO_DATE('{$_GET['end_date']}', '%m/%d/%Y')";

						$query = "

						SELECT id, DATE_FORMAT(`import_date`,'%m-%d-%Y') date_f, 'Labcorp Results' test FROM ct_labcorp_pid WHERE ct_sws_id='{$p_id}' AND import_date $bt_part
						UNION
						SELECT ct_hra.id, DATE_FORMAT(ct_hra.`import_date`,'%m-%d-%Y') date_f, 'HRA Results' test FROM ct_hra,ct_labcorp_pid WHERE ct_labcorp_pid.id=ct_hra.labcorp_id AND ct_sws_id='{$p_id}' AND ct_hra.`import_date`  $bt_part
						UNION
						SELECT id , DATE_FORMAT(`add_date`,'%m-%d-%Y') date_f, 'Health Assessment' test FROM ct_assessments WHERE patient = '{$p_id}' AND `add_date`  $bt_part
						UNION
						SELECT id,  DATE_FORMAT(q1date,'%m-%d-%Y') date_f , '1st Quarter Followup Consultation' test FROM ct_followups WHERE patient = '{$p_id}' AND q1date  $bt_part
						UNION
						SELECT id,  DATE_FORMAT(q2date,'%m-%d-%Y') date_f , '2nd Quarter Followup Consultation' test FROM ct_followups WHERE patient = '{$p_id}' AND q2date  $bt_part
						UNION
						SELECT id,  DATE_FORMAT(q3date,'%m-%d-%Y') date_f , '3rd Quarter Followup Consultation' test FROM ct_followups WHERE patient = '{$p_id}' AND q3date $bt_part
						UNION
						SELECT id,  DATE_FORMAT(q4date,'%m-%d-%Y') date_f , '4th Quarter Followup Consultation' test FROM ct_followups WHERE patient = '{$p_id}' AND q4date $bt_part
						UNION
						SELECT id, DATE_FORMAT(`date`,'%m-%d-%Y') date_f, 'Notification of Lab Results' test FROM ct_lab_results WHERE patient = '{$p_id}' AND `date` $bt_part

						ORDER BY date_f DESC";

						$result2 = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
						if(mysql_numrows($result2)) echo "<b>$firstname $lastname<br></b>";
						while($row2 = mysql_fetch_array($result2, MYSQL_ASSOC))
						{
							extract($row2);

							if(strpos($test,"Follow")!== false)
							{
								$test_link="Followup Consultation";
							}
							else
							{
								$test_link=$test;
							}


							?>
							&nbsp;&nbsp;&nbsp;<a href="index.php?page=history&patient=<?= $p_id ?>&test=<?= $test_link ?>&id=<?= $id ?>"><?= $date_f ?>&nbsp;-&nbsp;<?= $test ?></a><br>
							<?
							$totals[$test]++;
						}



					}

				?>

				<p><b>Totals:<br></b>
				<table cellpadding="0" cellspacing="0">
				<?
				if(is_array($totals))
				{
					arsort($totals);
					foreach ($totals as $test => $count)
					{
						echo "<tr><td>&nbsp;&nbsp;&nbsp;$test:</td><Td>&nbsp;&nbsp;&nbsp;$count</td></tr>";
					}
				}
				?></table>
				</p>

				</td>
			</tr>
		</table>

		<?


}
else
{
	?>
	<table align="center" width="100%">
		<?php
			if($_GET['message'])
			{
		?>
		<tr>
			<Td class="system_message" colspan="2"><?= $_GET['message'] ?></Td>
		</tr>
		<?php
			}
		?>
		<tr>
			<td>



			</td>
		</tr>
		<tr>
			<td><form action="index.php?page=users" method="GET">
			<input type='hidden' name='page' value='<?= $_GET['page'] ?>'>
			<input type='hidden' name='type' value='<?= $_GET['type'] ?>'>
				<table id="search_table" class="disp_table">
					<tr>
						<td nowrap><b>Search</b> <input type="text" name="s" value="<?= $_GET['s'] ?>" class="textbox search"></td>
						<td><input type="image" name="submit" src="util/images/magnify2.png"></td>
						<td width="100%"></td>
					</tr>
				</table>
			</td></form>
		</tr>
		<tr>
			<td>
				<table id="list_table" class="disp_table" width="100%" cellspacing="1" cellpadding="3" border="0">
				<tr>
					<th>Company</th>
				</tr>
				<?
				$i=1;
				$query = "SELECT * FROM ct_users WHERE usertype = '4'";
				if($_GET['s']!="") $query .= " AND (
													firstname LIKE('%{$_GET['s']}%')
												OR
													lastname LIKE('%{$_GET['s']}%')
												OR
													CONCAT(`firstname`,' ',`lastname`) LIKE('%{$_GET['s']}%')
												OR
													CONCAT(`lastname`,', ',`firstname`) LIKE('%{$_GET['s']}%')
												OR
													email LIKE('%{$_GET['s']}%')
												OR
													company LIKE('%{$_GET['s']}%')
												)";
				$query .=" ORDER BY company";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($row = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					extract($row);
					?>
					<tr class="row<?= $i*=-1 ?>">
						<td><a href="index.php?page=<?= $page ?>&id=<?= $id ?>"><?= $company ?></a></td>
					</tr>
					<?
				}
				?>
				</table>
			</td>
		</tr>

	</table>
	<?
}


?>