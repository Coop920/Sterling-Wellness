<?
if(count($_POST)>1)
{
	#These are all of the fields in the DB that will be updated.  I put them in an array because
	#this was easier than having to update all of the queries everytime a new field is added
	$fields_to_edit = array('rating','mostlike1','mostlike2','mostlike3','mostlike4','mostlike5','mostlike6','mostlike7','mostlike8','mostlike9','mostlike10','mostlike_other','leastlike1','leastlike2','leastlike3','leastlike4','leastlike5','leastlike6','leastlike7','leastlike8','leastlike9','leastlike10','leastlike_other','part_again','importance','importance_comment','wouldlike1','wouldlike2','wouldlike3','wouldlike4','wouldlike5','wouldlike6','wouldlike7','wouldlike_other','full_comments');
	
	#build out the query
	for($x=0;$x<count($fields_to_edit);$x++)
	{
		$insert_array[] = "`{$fields_to_edit[$x]}`='{$_POST[$fields_to_edit[$x]]}'";
	}
	$insert_array[] = "`completed`=NOW()";
	
	if(is_array($insert_array))
	{
		$query = "INSERT INTO `ct_surveys` SET " . implode(", ",$insert_array);
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		
		$query = "UPDATE `ct_labcorp_pid` SET survey_id = '".mysql_insert_id()."' WHERE id='".$_POST['labcorp_id']."'";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		
	}
	header("Location: index.php?page=survey");
}
	

$query = "SELECT id labcorp_id FROM ct_labcorp_pid WHERE ct_sws_id='{$GLOBALS['user_data']['id']}' AND survey_id IS NULL";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) 
{
	extract(mysql_fetch_array($result));
	?>
	<div id='page_head'>Satisfaction Survey</div>
	&nbsp;
	<form action="index.php?page=survey" method="POST">
	<input type="hidden" name="labcorp_id" value="<?= $labcorp_id ?>">
	<table align="center" id="form_table">
			
			
			<tr>
				<td>How did rate the onsite wellness screenings? (choose one)</td>
			</tr>
			<tr>
				<td>
				<input type="radio" name="rating" value="1">Excellent<br>
				<input type="radio" name="rating" value="2">Good<br>
				<input type="radio" name="rating" value="3">Average<br>
				<input type="radio" name="rating" value="4">Fair<br>
				<input type="radio" name="rating" value="5">Poor<br>
				</td>
			</tr>
			
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>What did you <i>most</i> like about the wellness screenings and consultations? (check all that apply)</td>
			</tr>
			<tr>
				<td>
				<input type="checkbox" name="mostlike1" value="1">Conveniece of Onsite Lab Testing<br>
				<input type="checkbox" name="mostlike2" value="1">Health Risk Appraisal Questionnaire<br>
				<input type="checkbox" name="mostlike3" value="1">Nutrition Consultation<br>
				<input type="checkbox" name="mostlike4" value="1">Blood Pressure Screening<br>
				<input type="checkbox" name="mostlike5" value="1">Weight & Body Composition Analysis<br>
				<input type="checkbox" name="mostlike6" value="1">Fitness Consultation<br>
				<input type="checkbox" name="mostlike7" value="1">3-Minute Step Test<br>
				<input type="checkbox" name="mostlike8" value="1">Sit & Reach Test<br>
				<input type="checkbox" name="mostlike9" value="1">Educational Material<br>
				<input type="checkbox" name="mostlike10" value="1">Other: <input type="text" name="mostlike_other" class="textbox_s"><br>
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>What did you <i>least</i> like about the wellness screenings and consultations? (check all that apply)</td>
			</tr>
			<tr>
				<td>
				<input type="checkbox" name="leastlike1" value="1">Conveniece of Onsite Lab Testing<br>
				<input type="checkbox" name="leastlike2" value="1">Health Risk Appraisal Questionnaire<br>
				<input type="checkbox" name="leastlike3" value="1">Nutrition Consultation<br>
				<input type="checkbox" name="leastlike4" value="1">Blood Pressure Screening<br>
				<input type="checkbox" name="leastlike5" value="1">Weight & Body Composition Analysis<br>
				<input type="checkbox" name="leastlike6" value="1">Fitness Consultation<br>
				<input type="checkbox" name="leastlike7" value="1">3-Minute Step Test<br>
				<input type="checkbox" name="leastlike8" value="1">Sit & Reach Test<br>
				<input type="checkbox" name="leastlike9" value="1">Educational Material<br>
				<input type="checkbox" name="leastlike10" value="1">Other: <input type="text" name="leastlike_other" class="textbox_s"><br>
				</td>
			</tr>	
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>Are you likely to participate in future onsite wellness screenings?</td>
			</tr>
			<tr>
				<td>
				<input type="radio" name="part_again" value="1">Yes<br>
				<input type="radio" name="part_again" value="0">No<br>
				
				</td>
			</tr>
			
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>How would you rate the importance an value of your Lab Results and Personal Wellness Profile in<br>making future life-style changes? (choose one)</td>
			</tr>
			<tr>
				<td>
				<input type="radio" name="importance" value="1">Highly Important and Valuable<br>
				<input type="radio" name="importance" value="2">Somewhat Important and Valuable<br>
				<input type="radio" name="importance" value="3">No Importance or Value<br>
				Comments:<br>
				<input type="text" name="importance_comment" class="textbox">
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td>What other onsite programs related to Health and Wellness would you like? (check all that apply)</td>
			</tr>
			<tr>
				<td>
				<input type="checkbox" name="wouldlike1" value="1">Weight Watchers Program at Work<br>
				<input type="checkbox" name="wouldlike2" value="1">Stress Management<br>
				<input type="checkbox" name="wouldlike3" value="1">Smoking Cessation Program<br>
				<input type="checkbox" name="wouldlike4" value="1">Exercise Fitness Program<br>
				<input type="checkbox" name="wouldlike5" value="1">Nutritional Series (healthy heart, low fat, low sodium, diabetic diet)<br>
				<input type="checkbox" name="wouldlike6" value="1">Diabetes Awareness<br>
				<input type="checkbox" name="wouldlike7" value="1">Other<input type="text" name="wouldlike_other" class="textbox_s">
				</td>
			</tr>
			<tr>
				<td>
				Comments:<br>
				<textarea class="textbox" rows="7" name="full_comments"></textarea>
				</td>
			</tr>
				
			<tr>
				<td>&nbsp;</td>
			</tr>
			<tr>
				<td align="center"><input type="submit" value="Submit Survey" class="button"></td>
			</tr>
		</table>
		</form>
<?
}
else 
{
	?>
	Thank you for taking our Satisfaction Survey.
	<?
}
?>