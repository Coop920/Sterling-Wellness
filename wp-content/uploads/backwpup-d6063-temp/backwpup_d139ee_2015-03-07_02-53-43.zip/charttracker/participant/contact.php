<?
/*
Managing Personal Information
Only the following information will be available to participants to manage in order to keep
contact information accurate.
Wellness Solutions � Chart Tracker
Website Development Proposal


� Name
� Address
� Phone Number
� Email Address
� Password
� Current location of employment
*/

if(count($_POST)>1)
{
	#These are all of the fields in the DB that will be updated.  I put them in an array because
	#this was easier than having to update all of the queries everytime a new field is added
	$fields_to_edit = array('firstname','lastname','email','company','address','city','state','zip','phone1','phone2');
	$fields_to_edit = array_merge($fields_to_edit,array('dob','phys','ins','ssn'));
	$_POST['dob'] = $_POST['dob_y'] . "-" . $_POST['dob_m'] . "-" . $_POST['dob_d'];

	#Make sure we don't edit a password field they don't want to edit. Also encrypt it in the DB
	if($_POST['password']!="")
	{
		$fields_to_edit[]="password";
		$_POST['password'] = md5($_POST['password']);
	}

	#build out the query
	for($x=0;$x<count($fields_to_edit);$x++)
	{
		$insert_array[] = "`{$fields_to_edit[$x]}`='{$_POST[$fields_to_edit[$x]]}'";
	}

	if(is_array($insert_array))
	{
		$query = "UPDATE `ct_users` SET " . implode(", ",$insert_array) . "WHERE id = '{$GLOBALS['user_data']['id']}'";
		$message = "Your contact info has been saved.";

		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	}

}

$query = "SELECT *,IF(`lastlogin`='0000-00-00 00:00:00','never',DATE_FORMAT(`lastlogin`,'%m-%d-%Y')) date_fmt FROM ct_users WHERE id='{$GLOBALS['user_data']['id']}'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));


list($dob_y,$dob_m,$dob_d) = explode("-",$dob);
list($ssn_1,$ssn_2,$ssn_3) = explode("-",$ssn);

$ssn_1=substr($ssn,0,3);
$ssn_2=substr($ssn,3,2);
$ssn_3=substr($ssn,5,4);

?>
<script src="util/js/jquery.js"></script>
<script src="util/js/jqvalidate.js"></script>

	<script>
	$().ready(function() {
		// validate signup form on keyup and submit
		$("#contact_form").validate({
			rules: {
				firstname: "required",
				lastname: "required",
				password2: {
					equalTo: "#password"
				},
				email: {
					required: true,
					email: true
				},
				zip: {
					required: true
				},
				address: {
					required: true
				},
				phone1: {
					required: true
				},
				city: {
					required: true
				}

			},
			messages: {
				firstname: "Please enter your first name.",
				lastname: "Please enter your last name.",
				password2: "Passwords do not match",
				email: "Please enter a valid email address",
				city: "Please enter your city",
				zip: "Please enter your zip code",
				phone1: "Please enter your phone number"

			}
		});
	});

	</script>


<form action="index.php?page=contact" method="POST" id="contact_form">
<?


?>
<div id='page_head'>Your Contact Information</div>
	&nbsp;

<table align="center" id="form_table" width="90%">

		<tr valign="top">
			<td>First Name<br><input type="text" class="textbox" name="firstname" value="<?= $firstname ?>"></td>
			<td colspan="2">Last Name<br><input type="text" class="textbox" name="lastname" value="<?= $lastname ?>"></td>
		</tr>
		<tr valign="top">
			<td>Email<br><input type="text" class="textbox" name="email" value="<?= $email ?>"></td>
			<td colspan="2">Birthdate<br>
				<input type="text" class="textbox_s" name="dob_m" value="<?= $dob_m ?>" size="2" maxlength="2" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==2) dob_d.focus()">/
				<input type="text" class="textbox_s" name="dob_d" value="<?= $dob_d ?>" size="2" maxlength="2" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==2) dob_y.focus()">/
				<input type="text" class="textbox_s" name="dob_y" value="<?= $dob_y ?>" size="4" maxlength="4" onkeyup="this.value=this.value.replace(/\D/g,'');if(this.value.length==4) ssn_1.focus()">
			</td>
		</tr>
		<tr valign="top">
			<td>Personal Physician<br><input type="text" class="textbox" name="phys" value="<?= $phys ?>"></td>
			<td colspan="2">Insurance Provider<br><input type="text" class="textbox" name="ins" value="<?= $ins ?>"></td>
		</tr>
		<tr valign="top">
			<td>Password<br><input type="password" class="textbox" name="password" id="password"></td>
			<td colspan="2">Retype Password<br><input type="password" class="textbox" id="password2" name="password2"></td>
		</tr>

		<tr valign="top">
			<td class="helptext" colspan="3">only enter password to edit your password</td>
		</tr>
		<tr valign="top">
			<td colspan="3">Address<br><input type="text" class="textbox" name="address" value="<?= $address ?>"></td>
		</tr>
		<tr valign="top">
			<td>City<br><input type="text" class="textbox" name="city" value="<?= $city ?>"></td>
			<td>State<br><select name="state"><?= show_states($state) ?></select></td>
			<td>Zip<br><input type="text" class="textbox" name="zip" value="<?= $zip ?>" size="5">
			</td>
		</tr>
		<tr valign="top">
			<td>Home Phone<br><input type="text" class="textbox" name="phone1" value="<?= $phone1 ?>"></td>
			<td colspan="2">Work Phone<br><input type="text" class="textbox" name="phone2" value="<?= $phone2 ?>"></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr valign="top">
			 <td colspan="4" align="center"><input type="submit" class="button" style="width:75px" value="Save">&nbsp;&nbsp;&nbsp;<input type="button" class="button" style="width:75px" value="Cancel" onClick="history.go(-1)"></td>
		</tr>
	</table>
	</form>
