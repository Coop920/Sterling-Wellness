<?/*
Personal History Reports
Participants will have access to a report that will give them specific information from each of
the items from imports, as well as all doctor and consultant entered data.  When the participant
enters the site, the user will be presented with three options:

� LabCorp Report
� WellSource HRA Report
� Physician Report

Each of these reports will be searchable and grouped by date range and will display only
personal information.  Available results will include totals and percentages.  Previous
years� data will be available for comparison purposes.
*/

?>
<table class="list_table" width="100%">
<?
	$table	= array(
	"Labcorp Results"=>array("ct_labcorp_pid","ct_sws_id"),
	"HRA Results"=>array("ct_hra","user_id"),
	"Health Assessment"=>array("ct_assessments","patient"),
	"Followup Consultation"=>array("ct_followups","patient"),
	"Notification of Lab Results"=>array("ct_lab_results","patient")
	);

	$query = "

	SELECT id, DATE_FORMAT(`import_date`,'%m-%d-%Y') date_f, 'Labcorp Results' test FROM ct_labcorp_pid WHERE ct_sws_id='{$GLOBALS['user_data']['id']}'
	UNION
	SELECT ct_hra.id, DATE_FORMAT(ct_hra.`import_date`,'%m-%d-%Y') date_f, 'HRA Results' test FROM ct_hra,ct_labcorp_pid WHERE ct_labcorp_pid.id=ct_hra.labcorp_id AND ct_sws_id='{$GLOBALS['user_data']['id']}'
	UNION
	SELECT id , DATE_FORMAT(`add_date`,'%m-%d-%Y') date_f, 'Health Assessment' test FROM ct_assessments WHERE patient = '{$GLOBALS['user_data']['id']}'
	UNION
	SELECT id,  DATE_FORMAT(GREATEST(q1date,q2date,q3date,q4date),'%m-%d-%Y') date_f , 'Followup Consultation' test FROM ct_followups WHERE patient = '{$GLOBALS['user_data']['id']}'
	UNION
	SELECT id, DATE_FORMAT(`date`,'%m-%d-%Y') date_f, 'Notification of Lab Results' test FROM ct_lab_results WHERE patient = '{$GLOBALS['user_data']['id']}'

	ORDER BY date_f DESC";

	ob_start();
	echo "<div>";

	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		extract($row);
		?>
		<div><a href="index.php?page=report&report=<?= $test ?>&test=<?= $id ?>"><b><?= $date_f ?></b><br><?= $test ?></div>
		<?
	}
	echo "</div>";
	$subnav = ob_get_contents();
	ob_end_clean();
	?>
	<table width="100%">
		<tr>
			<td valign="top">
				<table width="100%">
				<?
				#make sure this test belongs to this person
				if($_GET['test'])
				{
					if(does_this_test_belong_to_this_patient($_GET['test'],$table[$_GET['report']][0],$GLOBALS['user_data']['id'],$table[$_GET['report']][1]))
					{

						switch($_GET['report'])
						{
							case "Labcorp Results":
								echo "<span style='float:right'><a href='util/pdf/labs.php?id={$_GET['test']}'><img src='util/images/pdficon.gif' border=0 alt='Download as PDF' title='Download as PDF'></a></span>";
								show_labcorp_no_form($_GET['test'],false);
							break;

							case "HRA Results":
								show_hra_form($_GET['test']);
							break;

							case "Health Assessment":
								show_health_assessment($_GET['test']);
							break;

							case "Followup Consultation":
								echo "<span style='float:right'><a href='util/pdf/callbacks.php?id={$_GET['test']}'><img src='util/images/pdficon.gif' border=0 alt='Download as PDF' title='Download as PDF'></a></span>";
								show_followup($_GET['test']);
							break;

							case "Notification of Lab Results":
								show_notification($_GET['test']);
							break;

						}
					}
					else
					{
						echo "invalid results";
					}
				}
				else
				{

				}
				?>
				</table>
			</td>
		</tr>
	</table>