<?
$query = "SELECT * FROM ct_content WHERE page='ptnt'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
echo $content;


	$query = "

	SELECT id, DATE_FORMAT(`import_date`,'%m-%d-%Y') date_f, 'Labcorp Results' test FROM ct_labcorp_pid WHERE ct_sws_id='{$GLOBALS['user_data']['id']}'
	UNION
	SELECT ct_hra.id, DATE_FORMAT(ct_hra.`import_date`,'%m-%d-%Y') date_f, 'HRA Results' test FROM ct_hra,ct_labcorp_pid WHERE ct_labcorp_pid.id=ct_hra.labcorp_id AND ct_sws_id='{$GLOBALS['user_data']['id']}'
	UNION
	SELECT id , DATE_FORMAT(`add_date`,'%m-%d-%Y') date_f, 'Health Assessment' test FROM ct_assessments WHERE patient = '{$GLOBALS['user_data']['id']}'
	UNION
	SELECT id,  DATE_FORMAT(GREATEST(q1date,q2date,q3date,q4date),'%m-%d-%Y') date_f , 'Followup Consultation' test FROM ct_followups WHERE patient = '{$GLOBALS['user_data']['id']}'
	UNION
	SELECT id, DATE_FORMAT(`date`,'%m-%d-%Y') date_f, 'Notification of Lab Results' test FROM ct_lab_results WHERE patient = '{$GLOBALS['user_data']['id']}'

	ORDER BY date_f DESC";

	ob_start();
	echo "<div>";

	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		extract($row);
		?>
		<div><a href="index.php?page=report&report=<?= $test ?>&test=<?= $id ?>"><b><?= $date_f ?></b><br><?= $test ?></div>
		<?
	}
	echo "</div>";
	$subnav = ob_get_contents();
	ob_end_clean();
	?>