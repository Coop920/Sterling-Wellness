<?
include("global.php");
$password = substr(md5(uniqid("")), -6, 6);

if($_POST['email']!="")
{
	$query = "UPDATE ct_users SET password=MD5('$password') WHERE email = '{$_POST['email']}' LIMIT 1";
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	if(mysql_affected_rows()==1)
	{
		header("Location: index.php?page=password&message=Your password has been reset. The new password was sent to your email address.");

		$mailbody = "Your password at <a href='http://www.sterling-wellness.com/charttracker'>Sterling Wellness</a> has been reset. The new password is $password. You may log in <a href='http://www.sterling-wellness.com/charttracker'>here</a>.";

		$mailHeaders = "MIME-Version: 1.0\n";
		$mailHeaders .= "Content-type: text/html; charset=iso-8859-1\n";
		$mailHeaders .= "From: no-reply@sterling-wellness.com";

		mail($_POST['email'],"Your Sterling Wellness information",$mailbody,$mailHeaders);

	}
	else
	{
		header("Location: index.php?page=password&message=That email address was not found in our system.");
	}
}
else
{
	header("Location: index.php?page=password&message=Please enter a valid email address.");
}



?>