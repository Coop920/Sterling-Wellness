<?
include "../../global.php";

$fields = array(
			array(
			"alr_ph_0"=>"Glucose",
			"alr_ph_2"=>"Hemoglobin",
			"alr_ph_4"=>"Kidney Function",
			"alr_ph_6"=>"Liver Function",
			"alr_ph_8"=>"Electrolytes",
			"alr_ph_10"=>"Cholesterol",
			"alr_ph_12"=>"Thyroid",
			"alr_ph_14"=>"CBC",
			),
			array(
			"alr_ph_1"=>"Diabetes Mellitus",
			"alr_ph_3"=>"Cancer",
			"alr_ph_5"=>"Cardiovascular",
			"alr_ph_7"=>"Stroke",
			"alr_ph_9"=>"Hepatitis",
			"alr_ph_11"=>"Obesity",
			"alr_ph_13"=>"Other:",
			"alr_ph_17"=>"HRA Score Under 25"
			
			
			)
		);

		
foreach($fields[$_GET['field']] as $field=>$title)
{
	$query_part[] = "SUM($field) $field";
}
		
$query = "SELECT ".implode(",",$query_part)." FROM ct_followups LIMIT 1";
$result = mysql_query($query) or die($query . "<br>" . mysql_error());
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
	print_r($row);
	foreach($row as $key => $val)
	{
		$labels[] = $fields[$_GET['field']][$key];
		$counts[] = $val;
	}
}

print_r($counts);
?>
&title=<?= $_GET['title'] ?>,{font-size:20px; color: #FFFFFF; margin: 5px; background-color: #505050; padding:5px; padding-left: 20px; padding-right: 20px;}&
&x_axis_steps=1&
&x_axis_3d=12&
&y_legend=&nbsp;,12,#736AFF&
&y_ticks=5,10,5&
&x_labels=<?= implode(",",$labels) ?>&
&y_min=0&
&y_max=10&
&x_axis_colour=#909090&
&x_grid_colour=#ADB5C7&
&y_axis_colour=#909090&
&y_grid_colour=#ADB5C7&
&bar_3d=75,#2C4375,Count,10&
&values=<?= implode(",",$counts) ?>&