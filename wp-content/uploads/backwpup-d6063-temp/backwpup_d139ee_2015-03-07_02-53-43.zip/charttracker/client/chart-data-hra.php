<?
include "../../global.php";

$total_x = 10;

$query = "SELECT `{$_GET['field']}` label, count(`{$_GET['field']}`) count_field FROM ct_hra GROUP BY `{$_GET['field']}`";
$result = mysql_query($query) or die($query . "<br>" . mysql_error());
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
	extract($row);
	$labels[]=$label;
	$counts[]=$count_field;

	$counts_l[$label] = $count_field;
}

$label_max = max($labels);
$label_min = min($labels);
$label_increment = round(($label_max-$label_min)/$total_x);

for($x=0;$x<$total_x;$x++)
{
	$lower = (($x*$label_increment)+$label_min);
	$upper = (($x*$label_increment)+$label_min+$label_increment);

	$labels_n[$x]= $lower . " - " . $upper;

	foreach ($counts_l as $key=>$val)
	{
		if($key >= $lower && $key <= $upper)
		{
			$count_n[$x]+=$val;
		}
	}

}

$upper_scale = max($count_n);

/*
&title=<?= $_GET['field'] ?>,{font-size: 26px;}&
&x_axis_steps=1&
&y_ticks=5,10,6&
&line=3,#87421F&
&values=<?= implode(",",$counts) ?>&
&x_labels=<?= implode(",",$labels) ?>&
&y_min=0&
&y_max=<?= 15 ?>&
*/
?>
&title=<?= $_GET['caption'] ?>,{font-size:20px; color: #FFFFFF; margin: 5px; background-color: #505050; padding:5px; padding-left: 20px; padding-right: 20px;}&
&x_axis_steps=1&
&x_axis_3d=12&
&y_legend=&nbsp;,12,#736AFF&
&y_ticks=5,10,5&
&x_labels=<?= implode(",",$labels_n) ?>&
&y_min=0&
&y_max=<?= $upper_scale ?>&
&x_axis_colour=#909090&
&x_grid_colour=#ADB5C7&
&y_axis_colour=#909090&
&y_grid_colour=#ADB5C7&
&bar_3d=75,#2C4375,Count,10&
&values=<?= implode(",",$count_n) ?>&