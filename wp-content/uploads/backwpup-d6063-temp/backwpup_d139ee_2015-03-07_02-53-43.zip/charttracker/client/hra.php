<center><p><?



include_once 'util/openflash/php-ofc-library/open_flash_chart_object.php';



$the_fields = array(
	array("Total Cholesterol","TotalCholesterol"),
	array("HDL Cholesterol","HDLCholesterol"),
	array("LDL Cholesterol","LDLCholesterol"),
	array("Triglycerides","Triglycerides"),
	array("BMI","BMI"),
	//array("Body Fat"=>"BodyFat"),
	);




for($x=0;$x<count($the_fields);$x++)
{
	open_flash_chart_object( 750, 250, 'http://'. $_SERVER['SERVER_NAME'] .'/charttracker/client/chart-data-hra.php?caption='.$the_fields[$x][0].'&field='.$the_fields[$x][1], false );
	echo "</p><p>&nbsp;</p><p>";

}


?></p></center>