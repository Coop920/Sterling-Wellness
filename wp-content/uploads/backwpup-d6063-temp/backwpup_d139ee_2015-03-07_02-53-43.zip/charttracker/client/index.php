<?
/*

Clients will have access to the system as configured by the site administrator.  Clients will
have access to a report that will give them only a total count of each of the items from
imports, as well as all doctor and consultant entered data.  When the client enters the site,
the user will be presented with three options:

� LabCorp Report Results
 A report that will denote procedure results as a whole.  Gender specific would be
nice but can grow into this.

� Health Assessment Report
Please see Appendix D

� Follow-up Report
Please see Appendix E

Each of these reports will be searchable and grouped by date range and will display only
information pertaining to their employees.  Available results will include totals and
percentages.  Previous years� data will be available for comparison purposes.
*/


$query = "SELECT * FROM ct_content WHERE page='clnt'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
echo $content;
?>