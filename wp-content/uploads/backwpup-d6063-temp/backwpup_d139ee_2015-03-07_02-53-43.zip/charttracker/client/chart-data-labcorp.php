<?
include "../../global.php";



$query = "SELECT `{$_GET['field']}` label, count(`{$_GET['field']}`) count_field FROM ct_hra GROUP BY `{$_GET['field']}`";
$result = mysql_query($query) or die($query . "<br>" . mysql_error());
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
	extract($row);
	$labels[]=$label;
	$counts[]=$count_field;
}
/*
&title=<?= $_GET['field'] ?>,{font-size: 26px;}&
&x_axis_steps=1&
&y_ticks=5,10,6&
&line=3,#87421F&
&values=<?= implode(",",$counts) ?>&
&x_labels=<?= implode(",",$labels) ?>&
&y_min=0&
&y_max=<?= 15 ?>&
*/
?>
&title=<?= $_GET['field'] ?>,{font-size:20px; color: #FFFFFF; margin: 5px; background-color: #505050; padding:5px; padding-left: 20px; padding-right: 20px;}&
&x_axis_steps=1&
&x_axis_3d=12&
&y_legend=&nbsp;,12,#736AFF&
&y_ticks=5,10,5&
&x_labels=<?= implode(",",$labels) ?>&
&y_min=0&
&y_max=10&
&x_axis_colour=#909090&
&x_grid_colour=#ADB5C7&
&y_axis_colour=#909090&
&y_grid_colour=#ADB5C7&
&bar_3d=75,#2C4375,Count,10&
&values=<?= implode(",",$counts) ?>&