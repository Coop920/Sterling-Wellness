<center><?


/*
include_once 'util/openflash/php-ofc-library/open_flash_chart_object.php';



$the_fields = array("TotalCholesterol","HDLCholesterol","LDLCholesterol","Triglycerides","BMI","BodyFat");




for($x=0;$x<count($the_fields) && $x<15;$x++)
{
	open_flash_chart_object( 500, 250, 'http://'. $_SERVER['SERVER_NAME'] .'/charttracker/client/chart-data.php?field='.$the_fields[$x], false );
	echo "<p>";

}*/


?></center>
