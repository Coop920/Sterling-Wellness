<center><p><?



include_once 'util/openflash/php-ofc-library/open_flash_chart_object.php';

open_flash_chart_object( 750, 250, 'http://'. $_SERVER['SERVER_NAME'] .'/charttracker/client/chart-data-followups.php?field=0&title=Abnormal Lab Results', false );
echo "</p><p>&nbsp;</p><p>";
open_flash_chart_object( 750, 250, 'http://'. $_SERVER['SERVER_NAME'] .'/charttracker/client/chart-data-followups.php?field=1&title=Personal History', false );




?></p></center>
