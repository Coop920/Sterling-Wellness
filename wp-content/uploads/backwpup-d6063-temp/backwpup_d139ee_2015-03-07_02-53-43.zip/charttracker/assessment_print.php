<?
	include "global.php";

	if($_GET['assess_id'])
	{
		$query = "SELECT * FROM ct_assessments WHERE id='{$_GET['assess_id']}'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

		$_GET['new_patient']=$patient;


		$query = "SELECT firstname,lastname,id FROM ct_users WHERE `usertype`='3'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		while($row = mysql_fetch_array($result, MYSQL_ASSOC))
		{
			extract($row);
			$cons[$id] = "$firstname $lastname";

		}
	}


	$query = "SELECT * FROM ct_users WHERE id='{$_GET['new_patient']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	?>
	<html>
	<head>
		<title>Sterling Wellness Solutions</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<meta name="Author" content="Firefly Digital, Inc., www.firefly.cc, 800-397-1624">
		<link href="styles.css" rel="stylesheet" type="text/css">
	</head>
	<body onload="window.print();">
	<table cellspacing="3">
		<tr>
			<td><b>Name</b>:</td>
			<td><?= $firstname ?> <?= $lastname ?></td>
		</tr>
		<tr>
			<td><b>Phone Number:</b></td>
			<td><?= $phone ?></td>
		</tr>
		<tr>
			<td><b>Date:</b></td>
			<td><?= date("m-d-Y") ?></td>
		</tr>
		<tr>
			<td><b>Location:</b></td>
			<td><?= $location ?></td>
		</tr>
	</table>
	<br>
	<table id="list_table" class="disp_table" cellspacing="3">
		<tr>
			<th>Health Assessment</th>
			<th>Results</th>
			<th>Physician Referral</th>
			<th>Reason for Referral</th>
			<th>Comments/Reccomendations/Goals</th>
		</tr>
		<tr class="row-1">
			<td valign="top">
				<b>Health Screening Analysis</b>
				<p>
				<b>RX</b><br>
				<?
				$query = "SELECT * FROM ct_option_prs WHERE id IN ($rx) ORDER BY text";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($rxs = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					echo $rxs['text'] , "<br>";
				}
				?>
				<?= $other_box?"Other: ":"" ?><?=  $other_text ?>

				</p>

			</td>
			<td valign="top">
			<b>Blood Pressure</b>
				<table align="center">
				<tr>
					<td>Systolic</td>
					<td><?= $r_systolic ?></td>
				</tr>
				<tr>
					<td>Diastolic</td>
					<td><?= $r_diastolic ?></td>
				</tr>
				<tr>
					<td>Pulse</td>
					<td><?= $r_pulse ?></td>
				</tr>
				<tr>
					<td>Weight</td>
					<td><?= $r_weight ?></td>
				</tr>
				<tr>
					<td>Height</td>
					<td><?= $r_height ?></td>
				</tr>
				<tr>
					<td>Waist</td>
					<td><?= $r_waist ?></td>
				</tr>
				<tr>
					<td>Body Fat</td>
					<td><?= $r_bodyfat ?></td>
				</tr>
				<tr>
					<td>BMI</td>
					<td><?= $r_bmi ?></td>
				</tr>
				</table>

			</td>
			<td valign="top">
				<?= $phys_ref=="Y"?"Yes":"No" ?>
			</td>
			<td valign="top"><?= $rfr ?></td>
			<td valign="top"><?= $phys_rec ?><br><?= file_exists("signatures/$sign_phys.jpg")?"<img src='signatures/$sign_phys.jpg'>":"{$cons[$sign_phys]}" ?></td>
		</tr>
		<tr class="row-1">
			<td>Fitness Test (3 minute step test)</td>
			<td><?= $ft_results==1?"Excellent":"" ?>
				<?= $ft_results==2?"Good":"" ?>
				<?= $ft_results==3?"Above Average":"" ?>
				<?= $ft_results==4?"Average":"" ?>
				<?= $ft_results==5?"Below Average":"" ?>
				<?= $ft_results==6?"Poor":"" ?>
				<?= $ft_results==7?"Very Poor":"" ?>
				<?= $ft_results==8?"Incomplete":"" ?>
				<?= $ft_results==9?"Opted Out":"" ?></td>
			<td><?= $ft_ref=="Y"?"Yes":"No" ?></td>
			<td><?= $ft_rfr ?></td>
			<td valign="top"><?= $ft_rec ?><br><?= file_exists("signatures/$sign_ft.jpg")?"<img src='signatures/$sign_ft.jpg'>":"{$cons[$sign_ft]}" ?></td>
		</tr>
		<tr class="row-1">
			<td>Flexibility (Sit and Reach)</td>
			<td><?= $fl_results==1?"Excellent":"" ?>
				<?= $fl_results==2?"Good":"" ?>
				<?= $fl_results==3?"Above Average":"" ?>
				<?= $fl_results==4?"Average":"" ?>
				<?= $fl_results==5?"Below Average":"" ?>
				<?= $fl_results==6?"Poor":"" ?>
				<?= $fl_results==7?"Very Poor":"" ?>
				<?= $fl_results==8?"Incomplete":"" ?>
				<?= $fl_results==9?"Opted Out":"" ?></td>
			<td><?= $fl_ref=="Y"?"Yes":"No" ?></td>
			<td><?= $fl_rfr ?></td>
			<td valign="top"><?= $fl_rec ?><br><?= file_exists("signatures/$sign_fl.jpg")?"<img src='signatures/$sign_fl.jpg'>":"{$cons[$sign_fl]}" ?></td>
		</tr>
		<tr class="row-1">
			<td>Bone Density</td>
			<td>
				<?= $bone_density=="1"?"Normal":"" ?>
				<?= $bone_density=="2"?"Osteopenia":"" ?>
				<?= $bone_density=="3"?"Osteoporosis":"" ?>
			</td>
			<td><?= $bd_ref=="Y"?"Yes":"No" ?></td>
			<td><?= $bd_rfr ?></td>
			<td valign="top"><?= $bd_rec ?><br><?= file_exists("signatures/$sign_bd.jpg")?"<img src='signatures/$sign_bd.jpg'>":"{$cons[$sign_bd]}" ?></td>
		</tr>
	</table></body>