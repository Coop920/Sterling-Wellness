<link href="styles.css" rel="stylesheet" type="text/css">
<?
include("global.php");

if($_FILES['file']['tmp_name']!='')
{
	$fixed_date=date("Y-m-d",strtotime($_POST['date']));

	$query = "INSERT INTO ct_uploads
				(`filename`,`file_desc`,`user_id`,`date`)
				VALUES
				('{$_FILES['file']['name']}','{$_POST['file_desc']}','{$_POST['user_id']}','$fixed_date')";
	mysql_query($query) or die(mysql_error());

	$file_prefix = mysql_insert_id();

	if(!move_uploaded_file($_FILES['file']['tmp_name'],"uploads/".$file_prefix."_".$_FILES['file']['name']))
	{
		$_GET['delete'] = $file_prefix;
		echo "<font color='red'>File not uploaded. Please try again</font>";
	}
	else
	{
		echo "<font color='red'>File uploaded successfully</font>";
		unset($_POST);
	}
}

if($_GET['delete']>0)
{


	$query = "SELECT * FROM ct_uploads WHERE id='{$_GET['delete']}' LIMIT 1";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0)
	{
		extract(mysql_fetch_array($result));

		$query = "DELETE FROM ct_uploads WHERE id='{$_GET['delete']}' LIMIT 1";
		mysql_query($query) or die(mysql_error());

		if(file_exists("uploads/".$_GET['delete']."_".$filename))
			unlink("uploads/".$_GET['delete']."_".$filename);

	}
	$_GET['id']=$_GET['delete'];

}



#make sure they're logged in
check_auth();
#extra check... no one, under any circumstance can see this unless they're an admin
/*if($GLOBALS['user_data']['usertype']!=1)
die("You do not have permission to view this page. Please log in.");*/
if($_GET['labcorp_id'])
{
	show_labcorp_form($_GET['labcorp_id']);
}
else if($_GET['hra_id'])
{
	show_hra_form($_GET['hra_id']);
}
else
{

	$query = "SELECT *,DATE_FORMAT(`date`,'%m/%d/%Y') date_f FROM ct_uploads WHERE user_id = '{$_GET['id']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result))
	{
		?>
		<table width="100%">
		<tr>
			<th colspan="3">Uploaded Files</th>
		</tr>

		<?
	}

	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		extract($row);
		?>
		<tr>
			<td width="20%" valign="top"><a href="uploads/<?= $id ?>_<?= $filename ?>"><b><?= $date_f ?></b></a></td>
			<td valign="top"><?= $file_desc ?></td>
			<td width="10%" valign="top"><a href="#" onClick="if(confirm('Are you sure you want to delete this file?')) document.location='history_upload.php?delete=<?= $id ?>';"><img src="util/images/delete.png" border="0"></a></td>
		<?
	}

}
?>
</table>
<script src="util/js/jquery.js"></script>
<script src="util/js/jqalert.js"></script>
<script src="util/js/jdate.js"></script>
<script src="util/js/jqgrow.js"></script>

<script>
$(document).ready(function(){
$('.date').datepicker();
});
</script>

<table width="100%">
		<th>Upload a File</th>
		<tr><td>

<form enctype="multipart/form-data"	method="POST" action="history_upload.php?id=<?= $_GET['id'] ?>">
<p>
	<b>File:</b><br>
	<input type="file" name="file">
</p>
<p>
	<b>Description</b><br>
	<input type="text" name="file_desc" style="width:100%" value="<?= $_POST['file_desc'] ?>">

</p>
<p>
	<b>Document Date:</b><br>
	<input type="text" class="date" name="date" value="<?= $_POST['date'] ?>">
</p>
<center>
	<input type="submit" value="Upload File">
	<input type="hidden" name = "user_id" value="<?= $_GET['id'] ?>">
</center>



</form>


		</td>
</tr>
</table>