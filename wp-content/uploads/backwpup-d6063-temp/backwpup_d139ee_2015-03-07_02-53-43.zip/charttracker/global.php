<?
#Site information
	$GLOBALS['secure']=0;
	$GLOBALS['user_types'] = array (
							1=>"Admin",
							2=>"Physician",
							3=>"Consultant",
							4=>"Client",
							5=>"Participant",
							);
	$GLOBALS['user_types_names'] = array (
							1=>"Admin",
							2=>"Health Consultant",
							3=>"Field Consultant",
							4=>"Client",
							5=>"Participant",
							);
	$GLOBALS['token_hash'] = "well57";

	$history_types = array(
		'labcorp' => 'Labcorp Results',
		'hra' => 'HRA Results',
		'assessment' => 'Health Assessment',
		'followup' => 'Followup Consultation',
		'lab_result' => 'Notification of Lab Results',
		'upload' => 'Uploaded Form'
	);

# DB Information
	$HOST_DATABASE = "sterljj4_sws2";
	$HOST_NAME     = "localhost";
	$USER_NAME     = "sterljj4_sws2";
	$USER_PASSWORD = "notsilver";

# Connect to the database
	mysql_connect($HOST_NAME, $USER_NAME, $USER_PASSWORD);
	mysql_select_db($HOST_DATABASE);

#Include nescessary library files
	include("functions.php");


#all of the states
	$state_list = array('AL'=>"Alabama",
                'AK'=>"Alaska",
                'AZ'=>"Arizona",
                'AR'=>"Arkansas",
                'CA'=>"California",
                'CO'=>"Colorado",
                'CT'=>"Connecticut",
                'DE'=>"Delaware",
                'DC'=>"District Of Columbia",
                'FL'=>"Florida",
                'GA'=>"Georgia",
                'HI'=>"Hawaii",
                'ID'=>"Idaho",
                'IL'=>"Illinois",
                'IN'=>"Indiana",
                'IA'=>"Iowa",
                'KS'=>"Kansas",
                'KY'=>"Kentucky",
                'LA'=>"Louisiana",
                'ME'=>"Maine",
                'MD'=>"Maryland",
                'MA'=>"Massachusetts",
                'MI'=>"Michigan",
                'MN'=>"Minnesota",
                'MS'=>"Mississippi",
                'MO'=>"Missouri",
                'MT'=>"Montana",
                'NE'=>"Nebraska",
                'NV'=>"Nevada",
                'NH'=>"New Hampshire",
                'NJ'=>"New Jersey",
                'NM'=>"New Mexico",
                'NY'=>"New York",
                'NC'=>"North Carolina",
                'ND'=>"North Dakota",
                'OH'=>"Ohio",
                'OK'=>"Oklahoma",
                'OR'=>"Oregon",
                'PA'=>"Pennsylvania",
                'RI'=>"Rhode Island",
                'SC'=>"South Carolina",
                'SD'=>"South Dakota",
                'TN'=>"Tennessee",
                'TX'=>"Texas",
                'UT'=>"Utah",
                'VT'=>"Vermont",
                'VA'=>"Virginia",
                'WA'=>"Washington",
                'WV'=>"West Virginia",
                'WI'=>"Wisconsin",
                'WY'=>"Wyoming");
?>
