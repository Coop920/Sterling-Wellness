<?
if(count($_POST)>1)
{

	$query = "REPLACE INTO `ct_goals` SET
		`wt_cb`='{$_POST['wt_cb']}',
		`wt_ct`='{$_POST['wt_ct']}',
		`wt_st`='{$_POST['wt_st']}',
		`wt_lt`='{$_POST['wt_lt']}',
		`on_cb`='{$_POST['on_cb']}',
		`on_ct`='{$_POST['on_ct']}',
		`on_st`='{$_POST['on_st']}',
		`on_lt`='{$_POST['on_lt']}',
		`pa_cb`='{$_POST['pa_cb']}',
		`pa_ct`='{$_POST['pa_ct']}',
		`pa_st`='{$_POST['pa_st']}',
		`pa_lt`='{$_POST['pa_lt']}',
		`ht_cb`='{$_POST['ht_cb']}',
		`ht_ct`='{$_POST['ht_ct']}',
		`ht_st`='{$_POST['ht_st']}',
		`ht_lt`='{$_POST['ht_lt']}',
		`di_cb`='{$_POST['di_cb']}',
		`di_ct`='{$_POST['di_ct']}',
		`di_st`='{$_POST['di_st']}',
		`di_lt`='{$_POST['di_lt']}',
		`au_cb`='{$_POST['au_cb']}',
		`au_ct`='{$_POST['au_ct']}',
		`au_st`='{$_POST['au_st']}',
		`au_lt`='{$_POST['au_lt']}',
		`sm_cb`='{$_POST['sm_cb']}',
		`sm_ct`='{$_POST['sm_ct']}',
		`sm_st`='{$_POST['sm_st']}',
		`sm_lt`='{$_POST['sm_lt']}',
		`wl_cb`='{$_POST['wl_cb']}',
		`wl_ct`='{$_POST['wl_ct']}',
		`wl_st`='{$_POST['wl_st']}',
		`wl_lt`='{$_POST['wl_lt']}',
		`eh_cb`='{$_POST['eh_cb']}',
		`eh_ct`='{$_POST['eh_ct']}',
		`eh_st`='{$_POST['eh_st']}',
		`eh_lt`='{$_POST['eh_lt']}',
		`ot_cb`='{$_POST['ot_cb']}',
		`ot_ct`='{$_POST['ot_ct']}',
		`ot_st`='{$_POST['ot_st']}',
		`ot_lt`='{$_POST['ot_lt']}',
		`assess_id` = '{$_POST['assess_id']}'";
	mysql_query($query) or die($query . "<p>" . mysql_error());

	$query = "SELECT company FROM ct_users WHERE id='{$_POST['patient']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));


	header("Location: index.php?client=$company&message=Goals Saved!");

}



$query = "SELECT *,date_format(add_date,'%m/%d/%Y') date_f FROM ct_assessments WHERE id='{$_GET['assess_id']}'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) $assessment = (mysql_fetch_array($result));

$query = "SELECT firstname,lastname,id FROM ct_users WHERE `id`='{$assessment['patient']}'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) $patient = (mysql_fetch_array($result));

$query = "SELECT * FROM ct_goals WHERE assess_id='{$_GET['assess_id']}'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));


?>
<script>
$(document).ready(function(){

	$("input#wt_cb").click(function () {
		if( $("input#wt_cb").eq(0).attr( 'checked' ) ) $(".wt_td").slideDown('slow');
	  else $(".wt_td").slideUp('slow');
	});

	$("input#on_cb").click(function () {
		if( $("input#on_cb").eq(0).attr( 'checked' ) ) $(".on_td").slideDown('slow');
	  else $(".on_td").slideUp('slow');
	});

	$("input#ht_cb").click(function () {
		if( $("input#ht_cb").eq(0).attr( 'checked' ) ) $(".ht_td").slideDown('slow');
	  else $(".ht_td").slideUp('slow');
	});

	$("input#pa_cb").click(function () {
		if( $("input#pa_cb").eq(0).attr( 'checked' ) ) $(".pa_td").slideDown('slow');
	  else $(".pa_td").slideUp('slow');
	});

	$("input#di_cb").click(function () {
		if( $("input#di_cb").eq(0).attr( 'checked' ) ) $(".di_td").slideDown('slow');
	  else $(".di_td").slideUp('slow');
	});

	$("input#au_cb").click(function () {
		if( $("input#au_cb").eq(0).attr( 'checked' ) ) $(".au_td").slideDown('slow');
	  else $(".au_td").slideUp('slow');
	});

	$("input#sm_cb").click(function () {
		if( $("input#sm_cb").eq(0).attr( 'checked' ) ) $(".sm_td").slideDown('slow');
	  else $(".sm_td").slideUp('slow');
	});

	$("input#wl_cb").click(function () {
		if( $("input#wl_cb").eq(0).attr( 'checked' ) ) $(".wl_td").slideDown('slow');
	  else $(".wl_td").slideUp('slow');
	});

	$("input#eh_cb").click(function () {
		if( $("input#eh_cb").eq(0).attr( 'checked' ) ) $(".eh_td").slideDown('slow');
	  else $(".eh_td").slideUp('slow');
	});

	$("input#ot_cb").click(function () {
		if( $("input#ot_cb").eq(0).attr( 'checked' ) ) $(".ot_td").slideDown('slow');
	  else $(".ot_td").slideUp('slow');
	});

});

</script>
<form action="index.php?page=goal" method="POST">
<input type="hidden" name="assess_id" value="<?= $_GET['assess_id'] ?>">
<input type="hidden" name="patient" value="<?= $assessment['patient'] ?>">
<table cellspacing="1" cellpadding="3"  border="0" style="border:1px solid #D2D3CD;" align="center">
	<tr>
		<td colspan="3">
			<table width="100%" bgcolor="White">
				<tr>
					<td nowrap><b>Name</b></td><td colspan="3"><?= $patient['firstname'] . " " . $patient['lastname'] ?></td>
				<tr>
					<td><b>Date</b></td><td><?= $assessment['date_f'] ?></td>
				</tr>
				<tr>
					<td><b>Location</b></td><td><?= $assessment['location'] ?></td>
				</tr>
				<tr>
					<td nowrap width="60%"><b>Pertinent Diagnoses</b></td><td colspan="3" align="right"><input type="text" name="diagnosis" value="<?= $diagnosis ?>" ></td>
				</tr>
				<tr>
					<td nowrap width="20%"><b>Reference Labs</b></td><td colspan="3" align="right"><input type="text" name="diagnosis" value="<?= $diagnosis ?>" ></td>
				</tr>
				<tr>
					<td nowrap width="20%"><b>Current Weight</b></td><td><?= $assessment['r_weight'] ?></td>
				</tr>
			</table>
		</td>
	</tr>

	<tr>
		<th width="60%">Health Goals</th>
		<th>Short Term</th>
		<th>Long Term</th>
	</tr>


	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="wt_cb" <?= $wt_cb?"CHECKED":"" ?> id="wt_cb">Weight</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$wt_cb?";display:none":"" ?>" name="wt_ct" value="<?= $wt_ct ?>" class="wt_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$wt_cb?";display:none":"" ?>" name="wt_st" value="<?= $wt_st ?>" class="wt_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$wt_cb?";display:none":"" ?>" name="wt_lt" value="<?= $wt_lt ?>" class="wt_td"></td>
	</Tr>


	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="on_cb" <?= $on_cb?"CHECKED":"" ?> id="on_cb">Overall Nutrition</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$on_cb?";display:none":"" ?>" name="on_ct" value="<?= $on_ct ?>" class="on_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$on_cb?";display:none":"" ?>" name="on_st" value="<?= $on_st ?>" class="on_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$on_cb?";display:none":"" ?>" name="on_lt" value="<?= $on_lt ?>" class="on_td"></td>
	</Tr>


	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="pa_cb" <?= $pa_cb?"CHECKED":"" ?> id="pa_cb">Physical Activity</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$pa_cb?";display:none":"" ?>" name="pa_ct" value="<?= $pa_ct ?>" class="pa_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$pa_cb?";display:none":"" ?>" name="pa_st" value="<?= $pa_st ?>" class="pa_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$pa_cb?";display:none":"" ?>" name="pa_lt" value="<?= $pa_lt ?>" class="pa_td"></td>
	</Tr>

	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="ht_cb" <?= $ht_cb?"CHECKED":"" ?> id="ht_cb">Hypertension</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$ht_cb?";display:none":"" ?>" name="ht_ct" value="<?= $ht_ct ?>" class="ht_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$ht_cb?";display:none":"" ?>" name="ht_st" value="<?= $ht_st ?>" class="ht_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$ht_cb?";display:none":"" ?>" name="ht_lt" value="<?= $ht_lt ?>" class="ht_td"></td>
	</Tr>

	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="di_cb" <?= $di_cb?"CHECKED":"" ?> id="di_cb">Diabetes/Impaired Glucose Tolerance </label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$di_cb?";display:none":"" ?>" name="di_ct" value="<?= $di_ct ?>" class="di_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$di_cb?";display:none":"" ?>" name="di_st" value="<?= $di_st ?>" class="di_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$di_cb?";display:none":"" ?>" name="di_lt" value="<?= $di_lt ?>" class="di_td"></td>
	</Tr>

	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="au_cb" <?= $au_cb?"CHECKED":"" ?> id="au_cb">Alcohol Use</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$au_cb?";display:none":"" ?>" name="au_ct" value="<?= $au_ct ?>" class="au_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$au_cb?";display:none":"" ?>" name="au_st" value="<?= $au_st ?>" class="au_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$au_cb?";display:none":"" ?>" name="au_lt" value="<?= $au_lt ?>" class="au_td"></td>
	</Tr>

	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="sm_cb" <?= $sm_cb?"CHECKED":"" ?> id="sm_cb">Smoking/Tobacco Use</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$sm_cb?";display:none":"" ?>" name="sm_ct" value="<?= $sm_ct ?>" class="sm_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$sm_cb?";display:none":"" ?>" name="sm_st" value="<?= $sm_st ?>" class="sm_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$sm_cb?";display:none":"" ?>" name="sm_lt" value="<?= $sm_lt ?>" class="sm_td"></td>
	</Tr>

	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="wl_cb" <?= $wl_cb?"CHECKED":"" ?> id="wl_cb">Wellness/Preventive Health Care</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$wl_cb?";display:none":"" ?>" name="wl_ct" value="<?= $wl_ct ?>" class="wl_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$wl_cb?";display:none":"" ?>" name="wl_st" value="<?= $wl_st ?>" class="wl_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$wl_cb?";display:none":"" ?>" name="wl_lt" value="<?= $wl_lt ?>" class="wl_td"></td>
	</Tr>

	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="eh_cb" <?= $eh_cb?"CHECKED":"" ?> id="eh_cb">Emotional Health/Stress Management</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$eh_cb?";display:none":"" ?>" name="eh_ct" value="<?= $eh_ct ?>" class="eh_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$eh_cb?";display:none":"" ?>" name="eh_st" value="<?= $eh_st ?>" class="eh_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$eh_cb?";display:none":"" ?>" name="eh_lt" value="<?= $eh_lt ?>" class="eh_td"></td>
	</Tr>

	<tr bgcolor="White">
		<td colspan="3"><label><input type="checkbox" value="1" name="ot_cb" <?= $ot_cb?"CHECKED":"" ?> id="ot_cb">Other</label></td>
	</tr>
	<Tr bgcolor="White">
		<td align="center"><input type="text" style="width:100%<?= !$ot_cb?";display:none":"" ?>" name="ot_ct" value="<?= $ot_ct ?>" class="ot_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$ot_cb?";display:none":"" ?>" name="ot_st" value="<?= $ot_st ?>" class="ot_td"></td>
		<td align="center"><input type="text" style="width:45px<?= !$ot_cb?";display:none":"" ?>" name="ot_lt" value="<?= $ot_lt ?>" class="ot_td"></td>
	</Tr>
	<tr>
		<td align="center" colspan="3"><input type="submit" value="Save" class="button"></td>
	</tr>
</table>
</form>