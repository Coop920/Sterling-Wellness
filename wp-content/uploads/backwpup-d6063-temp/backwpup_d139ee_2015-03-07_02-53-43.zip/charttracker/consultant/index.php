<?
/*
Consultants will have access to the system as configured by the site administrator.  The
first thing they will see when going to the CTA will be a login screen.  Upon a successful
login to the site, Consultants will see a landing page with options to view Health
Assessment Client Listing.


Accessing Health Assessment Listing
After choosing to view the Health Assessment Listing the consultant will be given a list of
Clients who they have access to.  Once the Client is chosen a list of all Participants available
for Health Assessments will be provided.  The Consultant will be able to generate a Health
Assessment Worksheet.  This worksheet will be pre-populated with the following
information, which will not be editable by the Consultant:

� Participant Name
� Phone Number
� Date (automatically generated)
� Location (Drop-down list of Client Locations)
� Existing Physicians Referral
� Existing Reason for Referral

The Consultant will be able to add information to the Health Assessment Worksheet.  The
information they can Add/Edit is denoted in Appendix C.
*/

if($_POST['sub'])
{

	if(is_array($_POST['rx'])) $str_rx = implode(",",$_POST['rx']);


	if($_POST['a_id']!="")
	{
		$query = "UPDATE `ct_assessments` SET
			`patient` = '{$_POST['patient']}',
		    `rx` = '$str_rx',
		    `other_box` = '{$_POST['other_box']}',
	    	`other_text` = '{$_POST['other_text']}',
		    `r_systolic` = '{$_POST['r_systolic']}',
		    `r_diastolic` = '{$_POST['r_diastolic']}',
		    `r_pulse` = '{$_POST['r_pulse']}',
		    `r_weight` = '{$_POST['r_weight']}',
		    `r_height` = '{$_POST['r_height']}',
		    `r_waist` = '{$_POST['r_waist']}',
		    `r_bodyfat` = '{$_POST['r_bodyfat']}',
		    `r_bmi` = '{$_POST['r_bmi']}',
		    `phys_ref` = '{$_POST['phys_ref']}',
		    `rfr` = '{$_POST['rfr']}',
		    `goals` = '{$_POST['goals']}',
		    `ft_results` = '{$_POST['ft_results']}',
		    `ft_ref` = '{$_POST['ft_ref']}',
		    `ft_rfr` = '{$_POST['ft_rfr']}',
		    `fl_results` = '{$_POST['fl_results']}',
		    `fl_ref` = '{$_POST['fl_ref']}',
		    `fl_rfr` = '{$_POST['fl_rfr']}',
		    `bone_density` = '{$_POST['bone_density']}',
		    `bd_ref` = '{$_POST['bd_ref']}',
		    `bd_rfr` = '{$_POST['bd_rfr']}',
		    `sign_phys` = '{$_POST['sign_phys']}',
		    `sign_bd` = '{$_POST['sign_bd']}',
		    `sign_fl` = '{$_POST['sign_fl']}',
		    `sign_ft` = '{$_POST['sign_ft']}',
		    `phys_rec` = '{$_POST['phys_rec']}',
		    `ft_rec` = '{$_POST['ft_rec']}',
		    `fl_rec` = '{$_POST['fl_rec']}',
		    `bd_rec` = '{$_POST['bd_rec']}',
		    `location` = '{$_POST['location']}'
		    WHERE id = '{$_POST['a_id']}'
			";

			$message = "Updated";
	}
	else
	{

		$query = "INSERT INTO `ct_assessments` SET
		`patient` = '{$_POST['patient']}',
	    `rx` = '$str_rx',
	    `other_box` = '{$_POST['other_box']}',
	    `other_text` = '{$_POST['other_text']}',
	    `r_systolic` = '{$_POST['r_systolic']}',
	    `r_diastolic` = '{$_POST['r_diastolic']}',
	    `r_pulse` = '{$_POST['r_pulse']}',
	    `r_weight` = '{$_POST['r_weight']}',
	    `r_height` = '{$_POST['r_height']}',
	    `r_waist` = '{$_POST['r_waist']}',
	    `r_bodyfat` = '{$_POST['r_bodyfat']}',
	    `r_bmi` = '{$_POST['r_bmi']}',
	    `phys_ref` = '{$_POST['phys_ref']}',
	    `rfr` = '{$_POST['rfr']}',
	    `goals` = '{$_POST['goals']}',
	    `ft_results` = '{$_POST['ft_results']}',
	    `ft_ref` = '{$_POST['ft_ref']}',
	    `ft_rfr` = '{$_POST['ft_rfr']}',
	    `fl_results` = '{$_POST['fl_results']}',
	    `fl_ref` = '{$_POST['fl_ref']}',
	    `fl_rfr` = '{$_POST['fl_rfr']}',
	    `bone_density` = '{$_POST['bone_density']}',
		`bd_ref` = '{$_POST['bd_ref']}',
	    `bd_rfr` = '{$_POST['bd_rfr']}',
	    `add_date` = NOW(),
	    `sign_phys` = '{$_POST['sign_phys']}',
	    `sign_bd` = '{$_POST['sign_bd']}',
	    `sign_fl` = '{$_POST['sign_fl']}',
	    `sign_ft` = '{$_POST['sign_ft']}',
		`location` = '{$_POST['location']}',
	    `phys_rec` = '{$_POST['phys_rec']}',
	    `ft_rec` = '{$_POST['ft_rec']}',
	    `fl_rec` = '{$_POST['fl_rec']}',
	    `bd_rec` = '{$_POST['bd_rec']}'
		";

		$message = "Added";
	}
	mysql_query($query) or die($query . "<p>" . mysql_error());
	if($_POST['assess_id']=="") $_POST['assess_id']=mysql_insert_id;

	$query = "SELECT company FROM ct_users WHERE id='{$_POST['patient']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));


	if($_POST['list'])
		header("Location: index.php?client=$company&message=Assessment $message");
	elseif ($_POST['goal'])
		header("Location: index.php?page=goal&assess_id=".$_POST['a_id']);

}
else if(is_numeric($_GET['new_patient']) || is_numeric($_GET['assess_id']))
{

	if($_GET['assess_id'])
	{
		$query = "SELECT * FROM ct_assessments WHERE id='{$_GET['assess_id']}'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

		$_GET['new_patient']=$patient;

		$query = "SELECT firstname,lastname,id FROM ct_users WHERE `usertype`='3'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		while($row = mysql_fetch_array($result, MYSQL_ASSOC))
		{
			extract($row);
			$cons[$id] = "$firstname $lastname";

		}
	}



	$query = "SELECT * FROM ct_users WHERE id='{$_GET['new_patient']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	?>
	  <script>
		$(document).ready(function(){

		  $("input#other_box").click(function () {
			  if( $("input#other_box").eq(0).attr( 'checked' ) ) $("input#other_text").slideDown('slow');
			  else $("input#other_text").slideUp('slow');

		  });

		  $(".bd_ref").click(function () {
		  	if( $(".bd_ref:checked").eq(0).val() == 'Y' ) $("#div_rfr").slideDown('slow');
				else $("#div_rfr").slideUp('slow');
	    });


	    $(".fl_ref").click(function () {
	    	if( $(".fl_ref:checked").eq(0).val() == 'Y' ) $("#div_fl").slideDown('slow');
				else $("#div_fl").slideUp('slow');
	    });

			$(".ft_ref").click(function () {
				if( $(".ft_ref:checked").eq(0).val() == 'Y' ) $("#div_ft").slideDown('slow');
				else $("#div_ft").slideUp('slow');
    	});

			$(".phys_ref").click(function () {
				if( $(".phys_ref:checked").eq(0).val() == 'Y' ) $("#div_phys").slideDown('slow');
				else $("#div_phys").slideUp('slow');
    	});

	    	/*$('textarea').autogrow();*/

		});
	  </script>
	  <script language="JavaScript" src="util/js/slider.js" >
</script>
	<form method="POST" action="index.php">
	<input type="hidden" name="sub" value="1">
	<input type="hidden" name="patient" value="<?= $_GET['new_patient'] ?>">
	<input type="hidden" name="a_id" value="<?= $_GET['assess_id'] ?>">
	<? if($_GET['assess_id']!="") { ?>
		<SCRIPT LANGUAGE="JavaScript">
			function popUp(URL) {
			day = new Date();
			id = day.getTime();
			eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=1,width=600,height=800,left = 640,top = 225');");
			}
		</script>
		<div align="right"><a href="javascript:popUp('assessment_print.php?assess_id=<?= $_GET['assess_id'] ?>')" title='print this health assessment' alt='print this health assessment'><img src='util/images/action_print.gif' border=0 align="right">Print this Health Assessment</a></div><? } ?>



		<table cellpadding="3" width="100%">
		<tr>
			<td><b>Name</b>:</td>
			<td><?= $firstname ?> <?= $lastname ?></td>
			<td width="70%" rowspan="4" valign="top">
			<?
				$query = "SELECT ct_hra.id FROM ct_hra,ct_labcorp_pid WHERE ct_hra.labcorp_id=ct_labcorp_pid.id AND ct_labcorp_pid.ct_sws_id='{$_GET['new_patient']}' ORDER BY EntryDate DESC";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				if(mysql_num_rows($result)>0)
				{
					?>
					<div align="right"><input type="button" class="button" value="View Patient History" onclick="document.location='index.php?page=history&patient=<?= $_GET['new_patient'] ?>'" align="right"></div>
					<?
				}

			?>
			</td>
		</tr>
		<tr>
			<td><b>Phone Number:</b></td>
			<td><?= $phone ?></td>
		</tr>
		<tr>
			<td><b>Date:</b></td>
			<td><?= date("m-d-Y") ?></td>
		</tr>
		<tr>
			<td><b>Location:</b></td>
			<td>
			<?
			$query = "SELECT locations FROM ct_users WHERE id = '$company'";
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

			$local_array = explode("|",$locations)

			?>
			<select name="location">
			<?
			for($x=0;$x<count($local_array);$x++)
			{
				?><option <?= $location==$local_array[$x]?"SELECTED":"" ?>><?= $local_array[$x] ?></option><?
			}
			?>
			</select></td>
		</tr>
	</table>
	<br>



	<table id="list_table" class="disp_table" cellspacing="1" cellpadding="3" width="500" border="0">
		<tr>
			<th width="10%">Health Assessment</th>
			<th width="10%">Results</th>
			<th>Physician Referral</th>
			<th>Comments & Signature</th>
		</tr>
		<tr class="row-1">
			<td valign="top" nowrap>
				<b>Health Screening Analysis</b>
				<p>
				<b>RX</b><br>
				<?
				$rs_select = explode(",",$rx);

				$query = "SELECT * FROM ct_option_prs WHERE `active` = '1' ORDER BY text";
				$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				while($rxs = mysql_fetch_array($result, MYSQL_ASSOC))
				{
					?>
					<input type="checkbox" name="rx[]" value="<?= $rxs['id'] ?>" <?= in_array($rxs['id'],$rs_select)?"CHECKED":"" ?>><?= $rxs['text'] ?><br>
					<?
				}
				?>
				<input type="checkbox" id="other_box" name="other_box" value="16" <?= $other_box?"CHECKED":"" ?>>Other <input type="text" id="other_text" name="other_text" value="<?=  $other_text ?>" class="textbox" <?= !$other_box?"style='display:none'":"" ?>>

				</p>

			</td>
			<td valign="top">
			<b>Blood Pressure</b>
				<table align="center" width="100%">
				<tr>
					<td>Systolic</td>
					<td>
					<img src='util/images/arrow_fat_up.gif' onClick="document.getElementById('r_systolic').value=(document.getElementById('r_systolic').value*1)+1" style="cursor:hand;cursor:pointer">
					<img src='util/images/arrow_fat_down.gif' onClick="document.getElementById('r_systolic').value=(document.getElementById('r_systolic').value*1)-1" style="cursor:hand;cursor:pointer">
					<input class="carpe_slider_display"
				        id="r_systolic"
				        name="r_systolic"
				        value="<?= $r_systolic ?>"
				        type="text"
				        from="75"
				        to="300"
				        valuecount="250"
				        typelock="off" />

				</tr>
				<tr>
					<td colspan="2">
					<div class="carpe_horizontal_slider_track">
					    <div class="carpe_slider_slit">&nbsp;</div>
					    <div class="carpe_slider"
					        id="r_systolic_slider"
					        orientation="horizontal"
					        distance="140"
					        display="r_systolic"
					        style="left: 0px;">&nbsp;</div>
					</div>
					</td>
				</tr>
				<tr>
					<td>Diastolic</td>
					<td>
					<img src='util/images/arrow_fat_up.gif' onClick="document.getElementById('r_diastolic').value=(document.getElementById('r_diastolic').value*1)+1" style="cursor:hand;cursor:pointer">
					<img src='util/images/arrow_fat_down.gif' onClick="document.getElementById('r_diastolic').value=(document.getElementById('r_diastolic').value*1)-1" style="cursor:hand;cursor:pointer">
					<input class="carpe_slider_display"
				        id="r_diastolic"
				        name="r_diastolic"
				        value="<?= $r_diastolic ?>"
				        type="text"
				        from="50"
				        to="200"
				        valuecount="200"
				        typelock="off" /></td>
				<tr>
					<td colspan="2">
					<div class="carpe_horizontal_slider_track">
					    <div class="carpe_slider_slit">&nbsp;</div>
					    <div class="carpe_slider"
					        id="r_diastolic_slider"
					        orientation="horizontal"
					        distance="140"
					        display="r_diastolic"
					        style="left: 0px;">&nbsp;</div>
					</div>
					</td>
				</tr>
				</tr>
				<tr>
					<td>Pulse</td>
					<td>
					<img src='util/images/arrow_fat_up.gif' onClick="document.getElementById('r_pulse').value=(document.getElementById('r_pulse').value*1)+1" style="cursor:hand;cursor:pointer">
					<img src='util/images/arrow_fat_down.gif' onClick="document.getElementById('r_pulse').value=(document.getElementById('r_pulse').value*1)-1" style="cursor:hand;cursor:pointer">
					<input class="carpe_slider_display"
				        id="r_pulse"
				        name="r_pulse"
				        value="<?= $r_pulse ?>"
				        type="text"
				        from="40"
				        to="200"
				        valuecount="160"
				        typelock="off" /></td>
				</tr>
				<tr>
					<td colspan="2">
					<div class="carpe_horizontal_slider_track">
					    <div class="carpe_slider_slit">&nbsp;</div>
					    <div class="carpe_slider"
					        id="r_pulse_slider"
					        orientation="horizontal"
					        distance="140"
					        display="r_pulse"
					        style="left: 0px;">&nbsp;</div>
					</div>
					</td>
				</tr>
				<tr>
					<td>Weight</td>
					<td>
					<img src='util/images/arrow_fat_up.gif' onClick="document.getElementById('r_weight').value=(document.getElementById('r_weight').value*1)+1" style="cursor:hand;cursor:pointer">
					<img src='util/images/arrow_fat_down.gif' onClick="document.getElementById('r_weight').value=(document.getElementById('r_weight').value*1)-1" style="cursor:hand;cursor:pointer">
					<input class="carpe_slider_display"
				        id="r_weight"
				        name="r_weight"
				        value="<?= $r_weight ?>"
				        type="text"
				        from="100"
				        to="400"
				        valuecount="60"
				        typelock="off" /></td>
				</tr>
				<tr>
					<td colspan="2">
					<div class="carpe_horizontal_slider_track">
					    <div class="carpe_slider_slit">&nbsp;</div>
					    <div class="carpe_slider"
					        id="r_weight_slider"
					        orientation="horizontal"
					        distance="140"
					        display="r_weight"
					        style="left: 0px;">&nbsp;</div>
					</div>
					</td>
				</tr>
				<tr>
					<td>Height (in)</td>
					<td>
					<img src='util/images/arrow_fat_up.gif' onClick="document.getElementById('r_height').value=(document.getElementById('r_height').value*1)+1" style="cursor:hand;cursor:pointer">
					<img src='util/images/arrow_fat_down.gif' onClick="document.getElementById('r_height').value=(document.getElementById('r_height').value*1)-1" style="cursor:hand;cursor:pointer">
					<input class="carpe_slider_display"
				        id="r_height"
				        name="r_height"
				        value="<?= $r_height ?>"
				        type="text"
				        from="50"
				        to="84"
				        valuecount="60"
				        typelock="off" /></td>
				</tr>
				<tr>
					<td colspan="2">
					<div class="carpe_horizontal_slider_track">
					    <div class="carpe_slider_slit">&nbsp;</div>
					    <div class="carpe_slider"
					        id="r_height_slider"
					        orientation="horizontal"
					        distance="140"
					        display="r_height"
					        style="left: 0px;">&nbsp;</div>
					</div>
					</td>
				</tr>
				<tr>
					<td>Waist</td>
					<td>
					<img src='util/images/arrow_fat_up.gif' onClick="document.getElementById('r_waist').value=(document.getElementById('r_waist').value*1)+1" style="cursor:hand;cursor:pointer">
					<img src='util/images/arrow_fat_down.gif' onClick="document.getElementById('r_waist').value=(document.getElementById('r_waist').value*1)-1" style="cursor:hand;cursor:pointer">
					<input class="carpe_slider_display"
				        id="r_waist"
				        name="r_waist"
				        value="<?= $r_waist ?>"
				        type="text"
				        from="10"
				        to="40"
				        valuecount="60"
				        typelock="off" /></td>
				</tr>
				<tr>
					<td colspan="2">
					<div class="carpe_horizontal_slider_track">
					    <div class="carpe_slider_slit">&nbsp;</div>
					    <div class="carpe_slider"
					        id="r_waist_slider"
					        orientation="horizontal"
					        distance="140"
					        display="r_waist"
					        style="left: 0px;">&nbsp;</div>
					</div>
					</td>
				</tr>
				<tr>
					<td>Body Fat</td>
					<td>
					<img src='util/images/arrow_fat_up.gif' onClick="document.getElementById('r_bodyfat').value=(document.getElementById('r_bodyfat').value*1)+1" style="cursor:hand;cursor:pointer">
					<img src='util/images/arrow_fat_down.gif' onClick="document.getElementById('r_r_bodyfatwaist').value=(document.getElementById('r_bodyfat').value*1)-1" style="cursor:hand;cursor:pointer">
					<input class="carpe_slider_display"
				        id="r_bodyfat"
				        name="r_bodyfat"
				        value="<?= $r_bodyfat ?>"
				        type="text"
				        from="0"
				        to="100"
				        valuecount="101"
				        typelock="off" /></td>
				</tr>
				<tr>
					<td colspan="2">
					<div class="carpe_horizontal_slider_track">
					    <div class="carpe_slider_slit">&nbsp;</div>
					    <div class="carpe_slider"
					        id="r_bodyfat_slider"
					        orientation="horizontal"
					        distance="140"
					        display="r_bodyfat"
					        style="left: 0px;">&nbsp;</div>
					</div>
					</td>
				</tr>
				<tr>
					<td>BMI</td>
					<td>
					<img src='util/images/arrow_fat_up.gif' onClick="document.getElementById('r_bmi').value=(document.getElementById('r_bmi').value*1)+1" style="cursor:hand;cursor:pointer">
					<img src='util/images/arrow_fat_down.gif' onClick="document.getElementById('r_bmi').value=(document.getElementById('r_bmi').value*1)-1" style="cursor:hand;cursor:pointer">
					<input class="carpe_slider_display"
				        id="r_bmi"
				        name="r_bmi"
				        value="<?= $r_bmi ?>"
				        type="text"
				        from="10"
				        to="40"
				        valuecount="150"
				        typelock="off" /></td>
				</tr>
				<tr>
					<td colspan="2">
					<div class="carpe_horizontal_slider_track">
					    <div class="carpe_slider_slit">&nbsp;</div>
					    <div class="carpe_slider"
					        id="r_bmi_slider"
					        orientation="horizontal"
					        distance="140"
					        display="r_bmi"
					        style="left: 0px;">&nbsp;</div>
					</div>
					</td>
				</tr>
				<tr>
					<td class="helptext" colspan="2">*if a value is out of range, use<br>the keyboard to type it in to the corresponding field.</td>
				</tr>
				</table>

			</td>
			<td valign="top" rowspan="4">
				<input type="radio" name="phys_ref" value="N" <?= $phys_ref=="N" || $phys_ref=="" ?"CHECKED":"" ?> class="phys_ref">No&nbsp;&nbsp;
				<input type="radio" name="phys_ref" value="Y" <?= $phys_ref=="Y"?"CHECKED":"" ?> class="phys_ref">Yes
				<div id='div_phys' <?= $phys_ref!='Y'?"style='display:none'":"" ?>>
					<? reason_dropdown('rfr'); ?><br>
					<textarea name="rfr" id="rfr" style="height:150;width:100%"><?= $rfr ?></textarea>
				</div>
			</td>
			<td valign="top">
				<?= $sign_phys>0?"<input type='hidden' name='sign_phys' value='$sign_phys'>Completed by {$cons[$sign_phys]}":"<input type='checkbox' name='sign_phys' value='{$GLOBALS['user_data']['id']}'>Sign<br>"; ?>
				<? reccomend_dropdown('phys_rec'); ?><br>
				<textarea name="phys_rec" id="phys_rec" style="height:150;width:100%"><?= $phys_rec ?></textarea>
			</td>
		</tr>
		<tr class="row-1" valign="top">
			<td>Fitness Test (3 minute step test)</td>
			<td>
				<select name="ft_results">
					<option></option>
					<option value="1" <?= $ft_results==1?"SELECTED":"" ?>>Excellent</option>
					<option value="2" <?= $ft_results==2?"SELECTED":"" ?>>Good</option>
					<option value="3" <?= $ft_results==3?"SELECTED":"" ?>>Above Average</option>
					<option value="4" <?= $ft_results==4?"SELECTED":"" ?>>Average</option>
					<option value="5" <?= $ft_results==5?"SELECTED":"" ?>>Below Average</option>
					<option value="6" <?= $ft_results==6?"SELECTED":"" ?>>Poor</option>
					<option value="7" <?= $ft_results==7?"SELECTED":"" ?>>Very Poor</option>
					<option value="8" <?= $ft_results==8?"SELECTED":"" ?>>Incomplete</option>
					<option value="9" <?= $ft_results==9?"SELECTED":"" ?>>Opted Out</option>
				</select>

			</td>
<!--
			<td>
				<input type="radio" name="ft_ref" value="N" <?= $ft_ref=="N"||$ft_ref==""?"CHECKED":"" ?> class="ft_ref">No&nbsp;&nbsp;
				<input type="radio" name="ft_ref" value="Y" <?= $ft_ref=="Y"?"CHECKED":"" ?> class="ft_ref">Yes
				<div id='div_ft' <?= $ft_ref!='Y'?"style='display:none'":"" ?>>
					<? reason_dropdown('ft_rfr'); ?><br>
					<textarea name="ft_rfr" id="ft_rfr" style="height:150;width:100%"><?= $ft_rfr ?></textarea>
				</div>
			</td>
-->
			<td>
				<?= $sign_ft>0?"<input type='hidden' name='sign_ft' value='$sign_ft'>Completed by {$cons[$sign_ft]}":"<input type='checkbox' name='sign_ft' value='{$GLOBALS['user_data']['id']}'>Sign<br>"; ?>
				<? reccomend_dropdown('ft_rec'); ?><br>
				<textarea name="ft_rec" id="ft_rec" style="height:150;width:100%"><?= $ft_rec ?></textarea>
			</td>
		</tr>
		<tr class="row-1" valign="top">
			<td>Flexibility (Sit and Reach)</td>
			<td>
				<select name="fl_results">
					<option></option>
					<option value="1" <?= $fl_results==1?"SELECTED":"" ?>>Excellent</option>
					<option value="2" <?= $fl_results==2?"SELECTED":"" ?>>Good</option>
					<option value="3" <?= $fl_results==3?"SELECTED":"" ?>>Above Average</option>
					<option value="4" <?= $fl_results==4?"SELECTED":"" ?>>Average</option>
					<option value="5" <?= $fl_results==5?"SELECTED":"" ?>>Below Average</option>
					<option value="6" <?= $fl_results==6?"SELECTED":"" ?>>Poor</option>
					<option value="7" <?= $fl_results==7?"SELECTED":"" ?>>Very Poor</option>
					<option value="8" <?= $fl_results==8?"SELECTED":"" ?>>Incomplete</option>
					<option value="9" <?= $fl_results==9?"SELECTED":"" ?>>Opted Out</option>
				</select>
			</td>
<!--
			<td>
				<input type="radio" name="fl_ref" value="N" <?= $fl_ref=="N" || $fl_ref=="" ?"CHECKED":"" ?> class="fl_ref">No&nbsp;&nbsp;
				<input type="radio" name="fl_ref" value="Y" <?= $fl_ref=="Y"?"CHECKED":"" ?> class="fl_ref">Yes
				<div id='div_fl' <?= $fl_ref!='Y'?"style='display:none'":"" ?>>
					<? reason_dropdown('fl_rfr'); ?><br>
					<textarea name="fl_rfr" id="fl_rfr" style="height:150;width:100%"><?= $fl_rfr ?></textarea>
				</div>
			</td>
-->
			<td>
				<?= $sign_fl>0?"<input type='hidden' name='sign_fl' value='$sign_fl'>Completed by {$cons[$sign_fl]}":"<input type='checkbox' name='sign_fl' value='{$GLOBALS['user_data']['id']}'>Sign<br>"; ?>
				<? reccomend_dropdown('fl_rec'); ?><br>
				<textarea name="fl_rec" id="fl_rec" style="height:150;width:100%"><?= $fl_rec ?></textarea>
			</td>
		</tr>
		<tr class="row-1" valign="top">
			<td>Bone Density</td>
			<td>
				<input type="radio" name='bone_density' value="1" <?= $bone_density=="1"?"CHECKED":"" ?>>Normal<br>
				<input type="radio" name='bone_density' value="2" <?= $bone_density=="2"?"CHECKED":"" ?>>Osteopenia<br>
				<input type="radio" name='bone_density' value="3" <?= $bone_density=="3"?"CHECKED":"" ?>>Osteoporosis<br>
				<input type="radio" name='bone_density' value="4" <?= $bone_density=="4"?"CHECKED":"" ?>>Opted Out
			</td>
<!--
			<td>
				<input type="radio" name="bd_ref" value="N" <?= $bd_ref=="N" || $bd_ref=="" ?"CHECKED":"" ?> class="bd_ref">No&nbsp;&nbsp;
				<input type="radio" name="bd_ref" value="Y" <?= $bd_ref=="Y"?"CHECKED":"" ?> class="bd_ref">Yes
				<div id='div_rfr' <?= $bd_ref!='Y'?"style='display:none'":"" ?>>
					<? reason_dropdown('bd_rfr'); ?><br>
					<textarea name="bd_rfr" id="bd_rfr" style="height:150;width:100%"><?= $bd_rfr ?></textarea>
				</div>
			</td>
-->
			<td>
				<?= $sign_bd>0?"<input type='hidden' name='sign_bd' value='$sign_bd'>Completed by {$cons[$sign_bd]}":"<input type='checkbox' name='sign_bd' value='{$GLOBALS['user_data']['id']}'>Sign<br>"; ?>
				<? reccomend_dropdown('bd_rec'); ?><br>
				<textarea name="bd_rec" id="bd_rec" style="height:150;width:100%"><?= $bd_rec ?></textarea>

			</td>
		</tr>
	</table>
	&nbsp;
	<center>
		<input type="submit" class="button" name = "list" style="width:175px" value="Save and Go to Client List">
		<input type="submit" class="button" name = "goal" style="width:175px" value="Save and Go to Goal Sheet">
	</center>
	</form>
	<?

}
else if(is_numeric($_GET['goal_list']))
{
	$query = "SELECT CONCAT(firstname,' ',lastname)  name FROM ct_users WHERE id='{$_GET['goal_list']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));


	$query = "SELECT DATE_FORMAT(`add_date`,'%M %d, %Y') add_date_f,id FROM ct_goals,ct_assessments WHERE ct_assessments.id=ct_goals.assess_id AND `patient` = '{$_GET['goal_list']}' ORDER BY add_date DESC";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	?>
		<table id="list_table" cellpadding="5" cellspacing="0" width="100%">
		<tr>
			<th colspan='4'><a href="#" onclick="jqalert('These are all the health assessments for <?= $name ?>.', 'More Information', {icon: &quot;util/images/info.png&quot;})"><img src="util/images/important.png" align="right" border="0"></a><?= $name ?></th>
		</tr>
		<?
		if(mysql_num_rows($result)>0)
		{
			$i=1;
			while($row = mysql_fetch_array($result, MYSQL_ASSOC))
			{
				$i*=-1;
				echo "<tr class='row". $i . "'>";
				echo "<td><a href='index.php?page=goal&assess_id={$row['id']}'>{$row['add_date_f']}</a></td>";
				echo "</tr>";
			}
		}
		else
		{
			echo "<tr class='row-1'><td>This participant currently has no goal sheets. <a href='index.php?patient_list={$_GET['goal_list']}'>Click here</a> to add one.</td></tr>";
		}
		?>
		</table>
	<?
}
else if(is_numeric($_GET['patient_list']))
{
	$query = "SELECT CONCAT(firstname,' ',lastname)  name FROM ct_users WHERE id='{$_GET['patient_list']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));


	$query = "SELECT DATE_FORMAT(`add_date`,'%M %d, %Y') add_date_f,id FROM ct_assessments WHERE `patient` = '{$_GET['patient_list']}' ORDER BY add_date DESC";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	?>
		<table id="list_table" cellpadding="5" cellspacing="0" width="100%">
		<tr>
			<th colspan='4'><a href="#" onclick="jqalert('These are all the health assessments for <?= $name ?>.', 'More Information', {icon: &quot;util/images/info.png&quot;})"><img src="util/images/important.png" align="right" border="0"></a><?= $name ?></th>
		</tr>
		<?
		if(mysql_num_rows($result)>0)
		{
			$i=1;
			while($row = mysql_fetch_array($result, MYSQL_ASSOC))
			{
				$i*=-1;
				echo "<tr class='row". $i . "'>";
				echo "<td><a href='index.php?assess_id={$row['id']}'>{$row['add_date_f']}</a></td>";
				echo "</tr>";
			}
		}
		else
		{
			echo "<tr class='row-1'><td>This participant currently has no health assessments. <a href='index.php?new_patient={$_GET['patient_list']}'>Click here</a> to add one.</td></tr>";
		}
		?>
		</table>
	<?
}
else if(is_numeric($_GET['client']))
{
	$query = "SELECT company FROM ct_users WHERE id='{$_GET['client']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

	$query = "SELECT * FROM ct_users WHERE `usertype` = '5' AND company='{$_GET['client']}' AND lastname IS NOT NULL";
	if( isset( $_GET['s'] ) && $_GET['s'] ) {
		$query .= '
			AND CONCAT_WS( " ", firstname, lastname ) LIKE "%'.(string)$_GET['s'].'%"
		';
	}
	$query .= " ORDER BY lastname, firstname";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	?>
	<table align="center" width="100%">
		<tr>
			<td class="system_message" ><?= $_GET['message'] ?></td>
		</tr>
		<tr>
			<td>
			<form action="index.php" method="GET">
				<input type='hidden' name='client' value='<?php echo( $_GET['client'] ); ?>' />
				<table id="search_table" class="disp_table">
					<tr>
						<td nowrap align='left'>Search <input type="text" name="s" value="<?= $_GET['s'] ?>" class="textbox search"></td>
						<td align='left' ><input type="image" name="submit" src="util/images/magnify2.png"></td>
						<td align='left' width='100%' ><a href='index.php?client=<?php echo( $_GET['client'] ); ?>'>Show all</a></td>
					</tr>
				</table>
			</form>
			</td>
		</tr>
		<tr>
			<td>
				<table id="list_table" cellpadding="5" cellspacing="0" width="100%">
					<tr>
						<th colspan='4'><a href="#" onclick="jqalert('These are the employees of <?= $company ?>.', 'More Information', {icon: &quot;util/images/info.png&quot;})"><img src="util/images/important.png" align="right" border="0"></a><?= $company ?></th>
					</tr>

		<?
		$i=1;
		while($row = mysql_fetch_array($result, MYSQL_ASSOC))
		{
			$i*=-1;
			?>
			<tr class='row<?php echo $i; ?>'>
			<td><?php echo( $row['firstname'].' '.$row['lastname'] ); ?></td>
			<td align="right">
					<a href='index.php?page=history&patient=<?php echo( $row['id'] ); ?>'><img src='util/images/application_form_magnify.png' border='0' title='view patient history' alt='view most recent HRA'></a>&nbsp;
					<a href='index.php?patient_list=<?php echo( $row['id'] ); ?>'><img src='util/images/table_edit.png' border='0' title='view or edit a current health assessment' alt='view or edit a current health assessment'></a>&nbsp;
					<a href='index.php?new_patient=<?php echo( $row['id'] ); ?>'><img src='util/images/table_add.png' border='0' title='add new health assessment' alt='add new health assessment' ></a>&nbsp;
					<a href='index.php?goal_list=<?php echo( $row['id'] ); ?>'><img src='util/images/trophy_icon.gif' border='0' title='view or edit a current goals sheet' alt='view or edit a current goals sheet'></a>&nbsp;
			</td>
			</tr>
			<?php
		}
		?>
				</table>
			</td>
		</tr>
	</table>
	<?
}
else
{
	$query = "SELECT * FROM ct_content WHERE page='cons'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	echo $content;

	$query = "SELECT * FROM ct_users,ct_assigned_consultants WHERE ct_users.id=ct_assigned_consultants.client AND ct_assigned_consultants.user='{$GLOBALS['user_data']['id']}' AND `usertype` = '4' ORDER BY company";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	?>
		<table id="list_table" cellpadding="5" cellspacing="0" width="100%">
		<tr>
			<th colspan='4'><a href="#" onclick="jqalert('These are all of the cients you have access to.', 'More Information', {icon: &quot;util/images/info.png&quot;})"><img src="util/images/important.png" align="right" border="0"></a>Client List</th>
		</tr>
		<?
		$i=1;
		while($row = mysql_fetch_array($result, MYSQL_ASSOC))
		{
			$i*=-1;
			echo "<tr class='row". $i . "'>";
			echo "<td><a href='index.php?client={$row['id']}'>{$row['company']}</a></td>";
			echo "</tr>";
		}
		?>
		</table>
	<?
}
?>