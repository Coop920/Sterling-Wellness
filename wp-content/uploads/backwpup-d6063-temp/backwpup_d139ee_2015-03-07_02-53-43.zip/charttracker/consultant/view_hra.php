<?
#get most recent hra
$query = "SELECT ct_hra.id FROM ct_hra,ct_labcorp_pid WHERE ct_hra.labcorp_id=ct_labcorp_pid.id AND ct_labcorp_pid.ct_sws_id='{$_GET['patient']}' ORDER BY EntryDate DESC";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0)
{
	extract(mysql_fetch_array($result));
	show_hra_form($id);
}
else
{
	echo "This participant does not have an HRA.";
}



?>