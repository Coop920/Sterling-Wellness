<?
require_once("global.php");

if($_GET['test'])
{

	$query = "SELECT company FROM ct_users WHERE id='{$_GET['patient']}' LIMIT 1";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

	ob_start();
	?>

	<div><a href="index.php?client=<?= $company ?>"><b>Back to Participant List</b></a></div>
	<?
	$history = get_user_history( $_GET['patient'] );
	foreach( $history as $row ) {
		if( $row['test_type'] == 'upload' ) {
			?>
			<div><a target='_blank' href="uploads/<?= $row['id'] ?>_<?= $row['filename'] ?>"><b><?= $row['date_f'] ?>&nbsp;-&nbsp;<?= $row['test_name'] ?></b></a><br></div>
			<?php } else { ?>
			<div><a href="index.php?page=history&test=<?= $row['test_type'] ?>&id=<?= $row['id'] ?>&patient=<?= $_GET['patient'] ?>"><b><?= $row['date_f'] ?></b>&nbsp;-&nbsp;<?= $row['test_name'] ?></a><br></div>
			<?php
		}
	}

	echo "</div>";
	$subnav = ob_get_contents();
	ob_end_clean();

	switch($_GET['test'])
	{
		case 'labcorp':
			show_labcorp_no_form($_GET['id'],false);
		break;

		case 'hra':
			show_hra_form($_GET['id']);
		break;

		case 'assessment':
			show_health_assessment($_GET['id']);
		break;

		case 'followup':
			show_followup($_GET['id']);
		break;

		case 'lab_result':
			show_notification($_GET['id']);
		break;
		case 'upload':
			// TODO show uploded form
			break;
		default:
			echo "unknown test";
		break;

	}

}
else
{
	ob_start();
	echo "<div>";
	?>
	<input type="submit" class="button" style="float:right" name = "list" style="width:175px" value="Upload History" onclick="window.open('history_upload.php?id=<?= $_GET['patient'] ?>',null,'height=400,width=300,status=no,toolbar=no,menubar=no,location=no,scrollbar=yes,resizable=yes');">
	<?
	$history = get_user_history( $_GET['patient'] );
	foreach( $history as $row ) {
		if( $row['test_type'] == 'upload' ) {
			?>
			<div><a target='_blank' href="uploads/<?= $row['id'] ?>_<?= $row['filename'] ?>"><b><?= $row['date_f'] ?>&nbsp;-&nbsp;<?= $row['test_name'] ?></b></a><br></div>
			<?php } else { ?>
			<a href="index.php?page=history&test=<?= $row['test_type'] ?>&id=<?= $row['id'] ?>&patient=<?= $_GET['patient'] ?>"><b><?= $row['date_f'] ?></b>&nbsp;-&nbsp;<?= $row['test_name'] ?></a><br>
			<?php
		}
	}
}
?>