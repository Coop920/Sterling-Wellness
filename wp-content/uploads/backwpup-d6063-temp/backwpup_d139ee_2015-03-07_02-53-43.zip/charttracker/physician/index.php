<?
/*
Physicians will have access to the system as configured by the site administrator.  The first
thing they will see when going to the CTA will be a login screen.  Upon a successful login
to the site, physicians will see an option to view Notification of Medical Results Reports or
Follow Up Consultation Reports.
*/


$query = "SELECT * FROM ct_content WHERE page='phys'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
echo $content;
?>

<table width="100%">
	<tr>
		<td valign='top'>
		<?
		$query = "SELECT patient.firstname,patient.lastname,DATE_FORMAT(ct_labcorp_pid.import_date,'%m/%d/%Y') import_date_f,ct_labcorp_pid.id
					FROM ct_labcorp_pid,ct_users company, ct_users patient,ct_assigned_users
		 	 		WHERE ct_labcorp_pid.ct_sws_id=patient.id
		 	 			AND patient.company=company.id
		 	 			AND company.id=ct_assigned_users.client
		 	 			AND ct_labcorp_pid.hra_id IS NOT NULL
		 	 			AND ct_labcorp_pid.notification_id IS NULL
		 	 			AND ct_assigned_users.user = '{$GLOBALS['user_data']['id']}'
					";

		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		?>
			<table id="list_table" cellpadding="3" cellspacing="0" align="center" width="100%">
			<tr>
				<th colspan='4'><a href="#" onclick="jqalert('These are all participants who have a Labcorp test with at least one abnormal with related HRA entry but have yet to be notified.', 'More Information', {icon: 'util/images/info.png'});"><img src="util/images/important.png" align="right" border="0" /></a>Notifications Needed&nbsp;&nbsp;&nbsp;&nbsp;<a href="index.php<?= $_GET['show_all'] ? '' : '?show_all=1' ?>" ><?= $_GET['show_all'] ? '[abnormal only]' :'[show all]' ?></a></th>
			</tr>
			<?
			$i=1;
			while($row = mysql_fetch_array($result, MYSQL_ASSOC))
			{
				if(find_abnormal_pid($row['id']) || $_GET['show_all'])
				{
					$i*=-1;
					echo "<tr class='row". $i . "'>";
					echo "<td><a href='index.php?page=results&id={$row['id']}' alt='add notification' title='add notification'><img src='util/images/report_edit.png' border='0'></a></td>";
					echo "<td>{$row['firstname']}</td>";
					echo "<td>{$row['lastname']}</td>";
					echo "<td>{$row['import_date_f']}</td>";
					echo "</tr>";
				}
			}
			?>
			</table>
		</td>
		<td  valign="top">
		<?
			//$query = "SELECT *,DATE_FORMAT(ct_labcorp_pid.import_date,'%m/%d/%Y') import_date_f FROM ct_lab_results, ct_labcorp_pid WHERE ct_lab_results.labcorp_id = ct_labcorp_pid.id AND physician='{$GLOBALS['user_data']['id']}'";
			$query = "SELECT *,ct_followups.id id FROM ct_followups,ct_users WHERE ct_users.id=ct_followups.patient AND q1date <= NOW() AND q2date = '0000-00-00' AND physician='{$GLOBALS['user_data']['id']}'";
			$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

			?>
			<table id="list_table" cellpadding="3" cellspacing="0" align="center" width="100%">
			<tr>
				<th colspan='5'><a href="#" onclick="jqalert('This should be a list of all patients who need a followup form; Follow-up with them.', 'More Information', {icon: 'util/images/info.png'});"><img src="util/images/important.png" align="right" border="0"></a>Followups Needed</th>
			</tr>
			<?
			$i=1;
			while($row = mysql_fetch_array($result, MYSQL_ASSOC))
			{
				$i*=-1;
				echo "<tr class='row". $i . "'>";
				echo "<td><a href='index.php?page=followups&id={$row['id']}' alt='edit followup' title='edit followup'><img src='util/images/user_comment.png' border='0'></a></td>";
				echo "<td>{$row['firstname']}</td>";
				echo "<td>{$row['lastname']}</td>";
				echo "<td>{$row['import_date_f']}</td>";
				echo "</tr>";
			}
			?>
		</table>
	</td>
	<td valign="top">
	<?
	/*$query = "SELECT *,DATE_FORMAT(ct_labcorp_pid.import_date,'%m/%d/%Y') import_date_f FROM ct_labcorp_pid, ct_followups
		  WHERE ct_labcorp_pid.id = ct_followups.pid_id AND ct_followups.physician='{$GLOBALS['user_data']['id']}'";
	*/
	$query = "SELECT *,ct_followups.id id FROM ct_followups,ct_users WHERE ct_users.id=ct_followups.patient AND GREATEST(`q2date`,`q3date`,`q4date`) <= NOW() AND GREATEST(`q2date`,`q3date`,`q4date`) != '0000-00-00' AND physician='{$GLOBALS['user_data']['id']}'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	?>
	<table id="list_table" cellpadding="3" cellspacing="0" align="center" width="100%">
	<tr>
		<th colspan='4'><a href="#" onclick="jqalert('This should be a list of all participants who need an additional followup form; Follow-up with them.', 'More Information', {icon: 'util/images/info.png'});"><img src="util/images/important.png" align="right" border="0"></a>Additional Followups</th>
	</tr>
	<?
	$i=1;
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		$i*=-1;
		echo "<tr class='row". $i . "'>";
		echo "<td><a href='index.php?page=followups&id={$row['id']}' alt='edit followup' title='edit followup'><img src='util/images/user_comment_2.png' border='0'></a></td>";
		echo "<td>{$row['firstname']}</td>";
		echo "<td>{$row['lastname']}</td>";
		echo "<td>{$row['import_date_f']}</td>";
		echo "</tr>";
	}
?>
	</table>
</td>
</table>