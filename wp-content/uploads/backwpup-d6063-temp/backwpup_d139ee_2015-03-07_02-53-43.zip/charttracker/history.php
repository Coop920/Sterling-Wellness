<link href="styles.css" rel="stylesheet" type="text/css">
<?
include("global.php");

#make sure they're logged in
check_auth();
#extra check... no one, under any circumstance can see this unless they're an admin
if($GLOBALS['user_data']['usertype']!=1)
die("You do not have permission to view this page. Please log in.");
if($_GET['labcorp_id'])
{
	show_labcorp_form($_GET['labcorp_id']);
}
else if($_GET['hra_id'])
{
	show_hra_form($_GET['hra_id']);
}
else
{

	?>
		<table width="100%">
		<th>Imported Data</th>
		<tr><td>
	<?
	$query = "

	SELECT id, DATE_FORMAT(`import_date`,'%m-%d-%Y') date_f, 'Labcorp Results' test FROM ct_labcorp_pid WHERE ct_sws_id='{$_GET['id']}'
	UNION
	SELECT ct_hra.id, DATE_FORMAT(ct_hra.`import_date`,'%m-%d-%Y') date_f, 'HRA Results' test FROM ct_hra,ct_labcorp_pid WHERE ct_labcorp_pid.id=ct_hra.labcorp_id AND ct_sws_id='{$_GET['id']}'
	UNION
	SELECT id , DATE_FORMAT(`add_date`,'%m-%d-%Y') date_f, 'Health Assessment' test FROM ct_assessments WHERE patient = '{$_GET['id']}'
	UNION
	SELECT id,  DATE_FORMAT(GREATEST(q1date,q2date,q3date,q4date),'%m-%d-%Y') date_f , 'Followup Consultation' test FROM ct_followups WHERE patient = '{$_GET['id']}'
	UNION
	SELECT id, DATE_FORMAT(`date`,'%m-%d-%Y') date_f, 'Notification of Lab Results' test FROM ct_lab_results WHERE patient = '{$_GET['id']}'

	ORDER BY date_f DESC";

	ob_start();
	echo "<div>";

	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		extract($row);
		?>
		<a href="#" onClick="window.opener.location='index.php?page=history&patient=<?= $_GET['id'] ?>&test=<?= $test ?>&id=<?= $id ?>';window.close();"><b><?= $date_f ?></b>&nbsp;-&nbsp;<?= $test ?><br>


		<?
	}

}
?>
</td></tr></table>