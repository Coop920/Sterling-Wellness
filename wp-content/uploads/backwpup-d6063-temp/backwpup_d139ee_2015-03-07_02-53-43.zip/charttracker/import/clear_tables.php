<?

$query = "TRUNCATE TABLE `ct_labcorp_pid`";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
       		
$query = "TRUNCATE TABLE `ct_labcorp_nte`";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
       		
$query = "TRUNCATE TABLE `ct_labcorp_obr`";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
       		
$query = "TRUNCATE TABLE `ct_labcorp_obx`";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

$query = "TRUNCATE TABLE `ct_hra`";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
       		
$query = "DELETE FROM `ct_users` WHERE usertype='5'";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
       		
?>