<?php
include ("../../global.php");
#firsts things we's gonna do is get the ids of those jive turkey companies
$query = "SELECT * FROM ct_users WHERE usertype=4";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
	$company_id[$row['clientID']]=$row['id'];
}


#loop through all the cool cats chillin with no company
$query = "SELECT * FROM ct_users WHERE usertype=5 AND company IS NULL";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
	#find out if we have them, if we do, who's their boss?
	$query2 = "SELECT * FROM ct_patients_temp WHERE FirstName = '{$row['firstname']}' AND LastName = '{$row['lastname']}'";
	$result2 = mysql_query($query2) or mysql_error_handler($query2, $PHP_SELF);
	if(mysql_num_rows($result2)>0)
	{
		extract(mysql_fetch_array($result2));
		#OMG we found one!
		$query = "UPDATE ct_users SET ssn='$clientID',email='$EMail',groupnumber='$GroupNumber',company='{$company_id[$CompanyNumber]}'  WHERE id='{$row['id']}' LIMIT 1";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

		if($company_id[$CompanyNumber] != "" ) echo "<font color='green'>{$row['firstname']} {$row['lastname']} was matched.</font><br>";
		else echo "<font color='blue'>{$row['firstname']} {$row['lastname']} was matched but company id `$CompanyNumber` was not found.</font><br>";

	}
	else
	{
		#oh snap, they weren't there
		echo "<font color='red'>{$row['firstname']} {$row['lastname']} was not matched.</font><br>";
	}
	flush();


}

echo "done";




die();


$handle = fopen("Fireflypatients.csv", "r");
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
{
    $num = count($data);
    for ($c=0; $c < $num; $c++)
    {
        $insert[] = addslashes($data[$c]);
  	}
    if(count($insert)==7) $query_part[]="'".implode("','",$insert)."'";
    unset($insert);
}

$query = "INSERT INTO `ct_patients_temp` VALUES (" . implode("),(",$query_part) . ")";

mysql_query($query) or die(mysql_error() . "<br>" . $query);
echo "done";
fclose($handle);
?>
