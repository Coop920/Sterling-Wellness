<?php
die();
include ("../../global.php");

$handle = fopen("clients.txt", "r");
while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
{
    $num = count($data);
    for ($c=0; $c < $num; $c++)
    {
        if($c==11)
        {
			#this is goofy, but oh well.  it's location#,locationname,location#,locationname....

			$temp_array = explode(",",$data[$c]);
			for($x=0;$x<count($temp_array);$x+=2)
			{
				$newdata[] = addslashes($temp_array[$x]." - ".$temp_array[($x+1)]);
			}
			$insert[] = implode("|",$newdata);
        }
    	else
    	{
    		$insert[] = addslashes($data[$c]);
    	}
    }
    $query_part[]="'".implode("','",$insert)."'";
    unset($insert,$newdata,$temp_array);
}

$query = "INSERT INTO `ct_users` (`company`,`firstname`,`lastname`,`address`,`city`,`state`,`zip`,`phone1`,`phone2`,`email`,`clientID`,`locations`,`active`,`usertype`) VALUES (" . implode(",1,4),(",$query_part) . ",1,4)";

mysql_query($query) or die(mysql_error() . "<br>" . $query);

fclose($handle);
?>
