<?
ob_start();
include "../global.php";

//include "clear_tables.php";

$ftp_server = "sterlingwellness.fireflyserver.com";
$ftp_user_name = "sterling";
$ftp_user_pass = "m3d1c@lm1r@cl3";

$conn_id = ftp_connect($ftp_server);
$login_result = ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);

if ((!$conn_id) || (!$login_result)) {
        echo "FTP connection has failed!";
        echo "Attempted to connect to $ftp_server for user $ftp_user_name";
        exit;
    } else {
        echo "Connected to $ftp_server, for user $ftp_user_name";
    }


$d = dir("/home/sterling/");

while (false !== ($filename = $d->read()))
{
	import_file("/home/sterling/$filename");
	echo "Moving " . $filename . "<br>";
	ftp_rename($conn_id,$filename,"imported/$filename");
	echo "<br>$last_line<br>";
}


ftp_close($conn_id);

function import_file($filename)
{
	$dataFile = fopen( $filename, "r" ) ;
	echo "<p><B>$filename</b><br>";
	  if ( $dataFile )
	  {
	    while (!feof($dataFile))
	    {
	       $buffer_array = explode("|",rtrim(fgets($dataFile, 4096)));

	       switch($buffer_array[0])
	       {
	       	case("PID")://PATIENT IDENTIFICATION
	       		$name = explode("^",$buffer_array[5]);
	       		$address = explode("^",$buffer_array[11]);
	       		$insert_query[] = "`external_patient_id` = '{$buffer_array[2]}'";
	       		$insert_query[] = "`lab_assigned_id` = '{$buffer_array[3]}'";
	       		$insert_query[] = "`alternate_id` = '{$buffer_array[4]}'";
	       		$insert_query[] = "`lastname` = '".addslashes(ucwords(strtolower(str_replace("'","",$name[0]))))."'";
	       		$insert_query[] = "`firstname` = '".addslashes(ucwords(strtolower($name[1])))."'";
	       		$insert_query[] = "`midinitial` = '".addslashes(ucwords(strtolower($name[2])))."'";
	       		$insert_query[] = "`mothers_maiden` = '{$buffer_array[6]}'";
	       		$insert_query[] = "`dob` = '{$buffer_array[7]}'";
	       		$insert_query[] = "`sex` = '{$buffer_array[8]}'";
	       		$insert_query[] = "`address` = '{$address[0]}'";
	       		$insert_query[] = "`address2` = '{$address[1]}'";
	       		$insert_query[] = "`city` = '{$address[2]}'";
	       		$insert_query[] = "`state` = '{$address[3]}'";
	       		$insert_query[] = "`zip` = '{$address[4]}'";
	       		$insert_query[] = "`country_code` = '{$buffer_array[12]}'";
	       		$insert_query[] = "`homephone` = '{$buffer_array[13]}'";
	       		$insert_query[] = "`ssn` = '{$buffer_array[19]}'";
	       		$insert_query[] = "`import_date` = NOW()";

	       		$query = "INSERT INTO `ct_labcorp_pid` SET " . implode(", ",$insert_query);
	       		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				$pid = mysql_insert_id();
	       		$total_patients_data_added++;

	       		//echo $buffer_array[19] , "<br>";
	       	break;

	       	case("ORC")://COMMON ORDER SEGMENT
	       		#NO DATA OF ANY USE THAT I CAN SEE
	       	break;

	       	case("OBR")://OBSERVATION ORDER SEGMENT
	       		$observation = explode("^",$buffer_array[4]);
	       		$insert_query[] = "`pid` = '$pid'";
	       		$insert_query[] = "`sequence_num` = '{$buffer_array[1]}'";
	       		$insert_query[] = "`observation_identifier` = '{$observation[0]}'";
	       		$insert_query[] = "`observation_text` = '".addslashes($observation[1])."'";
	       		$insert_query[] = "`observation_coding` = '{$observation[2]}'";
	       		$insert_query[] = "`collection_time` = '{$buffer_array[7]}'";
	       		$insert_query[] = "`action_code` = '{$buffer_array[11]}'";

	       		$query = "INSERT INTO `ct_labcorp_obr` SET " . implode(", ",$insert_query);
	       		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				$obr = mysql_insert_id();

	       	break;

	       	case("OBX")://Result Observation Segment
	       		$observation = explode("^",$buffer_array[3]);
	       		$insert_query[] = "`obr` = '$obr'";
	       		$insert_query[] = "`observation_identifier` = '{$observation[0]}'";
	       		$insert_query[] = "`observation_text` = '".addslashes($observation[1])."}'";
	       		$insert_query[] = "`observation_coding` = '{$observation[2]}'";
	       		$insert_query[] = "`observation_id` = '{$buffer_array[4]}'";
	       		$insert_query[] = "`observation_value` = '{$buffer_array[5]}'";
	       		$insert_query[] = "`units` = '{$buffer_array[6]}'";
	       		$insert_query[] = "`reference` = '{$buffer_array[7]}'";
	       		$insert_query[] = "`abnormal_flags` = '{$buffer_array[8]}'";
	       		$insert_query[] = "`abnormal_probability` = '{$buffer_array[9]}'";
	       		$insert_query[] = "`abnormal_nature` = '{$buffer_array[10]}'";
	       		$insert_query[] = "`observation_results` = '{$buffer_array[11]}'";
	       		$insert_query[] = "`date_last_change` = '{$buffer_array[12]}'";
	       		$insert_query[] = "`date_observation` = '{$buffer_array[12]}'";
	       		$insert_query[] = "`lab` = '{$buffer_array[15]}'";

	       		$query = "INSERT INTO `ct_labcorp_obx` SET " . implode(", ",$insert_query);
	       		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
				$obx = mysql_insert_id();
	       	break;

	       	case("NTE")://Comment
	       		$observation = explode("^",$buffer_array[3]);
	       		$insert_query[] = "`obx` = '$obx'";
	       		$insert_query[] = "`comment_source` = '".addslashes($buffer_array[2])."'";
	       		$insert_query[] = "`comment_text` = '".addslashes($buffer_array[3])."'";

	       		$query = "INSERT INTO `ct_labcorp_nte` SET " . implode(", ",$insert_query);
	       		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	       	break;


	       }
	       unset($insert_query);

	    }

	    fclose($dataFile);


	  }
	  else
	  {
	    die( "fopen failed for $filename" ) ;
	  }

	  	echo ($total_patients_data_added+0) . " labcorp procedures were imported.\n";


	  	#First check to see if any of these guys are already in there by SSN.  That's going to be most accurate
//	  	$query = "UPDATE ct_labcorp_pid,ct_users SET ct_labcorp_pid.ct_sws_id=ct_labcorp_pid.id WHERE ct_labcorp_pid.ssn=ct_users.ssn AND ct_users.usertype='5' AND ct_labcorp_pid.ct_sws_id IS NULL AND ct_labcorp_pid.ssn != ''";
	  	$query = "UPDATE ct_labcorp_pid,ct_users SET ct_labcorp_pid.ct_sws_id=ct_users.id WHERE ct_labcorp_pid.ssn=ct_users.ssn AND ct_users.usertype='5' AND ct_labcorp_pid.ct_sws_id IS NULL AND ct_labcorp_pid.ssn != ''";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		echo (mysql_affected_rows()+0) . " labcorp procedures were matched to existing patients by social security number.\n";
		
		//Then check by user_id - field named external_patient_id
		$query = "UPDATE ct_labcorp_pid,ct_users SET ct_labcorp_pid.ct_sws_id=ct_users.id WHERE ct_labcorp_pid.external_patient_id=ct_users.id AND ct_users.usertype='5' AND ct_labcorp_pid.ct_sws_id IS NULL";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		echo (mysql_affected_rows()+0) . " labcorp procedures were matched to existing patients by external patient id.\n";

		#Then check by firstname lastname,  address, state
//		$query = "UPDATE ct_labcorp_pid,ct_users SET ct_labcorp_pid.ct_sws_id=ct_labcorp_pid.id WHERE ct_labcorp_pid.firstname LIKE(ct_users.firstname)  AND  ct_labcorp_pid.lastname LIKE(ct_users.lastname) AND ct_labcorp_pid.address LIKE(ct_users.address) AND ct_labcorp_pid.state LIKE(ct_users.state) AND ct_users.usertype='5' AND ct_labcorp_pid.ct_sws_id IS NULL";
		$query = "UPDATE ct_labcorp_pid,ct_users SET ct_labcorp_pid.ct_sws_id=ct_users.id WHERE ct_labcorp_pid.firstname LIKE(ct_users.firstname)  AND  ct_labcorp_pid.lastname LIKE(ct_users.lastname) AND ct_labcorp_pid.address LIKE(ct_users.address) AND ct_labcorp_pid.state LIKE(ct_users.state) AND ct_users.usertype='5' AND ct_labcorp_pid.ct_sws_id IS NULL";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		echo (mysql_affected_rows()+0) . " labcorp procedures were matched to existing patients by firstname, lastname, address, and state.\n";

		#Then import userdata if it doesn't already exist
		$query = "UPDATE ct_labcorp_pid,ct_users SET
					ct_users.usertype='5',
					ct_users.firstname=ct_labcorp_pid.firstname,
					ct_users.lastname=ct_labcorp_pid.lastname,
					ct_users.active='1',
					ct_users.address=ct_labcorp_pid.address,
					ct_users.city=ct_labcorp_pid.city,
					ct_users.state=ct_labcorp_pid.state,
					ct_users.zip=ct_labcorp_pid.zip,
					ct_users.phone1=ct_labcorp_pid.homephone,
					ct_users.dob=STR_TO_DATE(ct_labcorp_pid.dob, '%Y%m%d'),
					ct_users.ssn=ct_labcorp_pid.ssn,
					ct_users.sex=ct_labcorp_pid.sex
				WHERE
					ct_labcorp_pid.ct_sws_id=ct_users.id
					AND
					ct_users.lastname IS NULL
		";
		mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		echo (mysql_affected_rows()+0) . " labcorp procedures were matched to existing patients by social security number.\n";




		$query = "SELECT * FROM `ct_labcorp_pid` WHERE ct_sws_id IS NULL";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		while($row = mysql_fetch_assoc($result))
		{
		  	$query="INSERT INTO `ct_users` SET usertype='5',firstname='{$row['firstname']}',lastname='{$row['lastname']}',active='1',address='{$row['address']}',city='{$row['city']}',state='{$row['state']}',zip='{$row['zip']}',phone1='{$row['homephone']}',dob=STR_TO_DATE('{$row['dob']}', '%Y%m%d'),ssn='{$row['ssn']}',sex='{$row['sex']}'";
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

			$query="UPDATE `ct_labcorp_pid` SET ct_sws_id='".mysql_insert_id()."' WHERE id='{$row['id']}'";
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

			$total_users_data_added++;
		}

		echo ($total_users_data_added+0) . " <i>new</i> users were added.\n";


}
$mail_body = ob_get_contents();
ob_end_flush();

$mailHeaders = "MIME-Version: 1.0\n";
$mailHeaders .= "Content-type: text/html; charset=iso-8859-1\n";
$mailHeaders .= "From: admin@sterling-wellness.com";


mail("brett@fireflydigital.com","Labcorp Imports",$mail_body,$mailHeaders)
?>