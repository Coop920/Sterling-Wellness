<?
#if not secure, redirect

if( !isset($_SERVER[ 'HTTPS' ]) || $_SERVER[ 'HTTPS' ]=='' || ( $_SERVER[ 'HTTPS' ] == 'off' ) ) {
	header( "Location: https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
}
/*
if($GLOBALS['HTTPS']!="on")
{
	header("Location: https://".$GLOBALS['HTTP_HOST'].$GLOBALS['REQUEST_URI']);
}
*/



include "global.php";

#Check To see if user is logged in
if(check_auth())
{
	#Display the page
	display_page($_GET['mode'],$_GET['page'],$_GET['mytoken'],$params);
}



?>
