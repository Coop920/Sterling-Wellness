<?
//some of the labcorps were linking to the wrong user accounts.  this is a working file to find out why and how to fix it
include "../global.php";
?>
<table>
	<tr>
		<th>firstname</th>
		<th>lastname</th>
		<th>pid id</th>
		<th>ct_sws_id</th>
	</tr>


<?
$query = " SELECT * FROM `ct_labcorp_pid`";
$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
while($row = mysql_fetch_array($result, MYSQL_ASSOC))
{
	$query2 = " SELECT * FROM `ct_users` WHERE id = '{$row['ct_sws_id']}'";
	$result2 = mysql_query($query2) or mysql_error_handler($query2, $PHP_SELF);
	if(mysql_num_rows($result2)==0)
	{
		?>
		<tr>
			<td><?= $firstname ?></td>
			<td><?= $lastname ?></td>
			<td><?= $id ?></td>
			<td><?= $ct_sws_id ?></td>
		</tr>
		<?

/*
		$query="INSERT INTO `ct_users` SET usertype='5',firstname='{$row['firstname']}',lastname='{$row['lastname']}',active='1',address='{$row['address']}',city='{$row['city']}',state='{$row['state']}',zip='{$row['zip']}',phone1='{$row['homephone']}',dob=STR_TO_DATE('{$row['dob']}', '%Y%m%d'),ssn='{$row['ssn']}',sex='{$row['sex']}'";
		mysql_query($query) or die($query  . "<br>" . mysql_error());

		$query="UPDATE `ct_labcorp_pid` SET ct_sws_id='".mysql_insert_id()."' WHERE id='{$row['id']}'";
		mysql_query($query) or die($query  . "<br>" . mysql_error());*/

	}


}
?>
</table>