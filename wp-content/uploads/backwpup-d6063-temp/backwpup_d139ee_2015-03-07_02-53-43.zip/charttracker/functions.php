<?
function check_auth()
{
	#IS THE USER TRYING TO LOG IN?
	if($_POST['login']==1)
	{
		$query = "UPDATE `ct_users` SET `lastlogin`=NOW() WHERE (email='{$_POST['email']}' OR `id` = '{$_POST['email']}') AND password = '".md5($_POST['password'])."' AND active='1';";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_affected_rows()!=0)
		{
			$logging_in = 1;
		}
		else
		{
			$params['failed_login_message'] = "Invalid login information. Please try again";
		}
	}
	#CHECK TO SEE IF LOGGED IN AND GET ALL USER INFO
	if($logging_in) $query = "SELECT * FROM `ct_users` WHERE (email='{$_POST['email']}' OR `id` = '{$_POST['email']}') AND password = '".md5($_POST['password'])."' AND active=1;";
	else $query = "SELECT * FROM `ct_users` WHERE id='{$_COOKIE['id']}' AND password = '{$_COOKIE['pw']}' AND active=1;";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)==0)
	{
		#USER IS NOT SIGNED IN Force them to log in
		if($_GET['page']=="password") display_page("util","password","",$params);
		else display_page("util","login","",$params);
		return(false);
	}
	else
	{
		#USER IS SIGNED IN
		$GLOBALS['user_data'] = mysql_fetch_assoc($result);

		#SET A COOKIE SO IT IT DOESN'T ASK TO LOG IN AGAIN
		if($logging_in)
		{
			setcookie("id", $GLOBALS['user_data']['id']);
			setcookie("pw", md5($_POST['password']));
		}

		return(true);

	}
}

function display_page($mode,$page,$token,$params)
{
	//send to the right userfolder
	if($mode=="") $mode = strtolower($GLOBALS['user_types'][$GLOBALS['user_data']['usertype']]);

	//default to index.php unless otherwise specified
	if($page=="") $page="index";


	ob_start();

	//include the content page
	if(file_exists("$mode/$page.php")) include("$mode/$page.php");
	else echo "Page not included yet: " . "$mode/$page.php";
	$page_contents = ob_get_contents();

	ob_end_clean();

	ob_start();
	show_menu($GLOBALS['user_data']['usertype']);
	$menu = ob_get_contents();
	ob_end_clean();

	include("util/header.php");
		echo  $page_contents;
	include("util/footer.php");


}

function show_menu($usertype)
{
	if($usertype) include("util/menu.php");
}

function show_hidden_fields()
{
	echo ($_GET['page']=="")? "<input type='hidden' name='page' value='{$_POST['page']}'>":  "<input type='hidden' name='page' value='{$_GET['page']}'>";
}

function mysql_error_handler($query)
{
	echo "<p><i>$query</i><br>";
	echo mysql_error();
	die();
}

function get_next_PID() {
	$ids_per_query = 10;
	$query = '
		SELECT value FROM ct_options WHERE name="last_PID"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$row = mysql_fetch_array( $result, MYSQL_ASSOC );
	$PID = $row['value']+1;
	while( 1 ) {
		$maxPID = $PID+$ids_per_query;
//		echo( 'range is '.$PID.' - '.$maxPID."\n" );
		$query = '
			SELECT id
			FROM ct_users
			WHERE id between '.$PID.' AND '.( $maxPID ).'
			ORDER BY id
		';
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		$ids = array();
		while( ($row = mysql_fetch_array( $result, MYSQL_ASSOC ) ) ) {
			$ids[ $row['id'] ] = true;
		}
		while( $PID <= $maxPID ) {
			if( isset( $ids[$PID] ) ) {
				$PID++;
				continue;
			}
			$query = '
				UPDATE ct_options
				SET value = "'.$PID.'"
				WHERE name = "last_PID"
			';
			mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
			return $PID;
		}
	}
}

// returns error description
function change_user_id( $old_id, $new_id ) {
	$query = '
		select id from ct_users where id="'.$new_id.'"
	';
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	$row = mysql_fetch_array( $result, MYSQL_ASSOC );
	if( $row ) return 'Can not change PID. The PID '.$new_id.' is already used.';

	$query = 'UPDATE ct_users SET id="'.$new_id.'" WHERE id="'.$old_id.'"';
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	$query = 'UPDATE ct_assessments SET patient="'.$new_id.'" WHERE patient="'.$old_id.'"';
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	$query = 'UPDATE ct_followups SET patient="'.$new_id.'" WHERE patient="'.$old_id.'"';
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	$query = 'UPDATE ct_hra SET user_id="'.$new_id.'" WHERE user_id="'.$old_id.'"';
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	$query = 'UPDATE ct_labcorp_pid SET ct_sws_id="'.$new_id.'" WHERE ct_sws_id="'.$old_id.'"';
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	$query = 'UPDATE ct_lab_results SET patient="'.$new_id.'" WHERE patient="'.$old_id.'"';
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	$query = 'UPDATE ct_uploads SET user_id="'.$new_id.'" WHERE user_id="'.$old_id.'"';
	mysql_query($query) or mysql_error_handler($query, $PHP_SELF);

	return '';
}


function import_hra($temp_file,$id)
{
	if( !isset( $GLOBALS['fulldata'] ) ) $GLOBALS['fulldata']=array();
	echo "<pre>";
	$first_row=1;
	$handle = fopen($temp_file, "r" ) ;
	while (($data = fgetcsv($handle, 10000, ",")) !== FALSE)
	{
		if($first_row)
		{
			$fields = $data;
			$first_row=0;
//			unset($first_row);
		}
		else
		{
			/*
			error_log( 'there are '.count($fields).' fields in fields'."\n", 3, 'log.txt');
			error_log( print_r( $fields, true )."\n", 3, 'log.txt' );
			error_log( 'there are '.count($data).' fields in data'."\n", 3, 'log.txt');
			error_log( print_r( $data, true )."\n", 3, 'log.txt' );
			*/
			$update_part = array();
			$num = count($data);
			for ($c=0; $c < $num; $c++)
			{


// Note our use of ===.  Simply == would not work as expected
// because the position of 'a' was the 0th (first) character.


				$mystring = $fields[$c];
				$findme   = 'Date';
				$pos = strpos($mystring, $findme);

				if ($pos !== false)
				{
					$date_format = explode("/",$data[$c]);
					$data[$c]= $date_format[2] . "-" . $date_format[0] . "-" . $date_format[1];

				}

				$update_part[$fields[$c]] =   $data[$c];

			}
			if( !isset( $GLOBALS['fulldata'][$update_part["ClientID"]] ) ) $GLOBALS['fulldata'][$update_part["ClientID"]]=array();
			$GLOBALS['fulldata'][$update_part["ClientID"]] = array_merge((array)$GLOBALS['fulldata'][$update_part["ClientID"]],(array)$update_part);
		}

	}


}


function show_labcorp_form($labcorp_id,$show_contact_info)
{
	$query = "SELECT * FROM ct_labcorp_pid WHERE id='$labcorp_id'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

	if($show_contact_info)
	{
		?>
		<table id="list_table" class="disp_table" width="80%">
		<tr bgcolor="white">
			<td colspan="6">
				<table width=100% border="1">
					<tr>
						<td><b>Name</b></td>
						<td><?= $lastname ?>, <?= $firstname ?> <?= $midinitial ?></td>
						<td><b>Sex</b></td>
						<td><?= $sex ?></td>
					</tr>
					<tr>
						<td><b>Date of Birth</b></td>
						<td><?= $dob ?></td>
					</tr>
						<tr>
						<td><b></b></td>
						<td><?= $ssn ?></td>
					</tr><tr>
						<td valign="top"><b>Address</b></td>
						<td colspan="3"><?= $address ?><br><?= $address2 ?>
						<br><?= $city ?>, <?= $state ?> <?= $zip ?> <?= $country_code ?></td>
					</tr>
					<tr>
						<td><b>Phone</b></td>
						<td><?= $homephone ?></td>
					</tr>
				</table>


			</td>
		</tr>
		<tr>
			<th>Tests</td>
			<th>Result</td>
			<th>Flag</td>
			<th>Units</td>
			<th>Reference Interval</td>
			<th>Lab</td>
		</tr>
	    <?
	}
	else
	{
		?>
		<tr>
			<td><b>Abnormal Labs</b></td>
			<td><b>Result</b></td>
			<td><b>Units</b></td>
			<td><b>Flag</b></td>
			<td><b>Reference Interval</b></td>
			<td><b>Lab</b></td>
		</tr>

		<?

	}
	$query = "SELECT *,id obr_id FROM ct_labcorp_obr WHERE pid='$labcorp_id'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		extract($row);
		?>
			<!--<tr class="row1">
				<td colspan="6"><b><?= $observation_text ?></b></td>
				<!--<td align="center"><b><?= $observation_coding ?></b></td>
				<td align="center"><b><?= $observation_time ?></b></td>
			</tr>-->
		<?
		$i=1;
		$query2 = "SELECT *,id obx_id FROM ct_labcorp_obx WHERE obr='$obr_id'";
		$result2 = mysql_query($query2) or mysql_error_handler($query2, $PHP_SELF);
		while($row2 = mysql_fetch_array($result2, MYSQL_ASSOC))
		{
			extract($row2);
			?>
			<tr class="row<?= $i*=-1 ?>">

				<td><input type="checkbox" name="labs[<?= $id ?>]" value="1" <?= $abnormal_flags!=""?"CHECKED":"" ?>><?= $observation_text ?></td>
				<td align="right"><?= $observation_value ?></td>
				<td align="left"><?= $units ?></td>
				<td align="center"><?= $abnormal_flags ?></td>
				<td align="center"><?= $reference ?></td>
				<td align="center"><?= $lab ?></td>
			</tr>

			<?

		}

	}
	?>

	</table>
	<?
}

function show_labcorp_no_form($labcorp_id,$show_contact_info)
{
	$query = "SELECT * FROM ct_labcorp_pid WHERE id='$labcorp_id'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

	if($show_contact_info)
	{
		?>
		<table id="list_table" class="disp_table" width="100%">
		<tr bgcolor="white">
			<td colspan="6">
				<table width=100% border="0">
					<tr>
						<td><b>Name</b></td>
						<td><?= $lastname ?>, <?= $firstname ?> <?= $midinitial ?></td>
						<td><b>Sex</b></td>
						<td><?= $sex ?></td>
					</tr>
					<tr>
						<td><b>Date of Birth</b></td>
						<td><?= date("m-d-Y",strtotime($dob)) ?></td>
					</tr>
						<tr>
						<td><b></b></td>
						<td><?= $ssn ?></td>
					</tr><tr>
						<td valign="top"><b>Address</b></td>
						<td colspan="3"><?= $address ?><br><?= $address2 ?>
						<br><?= $city ?>, <?= $state ?> <?= $zip ?> <?= $country_code ?></td>
					</tr>
					<tr>
						<td><b>Phone</b></td>
						<td><?= $homephone ?></td>
					</tr>
				</table>


			</td>
		</tr>
		<tr>
			<th>Tests</td>
			<th>Result</td>
			<th>Flag</td>
			<th>Units</td>
			<th>Reference Interval</td>
			<th>Lab</td>
		</tr>
	    <?
	}
	else
	{
		?>
		<table cellpadding="4" width="100%">
		<tr>
			<td><b>Tests</b></td>
			<td align="center"><b>Result</b></td>
			<td align="center"><b>Units</b></td>
			<td align="center"><b>Flag</b></td>
			<td align="center"><b>Reference Interval</b></td>
			<td align="center"><b>Lab</b></td>
		</tr>

		<?
		$form = true;
	}
	$query = "SELECT *,id obr_id FROM ct_labcorp_obr WHERE pid='$labcorp_id'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	while($row = mysql_fetch_array($result, MYSQL_ASSOC))
	{
		extract($row);
		?>
			<tr><td>&nbsp;</td></tr>
			<tr class="rowover" height="30">
				<td colspan="6"><b><?= $observation_text ?></b></td>
				<!--<td align="center"><b><?= $observation_coding ?></b></td>
				<td align="center"><b><?= $observation_time ?></b></td>-->
			</tr>
		<?
		$i=1;
		$query2 = "SELECT *,id obx_id FROM ct_labcorp_obx WHERE obr='$obr_id'";
		$result2 = mysql_query($query2) or mysql_error_handler($query2, $PHP_SELF);
		while($row2 = mysql_fetch_array($result2, MYSQL_ASSOC))
		{
			extract($row2);
			?>
			<tr class="row<?= $i*=-1 ?>">

							<td>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $observation_text ?></td>
							<td align="right"><?= $observation_value ?></td>
							<td align="left"><?= $units ?></td>
							<td align="center"><?= $abnormal_flags ?></td>
							<td align="center"><?= $reference ?></td>
							<td align="center"><?= $lab ?></td>
						</tr>

			</tr>

			<?

				$query3 = "SELECT * FROM ct_labcorp_nte WHERE obx='$obx_id'";
				$result3 = mysql_query($query3) or mysql_error_handler($query3, $PHP_SELF);
				if(mysql_num_rows($result3)>0)
				{
					?><tr class="row<?= $i ?>"><td colspan="6"><?

					while($row3 = mysql_fetch_array($result3, MYSQL_ASSOC))
					{
						extract($row3);
						?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $comment_text ?><br><?

					}
					echo "</td></tr>";
				}
		}

	}
	?>

	</table>
	<?
}


function show_hra_form($hra_id)
{
	$query = "SELECT * FROM ct_hra WHERE id = '$hra_id'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	?>

	<table id="form_table" align="center" cellpadding="5" width="100%">
		<tr>
			<td><b>Name</b></td><td><?= $LastName?>, <?=$FirstName?> <?=$MiddleInitial?></td>
		</tr>
		<tr class="row1">
			<td><b>Address</b></td><td colspan="4"><?=$Address?></td>
		</tr>
		<?php
			if($Address2)
			{
		?>
		<tr class="row1">
			<td><b></b></td><td colspan="4"><?=$Address2?></td>
		</tr>
		<?php
			}
		?>
		<tr class="row1">
			<td><b></b></td><td colspan="4"><?=$City?>, <?=$State?> <?=$ZipCode?></td>
		</tr>
		<tr>
			<td><b>Phone</b></td><td><?=$Phone?></td>
			<td rowspan="500">&nbsp;&nbsp;</td>
			<td><b>Alt. Phone</b></td><td><?=$Phone2?></td>
		</tr>
		<tr class="row1">
			<td><b>Email</b></td><td><?=$EMail?></td>
			<td><b>Gender</b></td><td><?=$Gender?></td>
		</tr>
		<tr>
			<td><b>Date of Birth</b></td><td><?=$BirthDate?></td>
			<td><b>Marital Status</b></td><td><?=$MaritalStatus?></td>
		</tr>
		<tr class="row1">
			<td><b>Education Level</b></td><td><?=$EducationLevel?></td>
			<td><b>Income Level</b></td><td><?=$IncomeLevel?></td>
		<tr>
			<td><b>Race</b></td><td><?=$Race?></td>
			<td><b>Group Number</b></td><td><?=$GroupNumber?></td>
		</tr>
		<tr class="row1">
			<td><b>Physician</b></td><td><?=$PhysicianName?></td>
			<td><b>Health Plan</b></td><td><?=$HealthPlanName?></td>
		</tr>
		<tr>
			<td><b>Company</b></td><td><?=$CompanyName?></td>
		</tr>
		<tr class="row1">
			<td><b>Assesments</b></td><td><?=$nAssessments?></td>
			<td><b>Entry Date</b></td><td><?=$EntryDate?></td>
		</tr>
		<tr>
			<td><b>Record Date</b></td><td><?=$RecordDate?></td>
			<td><b>PWP Type</b></td><td><?=$PWPType?></td>
		</tr>
		<tr class="row1">
			<td><b>Frame Size</b></td><td><?=$FrameSize?></td>
			<td><b>Age</b></td><td><?=$Age?></td>
		</tr>
		<tr>
			<td><b>Height</b></td><td><?=$Height?></td>
			<td><b>Weight</b></td><td><?=$Weight?></td>
		</tr>
		<tr class="row1">

		<td><b>Litho Code</b></td><td><?=$LithoCode?></td>
		<td><b>StrSigTroubleSleeping</b></td><td><?=$StrSigTroubleSleeping?></td>
		</tr>
		<tr>
		<td><b>StrSigEndLife</b></td><td><?=$StrSigEndLife?></td>
		<td><b>ChronicPain</b></td><td><?=$ChronicPain?></td>
		</tr>
		<tr class="row1">
		<td><b>HealthLimitations</b></td><td><?=$HealthLimitations?></td>
		<td><b>EmotionalProblems</b></td><td><?=$EmotionalProblems?></td>
		</tr>
		<tr>
		<td><b>SocialActivity</b></td><td><?=$SocialActivity?></td>
		<td><b>ExerciseDays</b></td><td><?=$ExerciseDays?></td>
		</tr>
		<tr class="row1">
		<td><b>StrengthExercise</b></td><td><?=$StrengthExercise?></td>
		<td><b>StretchingExercise</b></td><td><?=$StretchingExercise?></td>
		</tr>
		<tr>
		<td><b>Breakfast</b></td><td><?=$Breakfast?></td>
		<td><b>Snacking</b></td><td><?=$Snacking?></td>
		</tr>
		<tr class="row1">
		<td><b>Salt</b></td><td><?=$Salt?></td>
		<td><b>FatIntake</b></td><td><?=$FatIntake?></td>
		</tr>
		<tr>
		<td><b>Breads</b></td><td><?=$Breads?></td>
		<td><b>FruitsAndVegetables</b></td><td><?=$FruitsAndVegetables?></td>
		</tr>
		<tr class="row1">
		<td><b>DrinksPerWeek</b></td><td><?=$DrinksPerWeek?></td>
		<td><b>Drugs</b></td><td><?=$Drugs?></td>
		</tr>
		<tr>
		<td><b>SmokingStatus</b></td><td><?=$SmokingStatus?></td>
		<td><b>ChewingTobacco</b></td><td><?=$ChewingTobacco?></td>
		</tr>
		<tr class="row1">
		<td><b>CopingStatus</b></td><td><?=$CopingStatus?></td>
		<td><b>StrSigMinorProb</b></td><td><?=$StrSigMinorProb?></td>
		</tr>
		<tr>
		<td><b>StrSigNotGettingAlong</b></td><td><?=$StrSigNotGettingAlong?></td>
		<td><b>StrSigNoPleasure</b></td><td><?=$StrSigNoPleasure?></td>
		</tr>
		<tr class="row1">
		<td><b>StrSigUnableToStop</b></td><td><?=$StrSigUnableToStop?></td>
		<td><b>StrSigAnger</b></td><td><?=$StrSigAnger?></td>
		</tr>
		<tr>
		<td><b>StrSigTense</b></td><td><?=$StrSigTense?></td>
		<td><b>FeelCalm</b></td><td><?=$FeelCalm?></td>
		</tr>
		<tr class="row1">
		<td><b>FeelEnergy</b></td><td><?=$FeelEnergy?></td>
		<td><b>FeelBlue</b></td><td><?=$FeelBlue?></td>
		</tr>
		<tr>
		<td><b>FeelHappy</b></td><td><?=$FeelHappy?></td>
		<td><b>FeelWorthless</b></td><td><?=$FeelWorthless?></td>
		</tr>
		<tr class="row1">
		<td><b>FeelRelax</b></td><td><?=$FeelRelax?></td>
		<td><b>Sleep</b></td><td><?=$Sleep?></td>
		</tr>
		<tr>
		<td><b>JobSatisfaction</b></td><td><?=$JobSatisfaction?></td>
		<td><b>CopeRsrcFriends</b></td><td><?=$CopeRsrcFriends?></td>
		</tr>
		<tr class="row1">
		<td><b>SeatBelts</b></td><td><?=$SeatBelts?></td>
		<td><b>SunProtection</b></td><td><?=$SunProtection?></td>
		</tr>
		<tr>
		<td><b>Lifting</b></td><td><?=$Lifting?></td>
		<td><b>DrinkingAndDriving</b></td><td><?=$DrinkingAndDriving?></td>
		</tr>
		<tr class="row1">
		<td><b>PhysicalExam</b></td><td><?=$PhysicalExam?></td>
		<td><b>WomenPregnant</b></td><td><?=$WomenPregnant?></td>
		</tr>
		<tr>
		<td><b>ExamPAP</b></td><td><?=$ExamPAP?></td>
		<td><b>ExamMammogram</b></td><td><?=$ExamMammogram?></td>
		</tr>
		<tr class="row1">
		<td><b>WomenGivenBirth</b></td><td><?=$WomenGivenBirth?></td>
		<td><b>WomenMenopause</b></td><td><?=$WomenMenopause?></td>
		</tr>
		<tr>
		<td><b>MedEstrogen</b></td><td><?=$MedEstrogen?></td>
		<td><b>WomenBreastExam</b></td><td><?=$WomenBreastExam?></td>
		</tr>
		<tr class="row1">
		<td><b>SickDays</b></td><td><?=$SickDays?></td>
		<td><b>ExamBowel</b></td><td><?=$ExamBowel?></td>
		</tr>
		<tr>
		<td><b>ExamDental</b></td><td><?=$ExamDental?></td>
		<td><b>ExamImmunizationsFlu</b></td><td><?=$ExamImmunizationsFlu?></td>
		</tr>
		<tr class="row1">
		<td><b>BloodTestsMethodPWP</b></td><td><?=$BloodTestsMethodPWP?></td>
		<td><b>SystolicBP</b></td><td><?=$SystolicBP?></td>
		</tr>
		<tr>
		<td><b>DiastolicBP</b></td><td><?=$DiastolicBP?></td>
		<td><b>TotalCholesterol</b></td><td><?=$TotalCholesterol?></td>
		</tr>
		<tr class="row1">
		<td><b>HDLCholesterol</b></td><td><?=$HDLCholesterol?></td>
		<td><b>LDLCholesterol</b></td><td><?=$LDLCholesterol?></td>
		</tr>
		<tr>
		<td><b>Triglycerides</b></td><td><?=$Triglycerides?></td>
		<td><b>Glucose</b></td><td><?=$Glucose?></td>
		</tr>
		<tr class="row1">
		<td><b>WaistGirth</b></td><td><?=$WaistGirth?></td>
		<td><b>HipGirth</b></td><td><?=$HipGirth?></td>
		</tr>
		<tr>
		<td><b>BodyCompMethodPWP</b></td><td><?=$BodyCompMethodPWP?></td>
		<td><b>SumOfSkinfolds</b></td><td><?=$SumOfSkinfolds?></td>
		</tr>
		<tr class="row1">
		<td><b>KnownBodyFat</b></td><td><?=$KnownBodyFat?></td>
		<td><b>hemoglobinA1c</b></td><td><?=$hemoglobinA1c?></td>
		</tr>
		<tr>
		<td><b>C_ReactiveProtein</b></td><td><?=$C_ReactiveProtein?></td>
		<td><b>RecTag1</b></td><td><?=$RecTag1?></td>
		</tr>
		<tr class="row1">
		<td><b>RecTag2</b></td><td><?=$RecTag2?></td>
		<td><b>RecTag3</b></td><td><?=$RecTag3?></td>
		</tr>
		<tr>
		<td><b>RecTag4</b></td><td><?=$RecTag4?></td>
		<td><b>SerialRecNum</b></td><td><?=$SerialRecNum?></td>
		</tr>
		<tr class="row1">
		<td><b>BMI</b></td><td><?=$BMI?></td>
		<td><b>WHR</b></td><td><?=$WHR?></td>
		</tr>
		<tr>
		<td><b>BodyFat</b></td><td><?=$BodyFat?></td>
		<td><b>WeightCategory</b></td><td><?=$WeightCategory?></td>
		</tr>
		<tr class="row1">
		<td><b>RelativeWeight</b></td><td><?=$RelativeWeight?></td>
		<td><b>RecLowWeight</b></td><td><?=$RecLowWeight?></td>
		</tr>
		<tr>
		<td><b>RecHighWeight</b></td><td><?=$RecHighWeight?></td>
		<td><b>RecLowFat</b></td><td><?=$RecLowFat?></td>
		</tr>
		<tr class="row1">
		<td><b>RecHighFat</b></td><td><?=$RecHighFat?></td>
		<td><b>ScorePercentFat</b></td><td><?=$ScorePercentFat?></td>
		</tr>
		<tr>
		<td><b>ScoreWHR</b></td><td><?=$ScoreWHR?></td>
		<td><b>ScoreBMI</b></td><td><?=$ScoreBMI?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreWeight</b></td><td><?=$ScoreWeight?></td>
		<td><b>ScoreBodyComp</b></td><td><?=$ScoreBodyComp?></td>
		</tr>
		<tr>
		<td><b>ScorePushups</b></td><td><?=$ScorePushups?></td>
		<td><b>ScoreFlexibility</b></td><td><?=$ScoreFlexibility?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreAerobic</b></td><td><?=$ScoreAerobic?></td>
		<td><b>ScoreFitness</b></td><td><?=$ScoreFitness?></td>
		</tr>
		<tr>
		<td><b>ScoreBreakfast</b></td><td><?=$ScoreBreakfast?></td>
		<td><b>ScoreFastFoods</b></td><td><?=$ScoreFastFoods?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreDietaryFiber</b></td><td><?=$ScoreDietaryFiber?></td>
		<td><b>ScoreFatIntake</b></td><td><?=$ScoreFatIntake?></td>
		</tr>
		<tr>
		<td><b>ScoreNutrition</b></td><td><?=$ScoreNutrition?></td>
		<td><b>ScoreSeatbelts</b></td><td><?=$ScoreSeatbelts?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreLifting</b></td><td><?=$ScoreLifting?></td>
		<td><b>ScoreDrinkAndDrive</b></td><td><?=$ScoreDrinkAndDrive?></td>
		</tr>
		<tr>
		<td><b>ScoreSafety</b></td><td><?=$ScoreSafety?></td>
		<td><b>ScoreAlcohol</b></td><td><?=$ScoreAlcohol?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreMedications</b></td><td><?=$ScoreMedications?></td>
		<td><b>ScoreInteractions</b></td><td><?=$ScoreInteractions?></td>
		</tr>
		<tr>
		<td><b>ScoreTobacco</b></td><td><?=$ScoreTobacco?></td>
		<td><b>ScoreSubstanceUse</b></td><td><?=$ScoreSubstanceUse?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreCancerHeredity</b></td><td><?=$ScoreCancerHeredity?></td>
		<td><b>ScoreCancerDietary</b></td><td><?=$ScoreCancerDietary?></td>
		</tr>
		<tr>
		<td><b>ScoreCancerSmoking</b></td><td><?=$ScoreCancerSmoking?></td>
		<td><b>ScoreCancerOther</b></td><td><?=$ScoreCancerOther?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreCancer</b></td><td><?=$ScoreCancer?></td>
		<td><b>GoodHealthPractices</b></td><td><?=$GoodHealthPractices?></td>
		</tr>
		<tr>
		<td><b>HealthAge</b></td><td><?=$HealthAge?></td>
		<td><b>BadCholesterol</b></td><td><?=$BadCholesterol?></td>
		</tr>
		<tr class="row1">
		<td><b>HDLRatio</b></td><td><?=$HDLRatio?></td>
		<td><b>ScoreFHxCHD</b></td><td><?=$ScoreFHxCHD?></td>
		</tr>
		<tr>
		<td><b>ScoreOverallBP</b></td><td><?=$ScoreOverallBP?></td>
		<td><b>ScoreTotalCholesterol</b></td><td><?=$ScoreTotalCholesterol?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreHDLCholesterol</b></td><td><?=$ScoreHDLCholesterol?></td>
		<td><b>ScoreBadCholesterol</b></td><td><?=$ScoreBadCholesterol?></td>
		</tr>
		<tr>
		<td><b>ScoreGlucose</b></td><td><?=$ScoreGlucose?></td>
		<td><b>ScoreHeartHealth</b></td><td><?=$ScoreHeartHealth?></td>
		</tr>
		<tr class="row1">
		<td><b>StressSignals</b></td><td><?=$StressSignals?></td>
		<td><b>ScorePerceivedStress</b></td><td><?=$ScorePerceivedStress?></td>
		</tr>
		<tr>
		<td><b>ScoreStressSignals</b></td><td><?=$ScoreStressSignals?></td>
		<td><b>ScoreStressLoad</b></td><td><?=$ScoreStressLoad?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreHappiness</b></td><td><?=$ScoreHappiness?></td>
		<td><b>ScoreStress</b></td><td><?=$ScoreStress?></td>
		</tr>
		<tr>
		<td><b>ScorePWP</b></td><td><?=$ScorePWP?></td>
		<td><b>HighRiskFactors</b></td><td><?=$HighRiskFactors?></td>
		</tr>
		<tr class="row1">
		<td><b>CHDRiskFactors</b></td><td><?=$CHDRiskFactors?></td>
		<td><b>MetabolicSyndromeRiskFactors</b></td><td><?=$MetabolicSyndromeRiskFactors?></td>
		</tr>
		<tr>
		<td><b>ScorePhysicalFunctioning</b></td><td><?=$ScorePhysicalFunctioning?></td>
		<td><b>ScoreHSQRolePhysical</b></td><td><?=$ScoreHSQRolePhysical?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreBodilyPain</b></td><td><?=$ScoreBodilyPain?></td>
		<td><b>ScoreHealthPerception</b></td><td><?=$ScoreHealthPerception?></td>
		</tr>
		<tr>
		<td><b>ScoreEnergyFatigue</b></td><td><?=$ScoreEnergyFatigue?></td>
		<td><b>ScoreSocialFunctioning</b></td><td><?=$ScoreSocialFunctioning?></td>
		</tr>
		<tr class="row1">
		<td><b>ScoreHSQRoleMental</b></td><td><?=$ScoreHSQRoleMental?></td>
		<td><b>ScoreHSQMentalHealth</b></td><td><?=$ScoreHSQMentalHealth?></td>
		</tr>
		<tr>
		<td><b>ScoreHSQPCS</b></td><td><?=$ScoreHSQPCS?></td>
		<td><b>ScoreHSQMCS</b></td><td><?=$ScoreHSQMCS?></td>
		</tr>
		<tr class="row1">
		<td><b>HlthViewAmHealthy</b></td><td><?=$HlthViewAmHealthy?></td>
		<td><b>HlthViewGetSickEasier</b></td><td><?=$HlthViewGetSickEasier?></td>
		</tr>
		<tr>
		<td><b>HlthViewExpectedHealth</b></td><td><?=$HlthViewExpectedHealth?></td>
		<td><b>HlthViewSeriousProblem</b></td><td><?=$HlthViewSeriousProblem?></td>
		</tr>
		<tr class="row1">
		<td><b>PerceivedHlthOverall</b></td><td><?=$PerceivedHlthOverall?></td>
		<td><b>FHxColorectalCancer</b></td><td><?=$FHxColorectalCancer?></td>
		</tr>
		<tr>
		<td><b>FHxBreastCancer</b></td><td><?=$FHxBreastCancer?></td>
		<td><b>FHxDiabetes</b></td><td><?=$FHxDiabetes?></td>
		</tr>
		<tr class="row1">
		<td><b>FHxCHD</b></td><td><?=$FHxCHD?></td>
		<td><b>FHxHighBP</b></td><td><?=$FHxHighBP?></td>
		</tr>
		<tr>
		<td><b>FHxHighCholesterol</b></td><td><?=$FHxHighCholesterol?></td>
		<td><b>PHxAsthma</b></td><td><?=$PHxAsthma?></td>
		</tr>
		<tr class="row1">
		<td><b>PHxBowelPolyps</b></td><td><?=$PHxBowelPolyps?></td>
		<td><b>PHxCancerNonSkin</b></td><td><?=$PHxCancerNonSkin?></td>
		</tr>
		<tr>
		<td><b>PHxBronchitis</b></td><td><?=$PHxBronchitis?></td>
		<td><b>PHxHeartAttack</b></td><td><?=$PHxHeartAttack?></td>
		</tr>
		<tr class="row1">
		<td><b>PHxDiabetes</b></td><td><?=$PHxDiabetes?></td>
		<td><b>PHxHighBP</b></td><td><?=$PHxHighBP?></td>
		</tr>
		<tr>
		<td><b>PHxHighCholesterol</b></td><td><?=$PHxHighCholesterol?></td>
		<td><b>PHxSciatica</b></td><td><?=$PHxSciatica?></td>
		</tr>
		<tr class="row1">
		<td><b>PHxStroke</b></td><td><?=$PHxStroke?></td>
		<td><b>SymChestPain</b></td><td><?=$SymChestPain?></td>
		</tr>
		<tr>
		<td><b>SymShortnessOfBreath</b></td><td><?=$SymShortnessOfBreath?></td>
		<td><b>SymDizziness</b></td><td><?=$SymDizziness?></td>
		</tr>
		<tr class="row1">
		<td><b>SymNumbnessOrTingling</b></td><td><?=$SymNumbnessOrTingling?></td>
		<td><b>SymUrinationOrThirst</b></td><td><?=$SymUrinationOrThirst?></td>
		</tr>
		<tr>
		<td><b>SymBackPain</b></td><td><?=$SymBackPain?></td>
		<td><b>LimitLiftingGroceries</b></td><td><?=$LimitLiftingGroceries?></td>
		</tr>
		<tr class="row1">
		<td><b>LimitClimbingStairs</b></td><td><?=$LimitClimbingStairs?></td>
		<td><b>LimitWalkingBlocks</b></td><td><?=$LimitWalkingBlocks?></td>
		</tr>
		<tr>
		<td><b>ChangeStatusExercise</b></td><td><?=$ChangeStatusExercise?></td>
		<td><b>ChangeStatusNutrition</b></td><td><?=$ChangeStatusNutrition?></td>
		</tr>
		<tr class="row1">
		<td><b>ChangeStatusSmoke</b></td><td><?=$ChangeStatusSmoke?></td>
		<td><b>ChangeStatusWeight</b></td><td><?=$ChangeStatusWeight?></td>
		</tr>
		<tr>
		<td><b>ChangeStatusStress</b></td><td><?=$ChangeStatusStress?></td>
		<td><b>ChangeStatusAlcohol</b></td><td><?=$ChangeStatusAlcohol?></td>
		</tr>
		<tr class="row1">
		<td><b>ChangeStatus</b></td><td><?=$ChangeStatus?></td>
		<td><b>NoConsent</b></td><td><?=$NoConsent?></td>
		</tr>
		<tr>
		<td><b>Optional1</b></td><td><?=$Optional1?></td>
		<td><b>Optional2</b></td><td><?=$Optional2?></td>
		</tr>
		<tr class="row1">
		<td><b>Optional3</b></td><td><?=$Optional3?></td>
		<td><b>Optional4</b></td><td><?=$Optional4?></td>
		</tr>
		<tr>
		<td><b>Optional5</b></td><td><?=$Optional5?></td>
		<td><b>Optional6</b></td><td><?=$Optional6?></td>
		</tr>
		<tr class="row1">
		<td><b>Optional7</b></td><td><?=$Optional7?></td>
		<td><b>Optional8</b></td><td><?=$Optional8?></td>
		</tr>
		<tr>
		<td><b>Optional9</b></td><td><?=$Optional9?></td>
		<td><b>Optional10</b></td><td><?=$Optional10?></td>
		</tr>
		<tr class="row1">
		<td><b>Optional11</b></td><td><?=$Optional11?></td>
		<td><b>Optional12</b></td><td><?=$Optional12?></td>
		</tr>
		<tr>
		<td><b>Optional13</b></td><td><?=$Optional13?></td>
		<td><b>Optional14</b></td><td><?=$Optional14?></td>
		</tr>
		<tr class="row1">
		<td><b>Optional15</b></td><td><?=$Optional15?></td>
		<td><b>Optional16</b></td><td><?=$Optional16?></td>
		</tr>
		<tr>
		<td><b>Optional17</b></td><td><?=$Optional17?></td>
		<td><b>Optional18</b></td><td><?=$Optional18?></td>
		</tr>
		<tr class="row1">
		<td><b>Optional19</b></td><td><?=$Optional19?></td>
		<td><b>Optional20</b></td><td><?=$Optional20?></td>
		</tr>
		<tr>
		<td><b>Optional21</b></td><td><?=$Optional21?></td>
		<td><b>Optional22</b></td><td><?=$Optional22?></td>
		</tr>
		<tr class="row1">
		<td><b>Optional23</b></td><td><?=$Optional23?></td>
		<td><b>Optional24</b></td><td><?=$Optional24?></td>
		</tr>
		<tr>
		<td><b>Optional25</b></td><td><?=$Optional25?></td>
		<td><b>Optional26</b></td><td><?=$Optional26?></td>
		</tr>
		<tr class="row1">
		<td><b>Optional27</b></td><td><?=$Optional27?></td>
		<td><b>Optional28</b></td><td><?=$Optional28?></td>
		</tr>
		<tr>
		<td><b>Optional29</b></td><td><?=$Optional29?></td>
		<td><b>Optional30</b></td><td><?=$Optional30?></td>
		</tr>
		<tr class="row1">
		<td><b>TextOption1</b></td><td><?=$TextOption1?></td>
		<td><b>TextOption2</b></td><td><?=$TextOption2?></td>
		</tr>
		<tr>
		<td><b>TextOption3</b></td><td><?=$TextOption3?></td>
		<td><b>TextOption4</b></td><td><?=$TextOption4?></td>
		</tr>
		<tr class="row1">
		<td><b>TextOption5</b></td><td><?=$TextOption5?></td>
		<td><b>HIQuitSmoking</b></td><td><?=$HIQuitSmoking?></td>
		</tr>
		<tr>
		<td><b>HIWeightMgt</b></td><td><?=$HIWeightMgt?></td>
		<td><b>HIAerobics</b></td><td><?=$HIAerobics?></td>
		</tr>
		<tr class="row1">
		<td><b>HIWalking</b></td><td><?=$HIWalking?></td>
		<td><b>HIJogging</b></td><td><?=$HIJogging?></td>
		</tr>
		<tr>
		<td><b>HIFitnessEval</b></td><td><?=$HIFitnessEval?></td>
		<td><b>HINutrition</b></td><td><?=$HINutrition?></td>
		</tr>
		<tr class="row1">
		<td><b>HICholesterol</b></td><td><?=$HICholesterol?></td>
		<td><b>HIBP</b></td><td><?=$HIBP?></td>
		</tr>
		<tr>
		<td><b>HICoronaryRisk</b></td><td><?=$HICoronaryRisk?></td>
		<td><b>HICancerRisk</b></td><td><?=$HICancerRisk?></td>
		</tr>
		<tr class="row1">
		<td><b>HIAlcoholDrug</b></td><td><?=$HIAlcoholDrug?></td>
		<td><b>HIHealthyBack</b></td><td><?=$HIHealthyBack?></td>
		</tr>
		<tr>
		<td><b>HISelfCare</b></td><td><?=$HISelfCare?></td>
		<td><b>HIStressMgt</b></td><td><?=$HIStressMgt?></td>
		</tr>
		<tr class="row1">
		<td><b>HICPR</b></td><td><?=$HICPR?></td>
		<td><b>HIFirstAid</b></td><td><?=$HIFirstAid?></td>
		</tr>
		<tr>
		<td><b>HIHealthEval</b></td><td><?=$HIHealthEval?></td>
		<td><b>HIWomensHealth</b></td><td><?=$HIWomensHealth?></td>
		</tr>
		<tr class="row1">
		<td><b>HIDiabetes</b></td><td><?=$HIDiabetes?></td>
		<td><b>HICommunication</b></td><td><?=$HICommunication?></td>
		</tr>
		<tr>
		<td><b>HIAIDSSTDS</b></td><td><?=$HIAIDSSTDS?></td>
		<td><b>HIRelationship</b></td><td><?=$HIRelationship?></td>
	</table>
	<?
}


function find_abnormal_pid ($pid_id)
{
	$query = "SELECT ct_labcorp_obx.abnormal_flags
				FROM ct_labcorp_pid,ct_labcorp_obr,ct_labcorp_obx
				WHERE 	ct_labcorp_pid.id = ct_labcorp_obr.pid
					AND ct_labcorp_obr.id = ct_labcorp_obx.obr
					AND	(ct_labcorp_obx.abnormal_flags IS NOT NULL)
					AND	(ct_labcorp_obx.abnormal_flags != '')
					AND ct_labcorp_pid.id = '$pid_id'
				LIMIT 1";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	return(mysql_num_rows($result));
}





function show_health_assessment($id)
{
	$query = "SELECT * FROM ct_assessments WHERE id='$id'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

	$query = "SELECT * FROM ct_users WHERE id='$patient'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
	?>

	<html>
	<head>
		<title>Sterling Wellness Solutions</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<meta name="Author" content="Firefly Digital, Inc., www.firefly.cc, 800-397-1624">
		<link href="styles.css" rel="stylesheet" type="text/css">
		<link href="layout.css" rel="stylesheet" type="text/css">
	</head>
	<table cellpadding="4">
		<tr>
			<td><b>Name</b>:</td>
			<td><?= $firstname ?> <?= $lastname ?></td>
		</tr>
		<tr>
			<td><b>Phone Number:</b></td>
			<td><?= $phone ?></td>
		</tr>
		<tr>
			<td><b>Date:</b></td>
			<td><?= date("m-d-Y") ?></td>
		</tr>
		<tr>
			<td><b>Location:</b></td>
			<td><?= $location ?></td>
		</tr>
	</table>
	<br>
	<table id="list_table" class="disp_table" cellpadding="4" width="100%">
		<tr>
			<th>Health Assessment</th>
			<th>Results</th>
			<th>Physician Referral</th>
			<th>Reason for Referral</th>
			<th>Comments/Reccomendations/Goals</th>
		</tr>
		<tr class="row-1">
			<td valign="top">
				<b>Health Screening Analysis</b>
				<p>
				<b>RX</b><br>
				<?
				if($rx!="")
				{
					$query = "SELECT * FROM ct_option_prs WHERE id IN ($rx) ORDER BY text";
					$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
					while($rxs = mysql_fetch_array($result, MYSQL_ASSOC))
					{
						echo $rxs['text'] , "<br>";
					}
				}
				?>
				<?= $other_box?"Other: ":"" ?><?=  $other_text ?>

				</p>

			</td>
			<td valign="top">
			<b>Blood Pressure</b>
				<table align="center">
				<tr>
					<td>Systolic</td>
					<td><?= $r_systolic ?></td>
				</tr>
				<tr>
					<td>Diastolic</td>
					<td><?= $r_diastolic ?></td>
				</tr>
				<tr>
					<td>Pulse</td>
					<td><?= $r_pulse ?></td>
				</tr>
				<tr>
					<td>Weight</td>
					<td><?= $r_weight ?></td>
				</tr>
				<tr>
					<td>Height</td>
					<td><?= $r_height ?></td>
				</tr>
				<tr>
					<td>Waist</td>
					<td><?= $r_waist ?></td>
				</tr>
				<tr>
					<td>Body Fat</td>
					<td><?= $r_bodyfat ?></td>
				</tr>
				<tr>
					<td>BMI</td>
					<td><?= $r_bmi ?></td>
				</tr>
				</table>

			</td>
			<td valign="top">
				<?= $phys_ref=="Y"?"Yes":"No" ?>
			</td>
			<td valign="top"><?= $rfr ?></td>
			<td valign="top"><?= $goals ?></td>
		</tr>
		<tr class="row-1">
			<td>Fitness Test (3 minute step test)</td>
			<td><?= $rfr ?></td>
			<td><?= $ft_ref=="Y"?"Yes":"No" ?></td>
			<td><?= $ft_rfr ?></td>
			<td><?= $sign_ft?"Signed":"" ?></td>
		</tr>
		<tr class="row-1">
			<td>Flexibility (Sit and Reach)</td>
			<td><?= $rfr ?></td>
			<td><?= $fl_ref=="Y"?"Yes":"No" ?></td>
			<td><?= $fl_rfr ?></td>
			<td><?= $sign_fl?"Signed":"" ?></td>
		</tr>
		<tr class="row-1">
			<td>Bone Density</td>
			<td>
				<?= $bone_density=="1"?"Normal":"" ?>
				<?= $bone_density=="2"?"Osteopenia":"" ?>
				<?= $bone_density=="3"?"Osteoporosis":"" ?>
			</td>
			<td><?= $bd_ref=="Y"?"Yes":"No" ?></td>
			<td><?= $bd_rfr ?></td>
			<td><?= $sign_bd?"Signed":"" ?></td>
		</tr>
	</table>
	<?
}

function show_followup($id)
{
	$query .= "SELECT *,DATE_FORMAT(FROM_DAYS(TO_DAYS(NOW())-TO_DAYS(dob)), '%Y')+0 age, DATE_FORMAT(q1date,'%m/%d/%y') q1date,DATE_FORMAT(q2date,'%m/%d/%y') q2date,DATE_FORMAT(q3date,'%m/%d/%y') q3date,DATE_FORMAT(q4date,'%m/%d/%y') q4date FROM ct_followups, ct_users WHERE ct_followups.patient = ct_users.id AND ct_followups.id = '$id'";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));

	?>
	<table align="center" cellpadding="6" cellspacing="0" width="100%">
		<tr>
			<td>
				<table width="100%">
					<tr>
						<td><b>Name: </b><?= $firstname ?> <?= $lastname ?></td>
						<td><b>Age: </b><?= $age ?></td>
						<td align="right"><b>Gender: </b>&nbsp;<?= $sex ?></td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td bgcolor="#ECEEE3" style="border-top: 1px #D0D0C8 solid">
				<table width="100%">
					<tr>
						<td rowspan="10" valign="top" width="110">
							<B>Reason for<br>Program<br>Participation</B>
						</td>
						<td colspan="2">
							<b>Abnormal Lab Results</b>
						</td>
						<td colspan="3">
							<b>Personal History</b>
						</td>
					</tr>
					<?

					$alr_ph_vals = array(
						"Glucose",
						"Diabetes Mellitus",
						"Hemoglobin A<sub>1</sub>C",
						"Cancer",
						"Kidney Function",
						"Cardiovascular",
						"Liver Function",
						"Stroke",
						"Electrolytes",
						"Hepatitis",
						"Cholesterol",
						"Obesity",
						"Thyroid",
						"Other:",
						"CBC",
						"&nbsp;",
						"Other",
						"HRA Score Under 25");

						for($x=0;$x<count($alr_ph_vals);$x+=2)
						{
							$var1 = "alr_ph_$x";
							$var2 = "alr_ph_".($x+1);

							?>
							<tr>
								<td colspan="2"><?= $$var1?$alr_ph_vals[$x]:"" ?></td>
								<td colspan="3"><?= $$var2?$alr_ph_vals[$x+1]:"" ?></td>
							</tr>
							<?
						}

					?>
				</table>
			</td>
		</tr>
		<tr>
			<td style="border-top: 1px #D0D0C8 solid">
				<table width="100%">
					<tr>
						<td rowspan="14" valign="top" width="110"><b>Health<br>Practice<br>Review</b></td>
						<td>&nbsp;</td>
							<td align="center"><b>Qtr 1:</b> <?= $q1date!="00/00/00"?$q1date:"" ?></td>
							<td align="center"><b>Qtr 2:</b> <?= $q2date!="00/00/00"?$q2date:"" ?></td>
							<td align="center"><b>Qtr 3:</b> <?= $q3date!="00/00/00"?$q3date:"" ?></td>
							<td align="center"><b>Qtr 4:</b> <?= $q4date!="00/00/00"?$q4date:"" ?></td>
						</tr>
						<?
						$hpr_vals = array(
									"Any changes to diet regimen",
									"Any changes to excercise regimen",
									"Smoking cessation",
									"Weight loss/gain",
									"Blood pressure control",
									"Medication regimen changes",
									"Diabetes Control",
									"Pneumonia vaccine",
									"Influenza vaccine",
									"PCP Follow-up",
									"Other:" );
						for($x=0;$x<count($hpr_vals);$x++)
						{
							$var1 = "hpr_$x"."_1";
							$var2 = "hpr_$x"."_2";
							$var3 = "hpr_$x"."_3";
							$var4 = "hpr_$x"."_4";
							?>
							<tr>
								<td><?= $hpr_vals[$x] ?></td>
								<td><?= $$var1 ?></td>
								<td><?= $$var2 ?></td>
								<td><?= $$var3 ?></td>
								<td><?= $$var4 ?></td>
							</tr>
							<?
						}

						?>
				</table>
			</td>
		</tr>
		<tr>
			<td bgcolor="#ECEEE3" style="border-top: 1px #D0D0C8 solid">
				<table width="100%">
					<tr>
						<td rowspan="25" valign="top" width="110"><b>Education/<br>Reinforcement<br>Provided</b></td>
						<?
						$erp_vals = array(
									"Limiting saturated fats",
									"Diabetes control",
									"High fiber diet",
									"Diet adequate in calcium",
									"Portion control",
									"Limiting sodium intake",
									"Other Diet",
									"Limit alcohol intake",
									"Colorectal cancer screening",
									"Mammogram",
									"Pap Smear",
									"Prostate health",
									"Bone density screening",
									"Eye exam",
									"Hearing screening",
									"Hearing protection",
									"Smoking cessation",
									"Seat belt use",
									"Limiting sun exposure",
									"Blood pressure control",
									"Medication compliance",
									"Pneumonia vaccine",
									"Influenza vaccine",
									"Other",
									);

						for($x=0;$x<count($erp_vals);$x++)
						{
							$var1 = "erp_$x"."_1";
							$var2 = "erp_$x"."_2";
							$var3 = "erp_$x"."_3";
							$var4 = "erp_$x"."_4";

							?>
							<tr>
								<td><?= $erp_vals[$x] ?></td>
								<td><?= $$var1 ?></td>
								<td><?= $$var2 ?></td>
								<td><?= $$var3 ?></td>
								<td><?= $$var4 ?></td>
							</tr>
							<?
						}

						?>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<?
}

function show_notification($id)
{
	/*$query .= "SELECT *,DATE_FORMAT(`EntryDate`,'%m-%d-%Y') date_fmt, concat(`ct_users`.`lastname`,', ',`ct_users`.`firstname`) name_fmt, companies.company company_name , ct_labcorp_pid.id id
							FROM ct_hra,ct_labcorp_pid, ct_users
							LEFT JOIN `ct_users` companies ON (companies.id = ct_users.company)
							WHERE  ct_hra.labcorp_id = ct_labcorp_pid.id
								AND ct_labcorp_pid.ct_sws_id = ct_users.id
								AND ct_labcorp_pid.id = '{$_GET['id']}'
							ORDER BY EntryDate";
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));
*/

	$query = "SELECT *,date_format(`date`,'%m-%d-%Y') date, date_format(`doc`,'%m-%d-%Y') doc FROM `ct_lab_results` WHERE `id` = '$id'";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		if(mysql_num_rows($result)>0) extract(mysql_fetch_array($result));



	?>
	<table align="center" width="100%" class="disp_table white_table" id="list_table">
		<tr>
			<td>
				<table id="form_table" cellpadding="4" width="100%">
					<tr>
						<th colspan="4">Participant Information</th>
					</tr>
					<tr>
						<td><b>Date:</b></td>
						<td width="50%"><?= $date ?></td>
					</tr>
					<tr>
						<td><b>Name:</b></td>
						<td><?= $name_fmt ?></td>
						<td><b>Phone:</b></td>
						<td width="50%"><?= $phone1 ?></td>
					</tr>
					<tr>
						<td><b>Company:</b></td>
						<td><?= $company ?></td>
						<td><b>Initials:</b></td>
						<td><?= $initial ?></td>
					</tr>
				</table>
				<br>
				<table id="form_table" cellpadding="4" width="100%">
					<tr>
						<th colspan="4">Call-Back Information</th>
					</tr>
					<tr>
						<td><b>Date of Call:</b></td>
						<td width="50%">
							<?= $doc ?>
						</td>
					</tr>
					<tr>
						<td><b>Labs sent via:</b></td>
						<td><?= $labs_sent=="m"?"Mail":"" ?>
							<?= $labs_sent=="f"?"Fax":"" ?>
							</select>
							</td>
						<td colspan="2" width="50%"><?= $wait?"Participant requested to wait for results.":"" ?>
					</tr>
					<tr>
						<td><b>Comments/History:</b></td>
					</tr>
					<tr>
						<td colspan="4"><?= $comments ?></td>
					</tr>
				</table>
				<br>
				<table id="form_table" width="100%">
					<tr>
						<th colspan="6">Wellness Panel</th>
					</tr>

					<?
					$checkboxes = unserialize($checkboxes);
					if(!is_array($checkboxes)) $checkboxes=array();

					$query = "SELECT *,id obr_id FROM ct_labcorp_obr WHERE pid='$id'";
					$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
					while($row = mysql_fetch_array($result, MYSQL_ASSOC))
					{
						extract($row);
						$i=1;
						$query2 = "SELECT *,id obx_id FROM ct_labcorp_obx WHERE obr='$obr_id'";
						$result2 = mysql_query($query2) or mysql_error_handler($query2, $PHP_SELF);
						while($row2 = mysql_fetch_array($result2, MYSQL_ASSOC))
						{
							extract($row2);

							?>
							<tr class="row<?= $i*=-1 ?>">

								<td><?= in_array($obx_id,$checkboxes)?"<b>X</b>":"" ?><?= $observation_text ?></td>
								<td align="center"><?= $observation_results ?></td>
								<td align="center"><?= $abnormal_flags ?></td>
								<td align="center"><?= $units ?></td>
								<td align="center"><?= $reference ?></td>
								<td align="center"><?= $lab ?></td>
							</tr>

							<?

						}
					}
					?>

				</table>




			</td>
		</tr>
	</table></td></tr>
	</table>
	<?
}


function does_this_test_belong_to_this_patient($test_id,$test_table,$id_to_check,$field_to_match)
{
	//if it's an hra, check to see if the associated labcorp belongs to the client
	if($test_table == "ct_hra")
		$query2 = "SELECT ct_hra.id FROM `ct_labcorp_pid`,`ct_hra` WHERE ct_hra.labcorp_id=ct_labcorp_pid.id AND `ct_hra`.`id`='$test_id' LIMIT 1";
	else //check the test
		$query2 = "SELECT id FROM `$test_table` WHERE `$field_to_match` = '$id_to_check' AND `id`='$test_id' LIMIT 1";

	$result2 = mysql_query($query2) or mysql_error_handler($query2, $PHP_SELF);
	return mysql_num_rows($result2);
}


function show_states($selected_state)
{

	foreach ($GLOBALS['state_list'] as $key=>$val)
	{
		if(strlen($selected_state)!=2) $selected_state="LA";

		?>
		<option value="<?= $key ?>" <?= $key==$selected_state?"SELECTED":"" ?>><?= $val ?></option>
		<?
	}


}

function reason_dropdown($textarea_id)
{
	?>
	<select onchange="document.getElementById('<?= $textarea_id ?>').value+=this.value+'\n'" style="width:100%">
		<option value="">Reason For Referral</option>
		<?
		$query = "SELECT `text` FROM ct_option_rfr";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		while($row = mysql_fetch_array($result, MYSQL_ASSOC))
		{
			extract($row);
			?><Option  value="<?= $text ?>"><?= $text ?></option><?
		}
		?>
	</select>
	<?
}


function reccomend_dropdown($textarea_id)
{
	?>
	<select onchange="document.getElementById('<?= $textarea_id ?>').value+= this.value? this.value+'\n' : '';" style="width:100%">
		<option value="">Comments &amp; Recommendations</option>
		<?
		$query = "SELECT `text` FROM ct_option_rec WHERE active=1";
		$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
		while($row = mysql_fetch_array($result, MYSQL_ASSOC))
		{
			extract($row);
			?><Option  value="<?= trim($text) ?>"><?= trim($text) ?></option><?
		}
		?>
	</select>
	<?
}

function get_user_history( $user_id, $full = false ) {
	global $history_types;
	if( $full ) {
		$query = '
			SELECT id, DATE_FORMAT(`import_date`,"%m-%d-%Y") date_f, "" filename, '.$history_types['labcorp'].'" test_name, "labcorp" test_type, hra_id linked_to FROM ct_labcorp_pid WHERE ct_sws_id="'.$user_id.'"
			UNION
			SELECT ct_hra.id id, DATE_FORMAT(ct_hra.`import_date`,"%m-%d-%Y") date_f, "" filename, "'.$history_types['hra'].'" test_name, "hra" test_type, ct_hra.labcorp_id linked_to FROM ct_hra,ct_labcorp_pid WHERE (ct_labcorp_pid.id=ct_hra.labcorp_id AND ct_sws_id="'.$user_id.'") OR ( ct_hra.user_id="'.$user_id.'" )
			UNION
			SELECT id , DATE_FORMAT(`add_date`,"%m-%d-%Y") date_f, "" filename, "'.$history_types['assessment'].'(attached)" test_name, "assessment" test_type, "" linked_to FROM ct_assessments WHERE patient = "'.$user_id.'"
			UNION
			SELECT id,  DATE_FORMAT(GREATEST(q1date,q2date,q3date,q4date),"%m-%d-%Y") date_f , "" filename, "'.$history_types['followup'].'" test_name, "followup" test_type, "" linked_to FROM ct_followups WHERE patient = "'.$user_id.'"
			UNION
			SELECT id, DATE_FORMAT(`date`,"%m-%d-%Y") date_f, "" filename, "'.$history_types['lab_result'].'" test_name, "lab_result" test_type, "" linked_to FROM ct_lab_results WHERE patient = "'.$user_id.'"
			UNION
			SELECT id, DATE_FORMAT(`date`,"%m-%d-%Y") date_f, filename filename, file_desc test_name, "upload" test_type, "" linked_to FROM ct_uploads WHERE user_id = "'.$user_id.'"
			ORDER BY date_f DESC';
	} else {
		$query = '
			SELECT id, DATE_FORMAT(`import_date`,"%m-%d-%Y") date_f, "" filename, "'.$history_types['labcorp'].'" test_name, "labcorp" test_type, hra_id linked_to FROM ct_labcorp_pid WHERE ct_sws_id="'.$user_id.'"
			UNION
			SELECT ct_hra.id id, DATE_FORMAT(ct_hra.`import_date`,"%m-%d-%Y") date_f, "" filename, "'.$history_types['hra'].'" test_name, "hra" test_type, ct_hra.labcorp_id linked_to FROM ct_hra,ct_labcorp_pid WHERE (ct_labcorp_pid.id=ct_hra.labcorp_id AND ct_sws_id="'.$user_id.'")
			UNION
			SELECT id , DATE_FORMAT(`add_date`,"%m-%d-%Y") date_f, "" filename, "'.$history_types['assessment'].'" test_name, "assessment" test_type, "" linked_to FROM ct_assessments WHERE patient = "'.$user_id.'"
			UNION
			SELECT id,  DATE_FORMAT(GREATEST(q1date,q2date,q3date,q4date),"%m-%d-%Y") date_f , "" filename, "'.$history_types['followup'].'" test_name, "followup" test_type, "" linked_to FROM ct_followups WHERE patient = "'.$user_id.'"
			UNION
			SELECT id, DATE_FORMAT(`date`,"%m-%d-%Y") date_f, "" filename, "'.$history_types['lab_result'].'" test_name, "lab_result" test_type, "" linked_to FROM ct_lab_results WHERE patient = "'.$user_id.'"
			UNION
			SELECT id, DATE_FORMAT(`date`,"%m-%d-%Y") date_f, filename filename, file_desc test_name, "upload" test_type, "" linked_to FROM ct_uploads WHERE user_id = "'.$user_id.'"
			ORDER BY date_f DESC';
	}

	$history = array();
	$result = mysql_query($query) or mysql_error_handler($query, $PHP_SELF);
	if( $result === false ) return $history;
	while( $row = mysql_fetch_array($result, MYSQL_ASSOC) ) $history[] = $row;
	return $history;
}
?>